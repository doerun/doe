/**
 * Copyright 2019-2023 WebGPU-Native developers
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/** @file */

/**
 * \mainpage
 *
 * **Important:** *This documentation is a Work In Progress.*
 *
 * This is the home of WebGPU C API specification. We define here the standard
 * `webgpu.h` header that all implementations should provide.
 *
 * For all details where behavior is not otherwise specified, `webgpu.h` has
 * the same behavior as the WebGPU specification for JavaScript on the Web.
 * The WebIDL-based Web specification is mapped into C as faithfully (and
 * bidirectionally) as practical/possible.
 * The working draft of WebGPU can be found at <https://www.w3.org/TR/webgpu/>.
 *
 * The standard include directive for this header is `#include <webgpu/webgpu.h>`
 * (if it is provided in a system-wide or toolchain-wide include directory).
 */

#ifndef DOE_WEBGPU_H_
#define DOE_WEBGPU_H_

#if defined(DoeWGPU_SHARED_LIBRARY)
#    if defined(_WIN32)
#        if defined(DoeWGPU_IMPLEMENTATION)
#            define DoeWGPU_EXPORT __declspec(dllexport)
#        else
#            define DoeWGPU_EXPORT __declspec(dllimport)
#        endif
#    else  // defined(_WIN32)
#        if defined(DoeWGPU_IMPLEMENTATION)
#            define DoeWGPU_EXPORT __attribute__((visibility("default")))
#        else
#            define DoeWGPU_EXPORT
#        endif
#    endif  // defined(_WIN32)
#else       // defined(DoeWGPU_SHARED_LIBRARY)
#    define DoeWGPU_EXPORT
#endif  // defined(DoeWGPU_SHARED_LIBRARY)

#if !defined(DoeWGPU_OBJECT_ATTRIBUTE)
#define DoeWGPU_OBJECT_ATTRIBUTE
#endif
#if !defined(DoeWGPU_ENUM_ATTRIBUTE)
#define DoeWGPU_ENUM_ATTRIBUTE
#endif
#if !defined(DoeWGPU_STRUCTURE_ATTRIBUTE)
#define DoeWGPU_STRUCTURE_ATTRIBUTE
#endif
#if !defined(DoeWGPU_FUNCTION_ATTRIBUTE)
#define DoeWGPU_FUNCTION_ATTRIBUTE
#endif
#if !defined(DoeWGPU_NULLABLE)
#define DoeWGPU_NULLABLE
#endif

#include <stdint.h>
#include <stddef.h>
#include <math.h>

#define _wgpu_COMMA ,
#if defined(__cplusplus)
#  define _wgpu_ENUM_ZERO_INIT(type) type(0)
#  define _wgpu_STRUCT_ZERO_INIT {}
#  if __cplusplus >= 201103L
#    define _wgpu_MAKE_INIT_STRUCT(type, value) (type value)
#  else
#    define _wgpu_MAKE_INIT_STRUCT(type, value) value
#  endif
#else
#  define _wgpu_ENUM_ZERO_INIT(type) (type)0
#  define _wgpu_STRUCT_ZERO_INIT {0}
#  if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
#    define _wgpu_MAKE_INIT_STRUCT(type, value) ((type) value)
#  else
#    define _wgpu_MAKE_INIT_STRUCT(type, value) value
#  endif
#endif

/**
 * \defgroup Constants Constants
 * \brief Constants.
 *
 * @{
 */

/**
 * 'True' value of @ref DoeWGPUBool.
 *
 * @remark It's not usually necessary to use this, as `true` (from
 * `stdbool.h` or C++) casts to the same value.
 */
#define DoeWGPU_TRUE (UINT32_C(1))
/**
 * 'False' value of @ref DoeWGPUBool.
 *
 * @remark It's not usually necessary to use this, as `false` (from
 * `stdbool.h` or C++) casts to the same value.
 */
#define DoeWGPU_FALSE (UINT32_C(0))
/**
 * Indicates no array layer count is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_ARRAY_LAYER_COUNT_UNDEFINED (UINT32_MAX)
/**
 * Indicates no copy stride is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_COPY_STRIDE_UNDEFINED (UINT32_MAX)
/**
 * Indicates no depth clear value is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_DEPTH_CLEAR_VALUE_UNDEFINED (NAN)
/**
 * Indicates no depth slice is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_DEPTH_SLICE_UNDEFINED (UINT32_MAX)
/**
 * For `uint32_t` limits, indicates no limit value is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_LIMIT_U32_UNDEFINED (UINT32_MAX)
/**
 * For `uint64_t` limits, indicates no limit value is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_LIMIT_U64_UNDEFINED (UINT64_MAX)
/**
 * Indicates no mip level count is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_MIP_LEVEL_COUNT_UNDEFINED (UINT32_MAX)
/**
 * Indicates no query set index is specified. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_QUERY_SET_INDEX_UNDEFINED (UINT32_MAX)
/**
 * Sentinel value used in @ref DoeWGPUStringView to indicate that the pointer
 * is to a null-terminated string, rather than an explicitly-sized string.
 */
#define DoeWGPU_STRLEN (SIZE_MAX)
/**
 * Indicates a size extending to the end of the buffer. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_WHOLE_MAP_SIZE (SIZE_MAX)
/**
 * Indicates a size extending to the end of the buffer. For more info,
 * see @ref SentinelValues and the places that use this sentinel value.
 */
#define DoeWGPU_WHOLE_SIZE (UINT64_MAX)

/** @} */

/**
 * \defgroup UtilityTypes Utility Types
 *
 * @{
 */

/**
 * Nullable value defining a pointer+length view into a UTF-8 encoded string.
 *
 * Values passed into the API may use the special length value @ref DoeWGPU_STRLEN
 * to indicate a null-terminated string.
 * Non-null values passed out of the API (for example as callback arguments)
 * always provide an explicit length and **may or may not be null-terminated**.
 *
 * Some inputs to the API accept null values. Those which do not accept null
 * values "default" to the empty string when null values are passed.
 *
 * Values are encoded as follows:
 * - `{NULL, DoeWGPU_STRLEN}`: the null value.
 * - `{non_null_pointer, DoeWGPU_STRLEN}`: a null-terminated string view.
 * - `{any, 0}`: the empty string.
 * - `{NULL, non_zero_length}`: not allowed (null dereference).
 * - `{non_null_pointer, non_zero_length}`: an explictly-sized string view with
 *   size `non_zero_length` (in bytes).
 *
 * For info on how this is used in various places, see \ref Strings.
 */
typedef struct DoeWGPUStringView {
    DoeWGPU_NULLABLE char const * data;
    size_t length;
} DoeWGPUStringView DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUStringView.
 */
#define DoeWGPU_STRING_VIEW_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUStringView, { \
    /*.data=*/NULL _wgpu_COMMA \
    /*.length=*/DoeWGPU_STRLEN _wgpu_COMMA \
})

typedef uint64_t DoeWGPUFlags;
typedef uint32_t DoeWGPUBool;

/** @} */

/**
 * \defgroup Objects Objects
 * \brief Opaque, non-dispatchable handles to WebGPU objects.
 *
 * @{
 */
typedef struct DoeWGPUAdapterImpl* DoeWGPUAdapter DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUBindGroupImpl* DoeWGPUBindGroup DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUBindGroupLayoutImpl* DoeWGPUBindGroupLayout DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUBufferImpl* DoeWGPUBuffer DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUCommandBufferImpl* DoeWGPUCommandBuffer DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUCommandEncoderImpl* DoeWGPUCommandEncoder DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUComputePassEncoderImpl* DoeWGPUComputePassEncoder DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUComputePipelineImpl* DoeWGPUComputePipeline DoeWGPU_OBJECT_ATTRIBUTE;
/**
 * TODO
 *
 * Releasing the last ref to a `DoeWGPUDevice` also calls @ref DoewgpuDeviceDestroy.
 * For more info, see @ref DeviceRelease.
 */
typedef struct DoeWGPUDeviceImpl* DoeWGPUDevice DoeWGPU_OBJECT_ATTRIBUTE;
/**
 * A sampleable 2D texture that may perform 0-copy YUV sampling internally. Creation of @ref DoeWGPUExternalTexture is extremely implementation-dependent and not defined in this header.
 */
typedef struct DoeWGPUExternalTextureImpl* DoeWGPUExternalTexture DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUInstanceImpl* DoeWGPUInstance DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUPipelineLayoutImpl* DoeWGPUPipelineLayout DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUQuerySetImpl* DoeWGPUQuerySet DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUQueueImpl* DoeWGPUQueue DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPURenderBundleImpl* DoeWGPURenderBundle DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPURenderBundleEncoderImpl* DoeWGPURenderBundleEncoder DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPURenderPassEncoderImpl* DoeWGPURenderPassEncoder DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPURenderPipelineImpl* DoeWGPURenderPipeline DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUSamplerImpl* DoeWGPUSampler DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUShaderModuleImpl* DoeWGPUShaderModule DoeWGPU_OBJECT_ATTRIBUTE;
/**
 * An object used to continuously present image data to the user, see @ref Surfaces for more details.
 */
typedef struct DoeWGPUSurfaceImpl* DoeWGPUSurface DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUTextureImpl* DoeWGPUTexture DoeWGPU_OBJECT_ATTRIBUTE;
typedef struct DoeWGPUTextureViewImpl* DoeWGPUTextureView DoeWGPU_OBJECT_ATTRIBUTE;

/** @} */

// Structure forward declarations
struct DoeWGPUAdapterInfo;
struct DoeWGPUBlendComponent;
struct DoeWGPUBufferBindingLayout;
struct DoeWGPUBufferDescriptor;
struct DoeWGPUColor;
struct DoeWGPUCommandBufferDescriptor;
struct DoeWGPUCommandEncoderDescriptor;
struct DoeWGPUCompatibilityModeLimits;
struct DoeWGPUCompilationMessage;
struct DoeWGPUConstantEntry;
struct DoeWGPUExtent3D;
struct DoeWGPUExternalTextureBindingEntry;
struct DoeWGPUExternalTextureBindingLayout;
struct DoeWGPUFuture;
struct DoeWGPUInstanceLimits;
struct DoeWGPUMultisampleState;
struct DoeWGPUOrigin3D;
struct DoeWGPUPassTimestampWrites;
struct DoeWGPUPipelineLayoutDescriptor;
struct DoeWGPUPrimitiveState;
struct DoeWGPUQuerySetDescriptor;
struct DoeWGPUQueueDescriptor;
struct DoeWGPURenderBundleDescriptor;
struct DoeWGPURenderBundleEncoderDescriptor;
struct DoeWGPURenderPassDepthStencilAttachment;
struct DoeWGPURenderPassMaxDrawCount;
struct DoeWGPURequestAdapterWebXROptions;
struct DoeWGPUSamplerBindingLayout;
struct DoeWGPUSamplerDescriptor;
struct DoeWGPUShaderSourceSPIRV;
struct DoeWGPUShaderSourceWGSL;
struct DoeWGPUStencilFaceState;
struct DoeWGPUStorageTextureBindingLayout;
struct DoeWGPUSupportedFeatures;
struct DoeWGPUSupportedInstanceFeatures;
struct DoeWGPUSupportedWGSLLanguageFeatures;
struct DoeWGPUSurfaceCapabilities;
struct DoeWGPUSurfaceColorManagement;
struct DoeWGPUSurfaceConfiguration;
struct DoeWGPUSurfaceSourceAndroidNativeWindow;
struct DoeWGPUSurfaceSourceMetalLayer;
struct DoeWGPUSurfaceSourceWaylandSurface;
struct DoeWGPUSurfaceSourceWindowsHWND;
struct DoeWGPUSurfaceSourceXCBWindow;
struct DoeWGPUSurfaceSourceXlibWindow;
struct DoeWGPUSurfaceTexture;
struct DoeWGPUTexelCopyBufferLayout;
struct DoeWGPUTextureBindingLayout;
struct DoeWGPUTextureBindingViewDimension;
struct DoeWGPUTextureComponentSwizzle;
struct DoeWGPUVertexAttribute;
struct DoeWGPUBindGroupEntry;
struct DoeWGPUBindGroupLayoutEntry;
struct DoeWGPUBlendState;
struct DoeWGPUCompilationInfo;
struct DoeWGPUComputePassDescriptor;
struct DoeWGPUComputeState;
struct DoeWGPUDepthStencilState;
struct DoeWGPUFutureWaitInfo;
struct DoeWGPUInstanceDescriptor;
struct DoeWGPULimits;
struct DoeWGPURenderPassColorAttachment;
struct DoeWGPURequestAdapterOptions;
struct DoeWGPUShaderModuleDescriptor;
struct DoeWGPUSurfaceDescriptor;
struct DoeWGPUTexelCopyBufferInfo;
struct DoeWGPUTexelCopyTextureInfo;
struct DoeWGPUTextureComponentSwizzleDescriptor;
struct DoeWGPUTextureDescriptor;
struct DoeWGPUVertexBufferLayout;
struct DoeWGPUBindGroupDescriptor;
struct DoeWGPUBindGroupLayoutDescriptor;
struct DoeWGPUColorTargetState;
struct DoeWGPUComputePipelineDescriptor;
struct DoeWGPUDeviceDescriptor;
struct DoeWGPURenderPassDescriptor;
struct DoeWGPUTextureViewDescriptor;
struct DoeWGPUVertexState;
struct DoeWGPUFragmentState;
struct DoeWGPURenderPipelineDescriptor;

// Callback info structure forward declarations
struct DoeWGPUBufferMapCallbackInfo;
struct DoeWGPUCompilationInfoCallbackInfo;
struct DoeWGPUCreateComputePipelineAsyncCallbackInfo;
struct DoeWGPUCreateRenderPipelineAsyncCallbackInfo;
struct DoeWGPUDeviceLostCallbackInfo;
struct DoeWGPUPopErrorScopeCallbackInfo;
struct DoeWGPUQueueWorkDoneCallbackInfo;
struct DoeWGPURequestAdapterCallbackInfo;
struct DoeWGPURequestDeviceCallbackInfo;
struct DoeWGPUUncapturedErrorCallbackInfo;

/**
 * \defgroup Enumerations Enumerations
 * \brief Enums.
 *
 * @{
 */

typedef enum DoeWGPUAdapterType {
    DoeWGPUAdapterType_DiscreteGPU = 0x00000001,
    DoeWGPUAdapterType_IntegratedGPU = 0x00000002,
    DoeWGPUAdapterType_CPU = 0x00000003,
    DoeWGPUAdapterType_Unknown = 0x00000004,
    DoeWGPUAdapterType_Force32 = 0x7FFFFFFF
} DoeWGPUAdapterType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUAddressMode {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUAddressMode_Undefined = 0x00000000,
    DoeWGPUAddressMode_ClampToEdge = 0x00000001,
    DoeWGPUAddressMode_Repeat = 0x00000002,
    DoeWGPUAddressMode_MirrorRepeat = 0x00000003,
    DoeWGPUAddressMode_Force32 = 0x7FFFFFFF
} DoeWGPUAddressMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUBackendType {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUBackendType_Undefined = 0x00000000,
    DoeWGPUBackendType_Null = 0x00000001,
    DoeWGPUBackendType_WebGPU = 0x00000002,
    DoeWGPUBackendType_D3D11 = 0x00000003,
    DoeWGPUBackendType_D3D12 = 0x00000004,
    DoeWGPUBackendType_Metal = 0x00000005,
    DoeWGPUBackendType_Vulkan = 0x00000006,
    DoeWGPUBackendType_OpenGL = 0x00000007,
    DoeWGPUBackendType_OpenGLES = 0x00000008,
    DoeWGPUBackendType_Force32 = 0x7FFFFFFF
} DoeWGPUBackendType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUBlendFactor {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUBlendFactor_Undefined = 0x00000000,
    DoeWGPUBlendFactor_Zero = 0x00000001,
    DoeWGPUBlendFactor_One = 0x00000002,
    DoeWGPUBlendFactor_Src = 0x00000003,
    DoeWGPUBlendFactor_OneMinusSrc = 0x00000004,
    DoeWGPUBlendFactor_SrcAlpha = 0x00000005,
    DoeWGPUBlendFactor_OneMinusSrcAlpha = 0x00000006,
    DoeWGPUBlendFactor_Dst = 0x00000007,
    DoeWGPUBlendFactor_OneMinusDst = 0x00000008,
    DoeWGPUBlendFactor_DstAlpha = 0x00000009,
    DoeWGPUBlendFactor_OneMinusDstAlpha = 0x0000000A,
    DoeWGPUBlendFactor_SrcAlphaSaturated = 0x0000000B,
    DoeWGPUBlendFactor_Constant = 0x0000000C,
    DoeWGPUBlendFactor_OneMinusConstant = 0x0000000D,
    DoeWGPUBlendFactor_Src1 = 0x0000000E,
    DoeWGPUBlendFactor_OneMinusSrc1 = 0x0000000F,
    DoeWGPUBlendFactor_Src1Alpha = 0x00000010,
    DoeWGPUBlendFactor_OneMinusSrc1Alpha = 0x00000011,
    DoeWGPUBlendFactor_Force32 = 0x7FFFFFFF
} DoeWGPUBlendFactor DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUBlendOperation {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUBlendOperation_Undefined = 0x00000000,
    DoeWGPUBlendOperation_Add = 0x00000001,
    DoeWGPUBlendOperation_Subtract = 0x00000002,
    DoeWGPUBlendOperation_ReverseSubtract = 0x00000003,
    DoeWGPUBlendOperation_Min = 0x00000004,
    DoeWGPUBlendOperation_Max = 0x00000005,
    DoeWGPUBlendOperation_Force32 = 0x7FFFFFFF
} DoeWGPUBlendOperation DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUBufferBindingType {
    /**
     * `0`. Indicates that this @ref DoeWGPUBufferBindingLayout member of
     * its parent @ref DoeWGPUBindGroupLayoutEntry is not used.
     * (See also @ref SentinelValues.)
     */
    DoeWGPUBufferBindingType_BindingNotUsed = 0x00000000,
    /**
     * `1`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUBufferBindingType_Undefined = 0x00000001,
    DoeWGPUBufferBindingType_Uniform = 0x00000002,
    DoeWGPUBufferBindingType_Storage = 0x00000003,
    DoeWGPUBufferBindingType_ReadOnlyStorage = 0x00000004,
    DoeWGPUBufferBindingType_Force32 = 0x7FFFFFFF
} DoeWGPUBufferBindingType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUBufferMapState {
    DoeWGPUBufferMapState_Unmapped = 0x00000001,
    DoeWGPUBufferMapState_Pending = 0x00000002,
    DoeWGPUBufferMapState_Mapped = 0x00000003,
    DoeWGPUBufferMapState_Force32 = 0x7FFFFFFF
} DoeWGPUBufferMapState DoeWGPU_ENUM_ATTRIBUTE;

/**
 * The callback mode controls how a callback for an asynchronous operation may be fired. See @ref Asynchronous-Operations for how these are used.
 */
typedef enum DoeWGPUCallbackMode {
    /**
     * Callbacks created with `DoeWGPUCallbackMode_WaitAnyOnly`:
     * - fire when the asynchronous operation's future is passed to a call to @ref DoewgpuInstanceWaitAny
     *   AND the operation has already completed or it completes inside the call to @ref DoewgpuInstanceWaitAny.
     */
    DoeWGPUCallbackMode_WaitAnyOnly = 0x00000001,
    /**
     * Callbacks created with `DoeWGPUCallbackMode_AllowProcessEvents`:
     * - fire for the same reasons as callbacks created with `DoeWGPUCallbackMode_WaitAnyOnly`
     * - fire inside a call to @ref DoewgpuInstanceProcessEvents if the asynchronous operation is complete.
     */
    DoeWGPUCallbackMode_AllowProcessEvents = 0x00000002,
    /**
     * Callbacks created with `DoeWGPUCallbackMode_AllowSpontaneous`:
     * - fire for the same reasons as callbacks created with `DoeWGPUCallbackMode_AllowProcessEvents`
     * - **may** fire spontaneously on an arbitrary or application thread, when the WebGPU implementations discovers that the asynchronous operation is complete.
     *
     *   Implementations _should_ fire spontaneous callbacks as soon as possible.
     *
     * @note Because spontaneous callbacks may fire at an arbitrary time on an arbitrary thread, applications should take extra care when acquiring locks or mutating state inside the callback. It undefined behavior to re-entrantly call into the webgpu.h API if the callback fires while inside the callstack of another webgpu.h function that is not `DoewgpuInstanceWaitAny` or `DoewgpuInstanceProcessEvents`.
     */
    DoeWGPUCallbackMode_AllowSpontaneous = 0x00000003,
    DoeWGPUCallbackMode_Force32 = 0x7FFFFFFF
} DoeWGPUCallbackMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUCompareFunction {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUCompareFunction_Undefined = 0x00000000,
    DoeWGPUCompareFunction_Never = 0x00000001,
    DoeWGPUCompareFunction_Less = 0x00000002,
    DoeWGPUCompareFunction_Equal = 0x00000003,
    DoeWGPUCompareFunction_LessEqual = 0x00000004,
    DoeWGPUCompareFunction_Greater = 0x00000005,
    DoeWGPUCompareFunction_NotEqual = 0x00000006,
    DoeWGPUCompareFunction_GreaterEqual = 0x00000007,
    DoeWGPUCompareFunction_Always = 0x00000008,
    DoeWGPUCompareFunction_Force32 = 0x7FFFFFFF
} DoeWGPUCompareFunction DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUCompilationInfoRequestStatus {
    DoeWGPUCompilationInfoRequestStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUCompilationInfoRequestStatus_CallbackCancelled = 0x00000002,
    DoeWGPUCompilationInfoRequestStatus_Force32 = 0x7FFFFFFF
} DoeWGPUCompilationInfoRequestStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUCompilationMessageType {
    DoeWGPUCompilationMessageType_Error = 0x00000001,
    DoeWGPUCompilationMessageType_Warning = 0x00000002,
    DoeWGPUCompilationMessageType_Info = 0x00000003,
    DoeWGPUCompilationMessageType_Force32 = 0x7FFFFFFF
} DoeWGPUCompilationMessageType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUComponentSwizzle {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUComponentSwizzle_Undefined = 0x00000000,
    /**
     * Force its value to 0.
     */
    DoeWGPUComponentSwizzle_Zero = 0x00000001,
    /**
     * Force its value to 1.
     */
    DoeWGPUComponentSwizzle_One = 0x00000002,
    /**
     * Take its value from the red channel of the texture.
     */
    DoeWGPUComponentSwizzle_R = 0x00000003,
    /**
     * Take its value from the green channel of the texture.
     */
    DoeWGPUComponentSwizzle_G = 0x00000004,
    /**
     * Take its value from the blue channel of the texture.
     */
    DoeWGPUComponentSwizzle_B = 0x00000005,
    /**
     * Take its value from the alpha channel of the texture.
     */
    DoeWGPUComponentSwizzle_A = 0x00000006,
    DoeWGPUComponentSwizzle_Force32 = 0x7FFFFFFF
} DoeWGPUComponentSwizzle DoeWGPU_ENUM_ATTRIBUTE;

/**
 * Describes how frames are composited with other contents on the screen when @ref DoewgpuSurfacePresent is called.
 */
typedef enum DoeWGPUCompositeAlphaMode {
    /**
     * `0`. Lets the WebGPU implementation choose the best mode (supported, and with the best performance) between @ref DoeWGPUCompositeAlphaMode_Opaque or @ref DoeWGPUCompositeAlphaMode_Inherit.
     */
    DoeWGPUCompositeAlphaMode_Auto = 0x00000000,
    /**
     * The alpha component of the image is ignored and teated as if it is always 1.0.
     */
    DoeWGPUCompositeAlphaMode_Opaque = 0x00000001,
    /**
     * The alpha component is respected and non-alpha components are assumed to be already multiplied with the alpha component. For example, (0.5, 0, 0, 0.5) is semi-transparent bright red.
     */
    DoeWGPUCompositeAlphaMode_Premultiplied = 0x00000002,
    /**
     * The alpha component is respected and non-alpha components are assumed to NOT be already multiplied with the alpha component. For example, (1.0, 0, 0, 0.5) is semi-transparent bright red.
     */
    DoeWGPUCompositeAlphaMode_Unpremultiplied = 0x00000003,
    /**
     * The handling of the alpha component is unknown to WebGPU and should be handled by the application using system-specific APIs. This mode may be unavailable (for example on Wasm).
     */
    DoeWGPUCompositeAlphaMode_Inherit = 0x00000004,
    DoeWGPUCompositeAlphaMode_Force32 = 0x7FFFFFFF
} DoeWGPUCompositeAlphaMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUCreatePipelineAsyncStatus {
    DoeWGPUCreatePipelineAsyncStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUCreatePipelineAsyncStatus_CallbackCancelled = 0x00000002,
    DoeWGPUCreatePipelineAsyncStatus_ValidationError = 0x00000003,
    DoeWGPUCreatePipelineAsyncStatus_InternalError = 0x00000004,
    DoeWGPUCreatePipelineAsyncStatus_Force32 = 0x7FFFFFFF
} DoeWGPUCreatePipelineAsyncStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUCullMode {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUCullMode_Undefined = 0x00000000,
    DoeWGPUCullMode_None = 0x00000001,
    DoeWGPUCullMode_Front = 0x00000002,
    DoeWGPUCullMode_Back = 0x00000003,
    DoeWGPUCullMode_Force32 = 0x7FFFFFFF
} DoeWGPUCullMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUDeviceLostReason {
    DoeWGPUDeviceLostReason_Unknown = 0x00000001,
    DoeWGPUDeviceLostReason_Destroyed = 0x00000002,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUDeviceLostReason_CallbackCancelled = 0x00000003,
    DoeWGPUDeviceLostReason_FailedCreation = 0x00000004,
    DoeWGPUDeviceLostReason_Force32 = 0x7FFFFFFF
} DoeWGPUDeviceLostReason DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUErrorFilter {
    DoeWGPUErrorFilter_Validation = 0x00000001,
    DoeWGPUErrorFilter_OutOfMemory = 0x00000002,
    DoeWGPUErrorFilter_Internal = 0x00000003,
    DoeWGPUErrorFilter_Force32 = 0x7FFFFFFF
} DoeWGPUErrorFilter DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUErrorType {
    DoeWGPUErrorType_NoError = 0x00000001,
    DoeWGPUErrorType_Validation = 0x00000002,
    DoeWGPUErrorType_OutOfMemory = 0x00000003,
    DoeWGPUErrorType_Internal = 0x00000004,
    DoeWGPUErrorType_Unknown = 0x00000005,
    DoeWGPUErrorType_Force32 = 0x7FFFFFFF
} DoeWGPUErrorType DoeWGPU_ENUM_ATTRIBUTE;

/**
 * See @ref DoeWGPURequestAdapterOptions::featureLevel.
 */
typedef enum DoeWGPUFeatureLevel {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUFeatureLevel_Undefined = 0x00000000,
    /**
     * "Compatibility" profile which can be supported on OpenGL ES 3.1 and D3D11.
     */
    DoeWGPUFeatureLevel_Compatibility = 0x00000001,
    /**
     * "Core" profile which can be supported on Vulkan/Metal/D3D12 (at least).
     */
    DoeWGPUFeatureLevel_Core = 0x00000002,
    DoeWGPUFeatureLevel_Force32 = 0x7FFFFFFF
} DoeWGPUFeatureLevel DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUFeatureName {
    DoeWGPUFeatureName_CoreFeaturesAndLimits = 0x00000001,
    DoeWGPUFeatureName_DepthClipControl = 0x00000002,
    DoeWGPUFeatureName_Depth32FloatStencil8 = 0x00000003,
    DoeWGPUFeatureName_TextureCompressionBC = 0x00000004,
    DoeWGPUFeatureName_TextureCompressionBCSliced3D = 0x00000005,
    DoeWGPUFeatureName_TextureCompressionETC2 = 0x00000006,
    DoeWGPUFeatureName_TextureCompressionASTC = 0x00000007,
    DoeWGPUFeatureName_TextureCompressionASTCSliced3D = 0x00000008,
    DoeWGPUFeatureName_TimestampQuery = 0x00000009,
    DoeWGPUFeatureName_IndirectFirstInstance = 0x0000000A,
    DoeWGPUFeatureName_ShaderF16 = 0x0000000B,
    DoeWGPUFeatureName_RG11B10UfloatRenderable = 0x0000000C,
    DoeWGPUFeatureName_BGRA8UnormStorage = 0x0000000D,
    DoeWGPUFeatureName_Float32Filterable = 0x0000000E,
    DoeWGPUFeatureName_Float32Blendable = 0x0000000F,
    DoeWGPUFeatureName_ClipDistances = 0x00000010,
    DoeWGPUFeatureName_DualSourceBlending = 0x00000011,
    DoeWGPUFeatureName_Subgroups = 0x00000012,
    DoeWGPUFeatureName_TextureFormatsTier1 = 0x00000013,
    DoeWGPUFeatureName_TextureFormatsTier2 = 0x00000014,
    DoeWGPUFeatureName_PrimitiveIndex = 0x00000015,
    DoeWGPUFeatureName_TextureComponentSwizzle = 0x00000016,
    DoeWGPUFeatureName_SubgroupSizeControl = 0x00000017,
    DoeWGPUFeatureName_Force32 = 0x7FFFFFFF
} DoeWGPUFeatureName DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUFilterMode {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUFilterMode_Undefined = 0x00000000,
    DoeWGPUFilterMode_Nearest = 0x00000001,
    DoeWGPUFilterMode_Linear = 0x00000002,
    DoeWGPUFilterMode_Force32 = 0x7FFFFFFF
} DoeWGPUFilterMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUFrontFace {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUFrontFace_Undefined = 0x00000000,
    DoeWGPUFrontFace_CCW = 0x00000001,
    DoeWGPUFrontFace_CW = 0x00000002,
    DoeWGPUFrontFace_Force32 = 0x7FFFFFFF
} DoeWGPUFrontFace DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUIndexFormat {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUIndexFormat_Undefined = 0x00000000,
    DoeWGPUIndexFormat_Uint16 = 0x00000001,
    DoeWGPUIndexFormat_Uint32 = 0x00000002,
    DoeWGPUIndexFormat_Force32 = 0x7FFFFFFF
} DoeWGPUIndexFormat DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUInstanceFeatureName {
    /**
     * Enable use of ::DoewgpuInstanceWaitAny with `timeoutNS > 0`.
     */
    DoeWGPUInstanceFeatureName_TimedWaitAny = 0x00000001,
    /**
     * Enable passing SPIR-V shaders to @ref DoewgpuDeviceCreateShaderModule,
     * via @ref DoeWGPUShaderSourceSPIRV.
     */
    DoeWGPUInstanceFeatureName_ShaderSourceSPIRV = 0x00000002,
    /**
     * Normally, a @ref DoeWGPUAdapter can only create a single device. If this is
     * available and enabled, then adapters won't immediately expire when they
     * create a device, so can be reused to make multiple devices. They may
     * still expire for other reasons.
     */
    DoeWGPUInstanceFeatureName_MultipleDevicesPerAdapter = 0x00000003,
    DoeWGPUInstanceFeatureName_Force32 = 0x7FFFFFFF
} DoeWGPUInstanceFeatureName DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPULoadOp {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPULoadOp_Undefined = 0x00000000,
    DoeWGPULoadOp_Load = 0x00000001,
    DoeWGPULoadOp_Clear = 0x00000002,
    DoeWGPULoadOp_Force32 = 0x7FFFFFFF
} DoeWGPULoadOp DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUMapAsyncStatus {
    DoeWGPUMapAsyncStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUMapAsyncStatus_CallbackCancelled = 0x00000002,
    DoeWGPUMapAsyncStatus_Error = 0x00000003,
    DoeWGPUMapAsyncStatus_Aborted = 0x00000004,
    DoeWGPUMapAsyncStatus_Force32 = 0x7FFFFFFF
} DoeWGPUMapAsyncStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUMipmapFilterMode {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUMipmapFilterMode_Undefined = 0x00000000,
    DoeWGPUMipmapFilterMode_Nearest = 0x00000001,
    DoeWGPUMipmapFilterMode_Linear = 0x00000002,
    DoeWGPUMipmapFilterMode_Force32 = 0x7FFFFFFF
} DoeWGPUMipmapFilterMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUOptionalBool {
    /**
     * `0`.
     */
    DoeWGPUOptionalBool_False = 0x00000000,
    DoeWGPUOptionalBool_True = 0x00000001,
    DoeWGPUOptionalBool_Undefined = 0x00000002,
    DoeWGPUOptionalBool_Force32 = 0x7FFFFFFF
} DoeWGPUOptionalBool DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUPopErrorScopeStatus {
    /**
     * The error scope stack was successfully popped and a result was reported.
     */
    DoeWGPUPopErrorScopeStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUPopErrorScopeStatus_CallbackCancelled = 0x00000002,
    /**
     * The error scope stack could not be popped, because it was empty.
     */
    DoeWGPUPopErrorScopeStatus_Error = 0x00000003,
    DoeWGPUPopErrorScopeStatus_Force32 = 0x7FFFFFFF
} DoeWGPUPopErrorScopeStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUPowerPreference {
    /**
     * `0`. No preference. (See also @ref SentinelValues.)
     */
    DoeWGPUPowerPreference_Undefined = 0x00000000,
    DoeWGPUPowerPreference_LowPower = 0x00000001,
    DoeWGPUPowerPreference_HighPerformance = 0x00000002,
    DoeWGPUPowerPreference_Force32 = 0x7FFFFFFF
} DoeWGPUPowerPreference DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUPredefinedColorSpace {
    DoeWGPUPredefinedColorSpace_SRGB = 0x00000001,
    DoeWGPUPredefinedColorSpace_DisplayP3 = 0x00000002,
    DoeWGPUPredefinedColorSpace_Force32 = 0x7FFFFFFF
} DoeWGPUPredefinedColorSpace DoeWGPU_ENUM_ATTRIBUTE;

/**
 * Describes when and in which order frames are presented on the screen when @ref DoewgpuSurfacePresent is called.
 */
typedef enum DoeWGPUPresentMode {
    /**
     * `0`. Present mode is not specified. Use the default.
     */
    DoeWGPUPresentMode_Undefined = 0x00000000,
    /**
     * The presentation of the image to the user waits for the next vertical blanking period to update in a first-in, first-out manner.
     * Tearing cannot be observed and frame-loop will be limited to the display's refresh rate.
     * This is the only mode that's always available.
     */
    DoeWGPUPresentMode_Fifo = 0x00000001,
    /**
     * The presentation of the image to the user tries to wait for the next vertical blanking period but may decide to not wait if a frame is presented late.
     * Tearing can sometimes be observed but late-frame don't produce a full-frame stutter in the presentation.
     * This is still a first-in, first-out mechanism so a frame-loop will be limited to the display's refresh rate.
     */
    DoeWGPUPresentMode_FifoRelaxed = 0x00000002,
    /**
     * The presentation of the image to the user is updated immediately without waiting for a vertical blank.
     * Tearing can be observed but latency is minimized.
     */
    DoeWGPUPresentMode_Immediate = 0x00000003,
    /**
     * The presentation of the image to the user waits for the next vertical blanking period to update to the latest provided image.
     * Tearing cannot be observed and a frame-loop is not limited to the display's refresh rate.
     */
    DoeWGPUPresentMode_Mailbox = 0x00000004,
    DoeWGPUPresentMode_Force32 = 0x7FFFFFFF
} DoeWGPUPresentMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUPrimitiveTopology {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUPrimitiveTopology_Undefined = 0x00000000,
    DoeWGPUPrimitiveTopology_PointList = 0x00000001,
    DoeWGPUPrimitiveTopology_LineList = 0x00000002,
    DoeWGPUPrimitiveTopology_LineStrip = 0x00000003,
    DoeWGPUPrimitiveTopology_TriangleList = 0x00000004,
    DoeWGPUPrimitiveTopology_TriangleStrip = 0x00000005,
    DoeWGPUPrimitiveTopology_Force32 = 0x7FFFFFFF
} DoeWGPUPrimitiveTopology DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUQueryType {
    DoeWGPUQueryType_Occlusion = 0x00000001,
    DoeWGPUQueryType_Timestamp = 0x00000002,
    DoeWGPUQueryType_Force32 = 0x7FFFFFFF
} DoeWGPUQueryType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUQueueWorkDoneStatus {
    DoeWGPUQueueWorkDoneStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPUQueueWorkDoneStatus_CallbackCancelled = 0x00000002,
    /**
     * There was some deterministic error. (Note this is currently never used,
     * but it will be relevant when it's possible to create a queue object.)
     */
    DoeWGPUQueueWorkDoneStatus_Error = 0x00000003,
    DoeWGPUQueueWorkDoneStatus_Force32 = 0x7FFFFFFF
} DoeWGPUQueueWorkDoneStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPURequestAdapterStatus {
    DoeWGPURequestAdapterStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPURequestAdapterStatus_CallbackCancelled = 0x00000002,
    DoeWGPURequestAdapterStatus_Unavailable = 0x00000003,
    DoeWGPURequestAdapterStatus_Error = 0x00000004,
    DoeWGPURequestAdapterStatus_Force32 = 0x7FFFFFFF
} DoeWGPURequestAdapterStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPURequestDeviceStatus {
    DoeWGPURequestDeviceStatus_Success = 0x00000001,
    /**
     * See @ref CallbackStatuses.
     */
    DoeWGPURequestDeviceStatus_CallbackCancelled = 0x00000002,
    DoeWGPURequestDeviceStatus_Error = 0x00000003,
    DoeWGPURequestDeviceStatus_Force32 = 0x7FFFFFFF
} DoeWGPURequestDeviceStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUSamplerBindingType {
    /**
     * `0`. Indicates that this @ref DoeWGPUSamplerBindingLayout member of
     * its parent @ref DoeWGPUBindGroupLayoutEntry is not used.
     * (See also @ref SentinelValues.)
     */
    DoeWGPUSamplerBindingType_BindingNotUsed = 0x00000000,
    /**
     * `1`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUSamplerBindingType_Undefined = 0x00000001,
    DoeWGPUSamplerBindingType_Filtering = 0x00000002,
    DoeWGPUSamplerBindingType_NonFiltering = 0x00000003,
    DoeWGPUSamplerBindingType_Comparison = 0x00000004,
    DoeWGPUSamplerBindingType_Force32 = 0x7FFFFFFF
} DoeWGPUSamplerBindingType DoeWGPU_ENUM_ATTRIBUTE;

/**
 * Status code returned (synchronously) from many operations. Generally
 * indicates an invalid input like an unknown enum value or @ref OutStructChainError.
 * Read the function's documentation for specific error conditions.
 */
typedef enum DoeWGPUStatus {
    DoeWGPUStatus_Success = 0x00000001,
    DoeWGPUStatus_Error = 0x00000002,
    DoeWGPUStatus_Force32 = 0x7FFFFFFF
} DoeWGPUStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUStencilOperation {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUStencilOperation_Undefined = 0x00000000,
    DoeWGPUStencilOperation_Keep = 0x00000001,
    DoeWGPUStencilOperation_Zero = 0x00000002,
    DoeWGPUStencilOperation_Replace = 0x00000003,
    DoeWGPUStencilOperation_Invert = 0x00000004,
    DoeWGPUStencilOperation_IncrementClamp = 0x00000005,
    DoeWGPUStencilOperation_DecrementClamp = 0x00000006,
    DoeWGPUStencilOperation_IncrementWrap = 0x00000007,
    DoeWGPUStencilOperation_DecrementWrap = 0x00000008,
    DoeWGPUStencilOperation_Force32 = 0x7FFFFFFF
} DoeWGPUStencilOperation DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUStorageTextureAccess {
    /**
     * `0`. Indicates that this @ref DoeWGPUStorageTextureBindingLayout member of
     * its parent @ref DoeWGPUBindGroupLayoutEntry is not used.
     * (See also @ref SentinelValues.)
     */
    DoeWGPUStorageTextureAccess_BindingNotUsed = 0x00000000,
    /**
     * `1`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUStorageTextureAccess_Undefined = 0x00000001,
    DoeWGPUStorageTextureAccess_WriteOnly = 0x00000002,
    DoeWGPUStorageTextureAccess_ReadOnly = 0x00000003,
    DoeWGPUStorageTextureAccess_ReadWrite = 0x00000004,
    DoeWGPUStorageTextureAccess_Force32 = 0x7FFFFFFF
} DoeWGPUStorageTextureAccess DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUStoreOp {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUStoreOp_Undefined = 0x00000000,
    DoeWGPUStoreOp_Store = 0x00000001,
    DoeWGPUStoreOp_Discard = 0x00000002,
    DoeWGPUStoreOp_Force32 = 0x7FFFFFFF
} DoeWGPUStoreOp DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUSType {
    DoeWGPUSType_ShaderSourceSPIRV = 0x00000001,
    DoeWGPUSType_ShaderSourceWGSL = 0x00000002,
    DoeWGPUSType_RenderPassMaxDrawCount = 0x00000003,
    DoeWGPUSType_SurfaceSourceMetalLayer = 0x00000004,
    DoeWGPUSType_SurfaceSourceWindowsHWND = 0x00000005,
    DoeWGPUSType_SurfaceSourceXlibWindow = 0x00000006,
    DoeWGPUSType_SurfaceSourceWaylandSurface = 0x00000007,
    DoeWGPUSType_SurfaceSourceAndroidNativeWindow = 0x00000008,
    DoeWGPUSType_SurfaceSourceXCBWindow = 0x00000009,
    DoeWGPUSType_SurfaceColorManagement = 0x0000000A,
    DoeWGPUSType_RequestAdapterWebXROptions = 0x0000000B,
    DoeWGPUSType_TextureComponentSwizzleDescriptor = 0x0000000C,
    DoeWGPUSType_ExternalTextureBindingLayout = 0x0000000D,
    DoeWGPUSType_ExternalTextureBindingEntry = 0x0000000E,
    DoeWGPUSType_CompatibilityModeLimits = 0x0000000F,
    DoeWGPUSType_TextureBindingViewDimension = 0x00000010,
    DoeWGPUSType_Force32 = 0x7FFFFFFF
} DoeWGPUSType DoeWGPU_ENUM_ATTRIBUTE;

/**
 * The status enum for @ref DoewgpuSurfaceGetCurrentTexture.
 */
typedef enum DoeWGPUSurfaceGetCurrentTextureStatus {
    /**
     * Yay! Everything is good and we can render this frame.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_SuccessOptimal = 0x00000001,
    /**
     * Still OK - the surface can present the frame, but in a suboptimal way. The surface may need reconfiguration.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_SuccessSuboptimal = 0x00000002,
    /**
     * Some operation timed out while trying to acquire the frame.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_Timeout = 0x00000003,
    /**
     * The surface is too different to be used, compared to when it was originally created.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_Outdated = 0x00000004,
    /**
     * The connection to whatever owns the surface was lost, or generally needs to be fully reinitialized.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_Lost = 0x00000005,
    /**
     * There was some deterministic error (for example, the surface is not configured, or there was an @ref OutStructChainError). Should produce @ref ImplementationDefinedLogging containing details.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus_Error = 0x00000006,
    DoeWGPUSurfaceGetCurrentTextureStatus_Force32 = 0x7FFFFFFF
} DoeWGPUSurfaceGetCurrentTextureStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUTextureAspect {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUTextureAspect_Undefined = 0x00000000,
    DoeWGPUTextureAspect_All = 0x00000001,
    DoeWGPUTextureAspect_StencilOnly = 0x00000002,
    DoeWGPUTextureAspect_DepthOnly = 0x00000003,
    DoeWGPUTextureAspect_Force32 = 0x7FFFFFFF
} DoeWGPUTextureAspect DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUTextureDimension {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUTextureDimension_Undefined = 0x00000000,
    DoeWGPUTextureDimension_1D = 0x00000001,
    DoeWGPUTextureDimension_2D = 0x00000002,
    DoeWGPUTextureDimension_3D = 0x00000003,
    DoeWGPUTextureDimension_Force32 = 0x7FFFFFFF
} DoeWGPUTextureDimension DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUTextureFormat {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUTextureFormat_Undefined = 0x00000000,
    DoeWGPUTextureFormat_R8Unorm = 0x00000001,
    DoeWGPUTextureFormat_R8Snorm = 0x00000002,
    DoeWGPUTextureFormat_R8Uint = 0x00000003,
    DoeWGPUTextureFormat_R8Sint = 0x00000004,
    DoeWGPUTextureFormat_R16Unorm = 0x00000005,
    DoeWGPUTextureFormat_R16Snorm = 0x00000006,
    DoeWGPUTextureFormat_R16Uint = 0x00000007,
    DoeWGPUTextureFormat_R16Sint = 0x00000008,
    DoeWGPUTextureFormat_R16Float = 0x00000009,
    DoeWGPUTextureFormat_RG8Unorm = 0x0000000A,
    DoeWGPUTextureFormat_RG8Snorm = 0x0000000B,
    DoeWGPUTextureFormat_RG8Uint = 0x0000000C,
    DoeWGPUTextureFormat_RG8Sint = 0x0000000D,
    DoeWGPUTextureFormat_R32Float = 0x0000000E,
    DoeWGPUTextureFormat_R32Uint = 0x0000000F,
    DoeWGPUTextureFormat_R32Sint = 0x00000010,
    DoeWGPUTextureFormat_RG16Unorm = 0x00000011,
    DoeWGPUTextureFormat_RG16Snorm = 0x00000012,
    DoeWGPUTextureFormat_RG16Uint = 0x00000013,
    DoeWGPUTextureFormat_RG16Sint = 0x00000014,
    DoeWGPUTextureFormat_RG16Float = 0x00000015,
    DoeWGPUTextureFormat_RGBA8Unorm = 0x00000016,
    DoeWGPUTextureFormat_RGBA8UnormSrgb = 0x00000017,
    DoeWGPUTextureFormat_RGBA8Snorm = 0x00000018,
    DoeWGPUTextureFormat_RGBA8Uint = 0x00000019,
    DoeWGPUTextureFormat_RGBA8Sint = 0x0000001A,
    DoeWGPUTextureFormat_BGRA8Unorm = 0x0000001B,
    DoeWGPUTextureFormat_BGRA8UnormSrgb = 0x0000001C,
    DoeWGPUTextureFormat_RGB10A2Uint = 0x0000001D,
    DoeWGPUTextureFormat_RGB10A2Unorm = 0x0000001E,
    DoeWGPUTextureFormat_RG11B10Ufloat = 0x0000001F,
    DoeWGPUTextureFormat_RGB9E5Ufloat = 0x00000020,
    DoeWGPUTextureFormat_RG32Float = 0x00000021,
    DoeWGPUTextureFormat_RG32Uint = 0x00000022,
    DoeWGPUTextureFormat_RG32Sint = 0x00000023,
    DoeWGPUTextureFormat_RGBA16Unorm = 0x00000024,
    DoeWGPUTextureFormat_RGBA16Snorm = 0x00000025,
    DoeWGPUTextureFormat_RGBA16Uint = 0x00000026,
    DoeWGPUTextureFormat_RGBA16Sint = 0x00000027,
    DoeWGPUTextureFormat_RGBA16Float = 0x00000028,
    DoeWGPUTextureFormat_RGBA32Float = 0x00000029,
    DoeWGPUTextureFormat_RGBA32Uint = 0x0000002A,
    DoeWGPUTextureFormat_RGBA32Sint = 0x0000002B,
    DoeWGPUTextureFormat_Stencil8 = 0x0000002C,
    DoeWGPUTextureFormat_Depth16Unorm = 0x0000002D,
    DoeWGPUTextureFormat_Depth24Plus = 0x0000002E,
    DoeWGPUTextureFormat_Depth24PlusStencil8 = 0x0000002F,
    DoeWGPUTextureFormat_Depth32Float = 0x00000030,
    DoeWGPUTextureFormat_Depth32FloatStencil8 = 0x00000031,
    DoeWGPUTextureFormat_BC1RGBAUnorm = 0x00000032,
    DoeWGPUTextureFormat_BC1RGBAUnormSrgb = 0x00000033,
    DoeWGPUTextureFormat_BC2RGBAUnorm = 0x00000034,
    DoeWGPUTextureFormat_BC2RGBAUnormSrgb = 0x00000035,
    DoeWGPUTextureFormat_BC3RGBAUnorm = 0x00000036,
    DoeWGPUTextureFormat_BC3RGBAUnormSrgb = 0x00000037,
    DoeWGPUTextureFormat_BC4RUnorm = 0x00000038,
    DoeWGPUTextureFormat_BC4RSnorm = 0x00000039,
    DoeWGPUTextureFormat_BC5RGUnorm = 0x0000003A,
    DoeWGPUTextureFormat_BC5RGSnorm = 0x0000003B,
    DoeWGPUTextureFormat_BC6HRGBUfloat = 0x0000003C,
    DoeWGPUTextureFormat_BC6HRGBFloat = 0x0000003D,
    DoeWGPUTextureFormat_BC7RGBAUnorm = 0x0000003E,
    DoeWGPUTextureFormat_BC7RGBAUnormSrgb = 0x0000003F,
    DoeWGPUTextureFormat_ETC2RGB8Unorm = 0x00000040,
    DoeWGPUTextureFormat_ETC2RGB8UnormSrgb = 0x00000041,
    DoeWGPUTextureFormat_ETC2RGB8A1Unorm = 0x00000042,
    DoeWGPUTextureFormat_ETC2RGB8A1UnormSrgb = 0x00000043,
    DoeWGPUTextureFormat_ETC2RGBA8Unorm = 0x00000044,
    DoeWGPUTextureFormat_ETC2RGBA8UnormSrgb = 0x00000045,
    DoeWGPUTextureFormat_EACR11Unorm = 0x00000046,
    DoeWGPUTextureFormat_EACR11Snorm = 0x00000047,
    DoeWGPUTextureFormat_EACRG11Unorm = 0x00000048,
    DoeWGPUTextureFormat_EACRG11Snorm = 0x00000049,
    DoeWGPUTextureFormat_ASTC4x4Unorm = 0x0000004A,
    DoeWGPUTextureFormat_ASTC4x4UnormSrgb = 0x0000004B,
    DoeWGPUTextureFormat_ASTC5x4Unorm = 0x0000004C,
    DoeWGPUTextureFormat_ASTC5x4UnormSrgb = 0x0000004D,
    DoeWGPUTextureFormat_ASTC5x5Unorm = 0x0000004E,
    DoeWGPUTextureFormat_ASTC5x5UnormSrgb = 0x0000004F,
    DoeWGPUTextureFormat_ASTC6x5Unorm = 0x00000050,
    DoeWGPUTextureFormat_ASTC6x5UnormSrgb = 0x00000051,
    DoeWGPUTextureFormat_ASTC6x6Unorm = 0x00000052,
    DoeWGPUTextureFormat_ASTC6x6UnormSrgb = 0x00000053,
    DoeWGPUTextureFormat_ASTC8x5Unorm = 0x00000054,
    DoeWGPUTextureFormat_ASTC8x5UnormSrgb = 0x00000055,
    DoeWGPUTextureFormat_ASTC8x6Unorm = 0x00000056,
    DoeWGPUTextureFormat_ASTC8x6UnormSrgb = 0x00000057,
    DoeWGPUTextureFormat_ASTC8x8Unorm = 0x00000058,
    DoeWGPUTextureFormat_ASTC8x8UnormSrgb = 0x00000059,
    DoeWGPUTextureFormat_ASTC10x5Unorm = 0x0000005A,
    DoeWGPUTextureFormat_ASTC10x5UnormSrgb = 0x0000005B,
    DoeWGPUTextureFormat_ASTC10x6Unorm = 0x0000005C,
    DoeWGPUTextureFormat_ASTC10x6UnormSrgb = 0x0000005D,
    DoeWGPUTextureFormat_ASTC10x8Unorm = 0x0000005E,
    DoeWGPUTextureFormat_ASTC10x8UnormSrgb = 0x0000005F,
    DoeWGPUTextureFormat_ASTC10x10Unorm = 0x00000060,
    DoeWGPUTextureFormat_ASTC10x10UnormSrgb = 0x00000061,
    DoeWGPUTextureFormat_ASTC12x10Unorm = 0x00000062,
    DoeWGPUTextureFormat_ASTC12x10UnormSrgb = 0x00000063,
    DoeWGPUTextureFormat_ASTC12x12Unorm = 0x00000064,
    DoeWGPUTextureFormat_ASTC12x12UnormSrgb = 0x00000065,
    DoeWGPUTextureFormat_Force32 = 0x7FFFFFFF
} DoeWGPUTextureFormat DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUTextureSampleType {
    /**
     * `0`. Indicates that this @ref DoeWGPUTextureBindingLayout member of
     * its parent @ref DoeWGPUBindGroupLayoutEntry is not used.
     * (See also @ref SentinelValues.)
     */
    DoeWGPUTextureSampleType_BindingNotUsed = 0x00000000,
    /**
     * `1`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUTextureSampleType_Undefined = 0x00000001,
    DoeWGPUTextureSampleType_Float = 0x00000002,
    DoeWGPUTextureSampleType_UnfilterableFloat = 0x00000003,
    DoeWGPUTextureSampleType_Depth = 0x00000004,
    DoeWGPUTextureSampleType_Sint = 0x00000005,
    DoeWGPUTextureSampleType_Uint = 0x00000006,
    DoeWGPUTextureSampleType_Force32 = 0x7FFFFFFF
} DoeWGPUTextureSampleType DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUTextureViewDimension {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUTextureViewDimension_Undefined = 0x00000000,
    DoeWGPUTextureViewDimension_1D = 0x00000001,
    DoeWGPUTextureViewDimension_2D = 0x00000002,
    DoeWGPUTextureViewDimension_2DArray = 0x00000003,
    DoeWGPUTextureViewDimension_Cube = 0x00000004,
    DoeWGPUTextureViewDimension_CubeArray = 0x00000005,
    DoeWGPUTextureViewDimension_3D = 0x00000006,
    DoeWGPUTextureViewDimension_Force32 = 0x7FFFFFFF
} DoeWGPUTextureViewDimension DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUToneMappingMode {
    DoeWGPUToneMappingMode_Standard = 0x00000001,
    DoeWGPUToneMappingMode_Extended = 0x00000002,
    DoeWGPUToneMappingMode_Force32 = 0x7FFFFFFF
} DoeWGPUToneMappingMode DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUVertexFormat {
    DoeWGPUVertexFormat_Uint8 = 0x00000001,
    DoeWGPUVertexFormat_Uint8x2 = 0x00000002,
    DoeWGPUVertexFormat_Uint8x4 = 0x00000003,
    DoeWGPUVertexFormat_Sint8 = 0x00000004,
    DoeWGPUVertexFormat_Sint8x2 = 0x00000005,
    DoeWGPUVertexFormat_Sint8x4 = 0x00000006,
    DoeWGPUVertexFormat_Unorm8 = 0x00000007,
    DoeWGPUVertexFormat_Unorm8x2 = 0x00000008,
    DoeWGPUVertexFormat_Unorm8x4 = 0x00000009,
    DoeWGPUVertexFormat_Snorm8 = 0x0000000A,
    DoeWGPUVertexFormat_Snorm8x2 = 0x0000000B,
    DoeWGPUVertexFormat_Snorm8x4 = 0x0000000C,
    DoeWGPUVertexFormat_Uint16 = 0x0000000D,
    DoeWGPUVertexFormat_Uint16x2 = 0x0000000E,
    DoeWGPUVertexFormat_Uint16x4 = 0x0000000F,
    DoeWGPUVertexFormat_Sint16 = 0x00000010,
    DoeWGPUVertexFormat_Sint16x2 = 0x00000011,
    DoeWGPUVertexFormat_Sint16x4 = 0x00000012,
    DoeWGPUVertexFormat_Unorm16 = 0x00000013,
    DoeWGPUVertexFormat_Unorm16x2 = 0x00000014,
    DoeWGPUVertexFormat_Unorm16x4 = 0x00000015,
    DoeWGPUVertexFormat_Snorm16 = 0x00000016,
    DoeWGPUVertexFormat_Snorm16x2 = 0x00000017,
    DoeWGPUVertexFormat_Snorm16x4 = 0x00000018,
    DoeWGPUVertexFormat_Float16 = 0x00000019,
    DoeWGPUVertexFormat_Float16x2 = 0x0000001A,
    DoeWGPUVertexFormat_Float16x4 = 0x0000001B,
    DoeWGPUVertexFormat_Float32 = 0x0000001C,
    DoeWGPUVertexFormat_Float32x2 = 0x0000001D,
    DoeWGPUVertexFormat_Float32x3 = 0x0000001E,
    DoeWGPUVertexFormat_Float32x4 = 0x0000001F,
    DoeWGPUVertexFormat_Uint32 = 0x00000020,
    DoeWGPUVertexFormat_Uint32x2 = 0x00000021,
    DoeWGPUVertexFormat_Uint32x3 = 0x00000022,
    DoeWGPUVertexFormat_Uint32x4 = 0x00000023,
    DoeWGPUVertexFormat_Sint32 = 0x00000024,
    DoeWGPUVertexFormat_Sint32x2 = 0x00000025,
    DoeWGPUVertexFormat_Sint32x3 = 0x00000026,
    DoeWGPUVertexFormat_Sint32x4 = 0x00000027,
    DoeWGPUVertexFormat_Unorm10_10_10_2 = 0x00000028,
    DoeWGPUVertexFormat_Unorm8x4BGRA = 0x00000029,
    DoeWGPUVertexFormat_Force32 = 0x7FFFFFFF
} DoeWGPUVertexFormat DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUVertexStepMode {
    /**
     * `0`. Indicates no value is passed for this argument. See @ref SentinelValues.
     */
    DoeWGPUVertexStepMode_Undefined = 0x00000000,
    DoeWGPUVertexStepMode_Vertex = 0x00000001,
    DoeWGPUVertexStepMode_Instance = 0x00000002,
    DoeWGPUVertexStepMode_Force32 = 0x7FFFFFFF
} DoeWGPUVertexStepMode DoeWGPU_ENUM_ATTRIBUTE;

/**
 * Status returned from a call to ::DoewgpuInstanceWaitAny.
 */
typedef enum DoeWGPUWaitStatus {
    /**
     * At least one DoeWGPUFuture completed successfully.
     */
    DoeWGPUWaitStatus_Success = 0x00000001,
    /**
     * The wait operation succeeded, but no DoeWGPUFutures completed within the timeout.
     */
    DoeWGPUWaitStatus_TimedOut = 0x00000002,
    /**
     * The call was invalid for some reason (see @ref Wait-Any).
     * Should produce @ref ImplementationDefinedLogging containing details.
     */
    DoeWGPUWaitStatus_Error = 0x00000003,
    DoeWGPUWaitStatus_Force32 = 0x7FFFFFFF
} DoeWGPUWaitStatus DoeWGPU_ENUM_ATTRIBUTE;

typedef enum DoeWGPUWGSLLanguageFeatureName {
    DoeWGPUWGSLLanguageFeatureName_ReadonlyAndReadwriteStorageTextures = 0x00000001,
    DoeWGPUWGSLLanguageFeatureName_Packed4x8IntegerDotProduct = 0x00000002,
    DoeWGPUWGSLLanguageFeatureName_UnrestrictedPointerParameters = 0x00000003,
    DoeWGPUWGSLLanguageFeatureName_PointerCompositeAccess = 0x00000004,
    DoeWGPUWGSLLanguageFeatureName_UniformBufferStandardLayout = 0x00000005,
    DoeWGPUWGSLLanguageFeatureName_SubgroupId = 0x00000006,
    DoeWGPUWGSLLanguageFeatureName_TextureAndSamplerLet = 0x00000007,
    DoeWGPUWGSLLanguageFeatureName_SubgroupUniformity = 0x00000008,
    DoeWGPUWGSLLanguageFeatureName_TextureFormatsTier1 = 0x00000009,
    DoeWGPUWGSLLanguageFeatureName_LinearIndexing = 0x0000000A,
    DoeWGPUWGSLLanguageFeatureName_ImmediateAddressSpace = 0x0000000B,
    DoeWGPUWGSLLanguageFeatureName_BufferView = 0x0000000C,
    DoeWGPUWGSLLanguageFeatureName_Force32 = 0x7FFFFFFF
} DoeWGPUWGSLLanguageFeatureName DoeWGPU_ENUM_ATTRIBUTE;

/** @} */

/**
 * \defgroup Bitflags Bitflags
 * \brief Type and constant definitions for bitflag types.
 *
 * @{
 */

/**
 * For reserved non-standard bitflag values, see @ref BitflagRegistry.
 */
typedef DoeWGPUFlags DoeWGPUBufferUsage;
/**
 * `0`.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_None = 0x0000000000000000;
/**
 * The buffer can be *mapped* on the CPU side in *read* mode (using @ref DoeWGPUMapMode_Read).
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_MapRead = 0x0000000000000001;
/**
 * The buffer can be *mapped* on the CPU side in *write* mode (using @ref DoeWGPUMapMode_Write).
 *
 * @note This usage is **not** required to set `mappedAtCreation` to `true` in @ref DoeWGPUBufferDescriptor.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_MapWrite = 0x0000000000000002;
/**
 * The buffer can be used as the *source* of a GPU-side copy operation.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_CopySrc = 0x0000000000000004;
/**
 * The buffer can be used as the *destination* of a GPU-side copy operation.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_CopyDst = 0x0000000000000008;
/**
 * The buffer can be used as an Index buffer when doing indexed drawing in a render pipeline.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_Index = 0x0000000000000010;
/**
 * The buffer can be used as a Vertex buffer when using a render pipeline.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_Vertex = 0x0000000000000020;
/**
 * The buffer can be bound to a shader as a uniform buffer.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_Uniform = 0x0000000000000040;
/**
 * The buffer can be bound to a shader as a storage buffer.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_Storage = 0x0000000000000080;
/**
 * The buffer can store arguments for an indirect draw call.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_Indirect = 0x0000000000000100;
/**
 * The buffer can store the result of a timestamp or occlusion query.
 */
static const DoeWGPUBufferUsage DoeWGPUBufferUsage_QueryResolve = 0x0000000000000200;

/**
 * For reserved non-standard bitflag values, see @ref BitflagRegistry.
 */
typedef DoeWGPUFlags DoeWGPUColorWriteMask;
/**
 * `0`.
 */
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_None = 0x0000000000000000;
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_Red = 0x0000000000000001;
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_Green = 0x0000000000000002;
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_Blue = 0x0000000000000004;
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_Alpha = 0x0000000000000008;
/**
 * `Red | Green | Blue | Alpha`.
 */
static const DoeWGPUColorWriteMask DoeWGPUColorWriteMask_All = 0x000000000000000F;

/**
 * For reserved non-standard bitflag values, see @ref BitflagRegistry.
 */
typedef DoeWGPUFlags DoeWGPUMapMode;
/**
 * `0`.
 */
static const DoeWGPUMapMode DoeWGPUMapMode_None = 0x0000000000000000;
static const DoeWGPUMapMode DoeWGPUMapMode_Read = 0x0000000000000001;
static const DoeWGPUMapMode DoeWGPUMapMode_Write = 0x0000000000000002;

/**
 * For reserved non-standard bitflag values, see @ref BitflagRegistry.
 */
typedef DoeWGPUFlags DoeWGPUShaderStage;
/**
 * `0`.
 */
static const DoeWGPUShaderStage DoeWGPUShaderStage_None = 0x0000000000000000;
static const DoeWGPUShaderStage DoeWGPUShaderStage_Vertex = 0x0000000000000001;
static const DoeWGPUShaderStage DoeWGPUShaderStage_Fragment = 0x0000000000000002;
static const DoeWGPUShaderStage DoeWGPUShaderStage_Compute = 0x0000000000000004;

/**
 * For reserved non-standard bitflag values, see @ref BitflagRegistry.
 */
typedef DoeWGPUFlags DoeWGPUTextureUsage;
/**
 * `0`.
 */
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_None = 0x0000000000000000;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_CopySrc = 0x0000000000000001;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_CopyDst = 0x0000000000000002;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_TextureBinding = 0x0000000000000004;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_StorageBinding = 0x0000000000000008;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_RenderAttachment = 0x0000000000000010;
static const DoeWGPUTextureUsage DoeWGPUTextureUsage_TransientAttachment = 0x0000000000000020;

/** @} */

typedef void (*DoeWGPUProc)(void) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * \defgroup Callbacks Callbacks
 * \brief Callbacks through which asynchronous functions return.
 *
 * @{
 */

/**
 * See also @ref CallbackError.
 *
 * @param message
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUBufferMapCallback)(DoeWGPUMapAsyncStatus status, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param compilationInfo
 * This argument contains multiple @ref ImplementationAllocatedStructChain roots.
 * Arbitrary chains must be handled gracefully by the application!
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUCompilationInfoCallback)(DoeWGPUCompilationInfoRequestStatus status, struct DoeWGPUCompilationInfo const * compilationInfo, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param pipeline
 * This parameter is @ref PassedWithOwnership.
 */
typedef void (*DoeWGPUCreateComputePipelineAsyncCallback)(DoeWGPUCreatePipelineAsyncStatus status, DoeWGPUComputePipeline pipeline, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param pipeline
 * This parameter is @ref PassedWithOwnership.
 */
typedef void (*DoeWGPUCreateRenderPipelineAsyncCallback)(DoeWGPUCreatePipelineAsyncStatus status, DoeWGPURenderPipeline pipeline, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param device
 * Pointer to the device which was lost. This is always a non-null pointer.
 * The pointed-to @ref DoeWGPUDevice will be null if, and only if, either:
 * (1) The `reason` is @ref DoeWGPUDeviceLostReason_FailedCreation.
 * (2) The last ref of the device has been (or is being) released: see @ref DeviceRelease.
 * This parameter is @ref PassedWithoutOwnership.
 *
 * @param reason
 * An error code explaining why the device was lost.
 *
 * @param message
 * A @ref LocalizableHumanReadableMessageString describing why the device was lost.
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUDeviceLostCallback)(DoeWGPUDevice const * device, DoeWGPUDeviceLostReason reason, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param status
 * See @ref DoeWGPUPopErrorScopeStatus.
 *
 * @param type
 * The type of the error caught by the scope, or @ref DoeWGPUErrorType_NoError if there was none.
 * If the `status` is not @ref DoeWGPUPopErrorScopeStatus_Success, this is @ref DoeWGPUErrorType_NoError.
 *
 * @param message
 * If the `status` is not @ref DoeWGPUPopErrorScopeStatus_Success **or**
 * the `type` is not @ref DoeWGPUErrorType_NoError, this is a non-empty
 * @ref LocalizableHumanReadableMessageString;
 * otherwise, this is an empty string.
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUPopErrorScopeCallback)(DoeWGPUPopErrorScopeStatus status, DoeWGPUErrorType type, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param status
 * See @ref DoeWGPUQueueWorkDoneStatus.
 *
 * @param message
 * If the `status` is not @ref DoeWGPUQueueWorkDoneStatus_Success,
 * this is a non-empty @ref LocalizableHumanReadableMessageString;
 * otherwise, this is an empty string.
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUQueueWorkDoneCallback)(DoeWGPUQueueWorkDoneStatus status, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param adapter
 * This parameter is @ref PassedWithOwnership.
 *
 * @param message
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPURequestAdapterCallback)(DoeWGPURequestAdapterStatus status, DoeWGPUAdapter adapter, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param device
 * This parameter is @ref PassedWithOwnership.
 *
 * @param message
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPURequestDeviceCallback)(DoeWGPURequestDeviceStatus status, DoeWGPUDevice device, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/**
 * See also @ref CallbackError.
 *
 * @param device
 * This parameter is @ref PassedWithoutOwnership.
 *
 * @param message
 * This parameter is @ref PassedWithoutOwnership.
 */
typedef void (*DoeWGPUUncapturedErrorCallback)(DoeWGPUDevice const * device, DoeWGPUErrorType type, DoeWGPUStringView message, DoeWGPU_NULLABLE void* userdata1, DoeWGPU_NULLABLE void* userdata2) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */
/**
 * \defgroup ChainedStructures Chained Structures
 * \brief Structures used to extend descriptors.
 *
 * @{
 */

typedef struct DoeWGPUChainedStruct {
    struct DoeWGPUChainedStruct * next;
    DoeWGPUSType sType;
} DoeWGPUChainedStruct DoeWGPU_STRUCTURE_ATTRIBUTE;

/** @} */


/**
 * \defgroup Structures Structures
 * \brief Descriptors and other transparent structures.
 *
 * @{
 */

/**
 * \defgroup CallbackInfoStructs Callback Info Structs
 * \brief Callback info structures that are used in asynchronous functions.
 *
 * @{
 */

typedef struct DoeWGPUBufferMapCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUBufferMapCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUBufferMapCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBufferMapCallbackInfo.
 */
#define DoeWGPU_BUFFER_MAP_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBufferMapCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUCompilationInfoCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUCompilationInfoCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUCompilationInfoCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCompilationInfoCallbackInfo.
 */
#define DoeWGPU_COMPILATION_INFO_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCompilationInfoCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUCreateComputePipelineAsyncCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUCreateComputePipelineAsyncCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUCreateComputePipelineAsyncCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCreateComputePipelineAsyncCallbackInfo.
 */
#define DoeWGPU_CREATE_COMPUTE_PIPELINE_ASYNC_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCreateComputePipelineAsyncCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUCreateRenderPipelineAsyncCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUCreateRenderPipelineAsyncCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUCreateRenderPipelineAsyncCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCreateRenderPipelineAsyncCallbackInfo.
 */
#define DoeWGPU_CREATE_RENDER_PIPELINE_ASYNC_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCreateRenderPipelineAsyncCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUDeviceLostCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUDeviceLostCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUDeviceLostCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUDeviceLostCallbackInfo.
 */
#define DoeWGPU_DEVICE_LOST_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUDeviceLostCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUPopErrorScopeCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUPopErrorScopeCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUPopErrorScopeCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUPopErrorScopeCallbackInfo.
 */
#define DoeWGPU_POP_ERROR_SCOPE_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUPopErrorScopeCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUQueueWorkDoneCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPUQueueWorkDoneCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUQueueWorkDoneCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUQueueWorkDoneCallbackInfo.
 */
#define DoeWGPU_QUEUE_WORK_DONE_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUQueueWorkDoneCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPURequestAdapterCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPURequestAdapterCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPURequestAdapterCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURequestAdapterCallbackInfo.
 */
#define DoeWGPU_REQUEST_ADAPTER_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURequestAdapterCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPURequestDeviceCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Controls when the callback may be called.
     *
     * Has no default. The `INIT` macro sets this to (@ref DoeWGPUCallbackMode)0.
     */
    DoeWGPUCallbackMode mode;
    DoeWGPURequestDeviceCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPURequestDeviceCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURequestDeviceCallbackInfo.
 */
#define DoeWGPU_REQUEST_DEVICE_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURequestDeviceCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.mode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCallbackMode) _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

typedef struct DoeWGPUUncapturedErrorCallbackInfo {
    DoeWGPUChainedStruct * nextInChain;
    DoeWGPUUncapturedErrorCallback callback;
    DoeWGPU_NULLABLE void* userdata1;
    DoeWGPU_NULLABLE void* userdata2;
} DoeWGPUUncapturedErrorCallbackInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUUncapturedErrorCallbackInfo.
 */
#define DoeWGPU_UNCAPTURED_ERROR_CALLBACK_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUUncapturedErrorCallbackInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.callback=*/NULL _wgpu_COMMA \
    /*.userdata1=*/NULL _wgpu_COMMA \
    /*.userdata2=*/NULL _wgpu_COMMA \
})

/** @} */

/**
 * Default values can be set using @ref DoeWGPU_ADAPTER_INFO_INIT as initializer.
 */
typedef struct DoeWGPUAdapterInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is an \ref OutputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView vendor;
    /**
     * This is an \ref OutputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView architecture;
    /**
     * This is an \ref OutputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView device;
    /**
     * This is an \ref OutputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView description;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUBackendType_Undefined.
     */
    DoeWGPUBackendType backendType;
    /**
     * The `INIT` macro sets this to (@ref DoeWGPUAdapterType)0.
     */
    DoeWGPUAdapterType adapterType;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t vendorID;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t deviceID;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t subgroupMinSize;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t subgroupMaxSize;
} DoeWGPUAdapterInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUAdapterInfo.
 */
#define DoeWGPU_ADAPTER_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUAdapterInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.vendor=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.architecture=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.device=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.description=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.backendType=*/DoeWGPUBackendType_Undefined _wgpu_COMMA \
    /*.adapterType=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUAdapterType) _wgpu_COMMA \
    /*.vendorID=*/0 _wgpu_COMMA \
    /*.deviceID=*/0 _wgpu_COMMA \
    /*.subgroupMinSize=*/0 _wgpu_COMMA \
    /*.subgroupMaxSize=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BLEND_COMPONENT_INIT as initializer.
 */
typedef struct DoeWGPUBlendComponent {
    /**
     * If set to @ref DoeWGPUBlendOperation_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUBlendOperation_Add.
     *
     * The `INIT` macro sets this to @ref DoeWGPUBlendOperation_Undefined.
     */
    DoeWGPUBlendOperation operation;
    /**
     * If set to @ref DoeWGPUBlendFactor_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUBlendFactor_One.
     *
     * The `INIT` macro sets this to @ref DoeWGPUBlendFactor_Undefined.
     */
    DoeWGPUBlendFactor srcFactor;
    /**
     * If set to @ref DoeWGPUBlendFactor_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUBlendFactor_Zero.
     *
     * The `INIT` macro sets this to @ref DoeWGPUBlendFactor_Undefined.
     */
    DoeWGPUBlendFactor dstFactor;
} DoeWGPUBlendComponent DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBlendComponent.
 */
#define DoeWGPU_BLEND_COMPONENT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBlendComponent, { \
    /*.operation=*/DoeWGPUBlendOperation_Undefined _wgpu_COMMA \
    /*.srcFactor=*/DoeWGPUBlendFactor_Undefined _wgpu_COMMA \
    /*.dstFactor=*/DoeWGPUBlendFactor_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BUFFER_BINDING_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUBufferBindingLayout {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If set to @ref DoeWGPUBufferBindingType_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUBufferBindingType_Uniform.
     *
     * The `INIT` macro sets this to @ref DoeWGPUBufferBindingType_Undefined.
     */
    DoeWGPUBufferBindingType type;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool hasDynamicOffset;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint64_t minBindingSize;
} DoeWGPUBufferBindingLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBufferBindingLayout.
 */
#define DoeWGPU_BUFFER_BINDING_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBufferBindingLayout, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.type=*/DoeWGPUBufferBindingType_Undefined _wgpu_COMMA \
    /*.hasDynamicOffset=*/DoeWGPU_FALSE _wgpu_COMMA \
    /*.minBindingSize=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BUFFER_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUBufferDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUBufferUsage_None.
     */
    DoeWGPUBufferUsage usage;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint64_t size;
    /**
     * When true, the buffer is mapped in write mode at creation. It should thus be unmapped once its initial data has been written.
     *
     * @note Mapping at creation does **not** require the usage @ref DoeWGPUBufferUsage_MapWrite.
     *
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool mappedAtCreation;
} DoeWGPUBufferDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBufferDescriptor.
 */
#define DoeWGPU_BUFFER_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBufferDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.usage=*/DoeWGPUBufferUsage_None _wgpu_COMMA \
    /*.size=*/0 _wgpu_COMMA \
    /*.mappedAtCreation=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * An RGBA color. Represents a `f32`, `i32`, or `u32` color using @ref DoubleAsSupertype.
 *
 * If any channel is non-finite, produces a @ref NonFiniteFloatValueError.
 *
 * Default values can be set using @ref DoeWGPU_COLOR_INIT as initializer.
 */
typedef struct DoeWGPUColor {
    /**
     * The `INIT` macro sets this to `0.`.
     */
    double r;
    /**
     * The `INIT` macro sets this to `0.`.
     */
    double g;
    /**
     * The `INIT` macro sets this to `0.`.
     */
    double b;
    /**
     * The `INIT` macro sets this to `0.`.
     */
    double a;
} DoeWGPUColor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUColor.
 */
#define DoeWGPU_COLOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUColor, { \
    /*.r=*/0. _wgpu_COMMA \
    /*.g=*/0. _wgpu_COMMA \
    /*.b=*/0. _wgpu_COMMA \
    /*.a=*/0. _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COMMAND_BUFFER_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUCommandBufferDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPUCommandBufferDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCommandBufferDescriptor.
 */
#define DoeWGPU_COMMAND_BUFFER_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCommandBufferDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COMMAND_ENCODER_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUCommandEncoderDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPUCommandEncoderDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCommandEncoderDescriptor.
 */
#define DoeWGPU_COMMAND_ENCODER_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCommandEncoderDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Note: While Compatibility Mode is optional to implement, this extension struct
 * is required to be supported (for both queries and requests) and behave as
 * defined in the WebGPU spec.
 *
 * Default values can be set using @ref DoeWGPU_COMPATIBILITY_MODE_LIMITS_INIT as initializer.
 */
typedef struct DoeWGPUCompatibilityModeLimits {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageBuffersInVertexStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageTexturesInVertexStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageBuffersInFragmentStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageTexturesInFragmentStage;
} DoeWGPUCompatibilityModeLimits DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCompatibilityModeLimits.
 */
#define DoeWGPU_COMPATIBILITY_MODE_LIMITS_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCompatibilityModeLimits, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_CompatibilityModeLimits _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.maxStorageBuffersInVertexStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxStorageTexturesInVertexStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxStorageBuffersInFragmentStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxStorageTexturesInFragmentStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
})

/**
 * This is an @ref ImplementationAllocatedStructChain root.
 * Arbitrary chains must be handled gracefully by the application!
 *
 * Default values can be set using @ref DoeWGPU_COMPILATION_MESSAGE_INIT as initializer.
 */
typedef struct DoeWGPUCompilationMessage {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * A @ref LocalizableHumanReadableMessageString.
     *
     * This is an \ref OutputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView message;
    /**
     * Severity level of the message.
     *
     * The `INIT` macro sets this to (@ref DoeWGPUCompilationMessageType)0.
     */
    DoeWGPUCompilationMessageType type;
    /**
     * Line number where the message is attached, starting at 1.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t lineNum;
    /**
     * Offset in UTF-8 code units (bytes) from the beginning of the line, starting at 1.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t linePos;
    /**
     * Offset in UTF-8 code units (bytes) from the beginning of the shader code, starting at 0.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t offset;
    /**
     * Length in UTF-8 code units (bytes) of the span the message corresponds to.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t length;
} DoeWGPUCompilationMessage DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCompilationMessage.
 */
#define DoeWGPU_COMPILATION_MESSAGE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCompilationMessage, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.message=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.type=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUCompilationMessageType) _wgpu_COMMA \
    /*.lineNum=*/0 _wgpu_COMMA \
    /*.linePos=*/0 _wgpu_COMMA \
    /*.offset=*/0 _wgpu_COMMA \
    /*.length=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_CONSTANT_ENTRY_INIT as initializer.
 */
typedef struct DoeWGPUConstantEntry {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView key;
    /**
     * Represents a WGSL numeric or boolean value using @ref DoubleAsSupertype.
     *
     * If non-finite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to `0.`.
     */
    double value;
} DoeWGPUConstantEntry DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUConstantEntry.
 */
#define DoeWGPU_CONSTANT_ENTRY_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUConstantEntry, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.key=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.value=*/0. _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_EXTENT_3D_INIT as initializer.
 */
typedef struct DoeWGPUExtent3D {
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t width;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t height;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t depthOrArrayLayers;
} DoeWGPUExtent3D DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUExtent3D.
 */
#define DoeWGPU_EXTENT_3D_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUExtent3D, { \
    /*.width=*/0 _wgpu_COMMA \
    /*.height=*/1 _wgpu_COMMA \
    /*.depthOrArrayLayers=*/1 _wgpu_COMMA \
})

/**
 * Chained in an @ref DoeWGPUBindGroupEntry to set it to an @ref DoeWGPUExternalTexture. This must have a corresponding @ref DoeWGPUExternalTextureBindingLayout in the @ref DoeWGPUBindGroupLayout.
 *
 * Default values can be set using @ref DoeWGPU_EXTERNAL_TEXTURE_BINDING_ENTRY_INIT as initializer.
 */
typedef struct DoeWGPUExternalTextureBindingEntry {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUExternalTexture externalTexture;
} DoeWGPUExternalTextureBindingEntry DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUExternalTextureBindingEntry.
 */
#define DoeWGPU_EXTERNAL_TEXTURE_BINDING_ENTRY_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUExternalTextureBindingEntry, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_ExternalTextureBindingEntry _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.externalTexture=*/NULL _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUBindGroupLayoutEntry to specify that the corresponding entries in an @ref DoeWGPUBindGroup will contain an @ref DoeWGPUExternalTexture.
 *
 * Default values can be set using @ref DoeWGPU_EXTERNAL_TEXTURE_BINDING_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUExternalTextureBindingLayout {
    DoeWGPUChainedStruct chain;
} DoeWGPUExternalTextureBindingLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUExternalTextureBindingLayout.
 */
#define DoeWGPU_EXTERNAL_TEXTURE_BINDING_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUExternalTextureBindingLayout, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_ExternalTextureBindingLayout _wgpu_COMMA \
    }) _wgpu_COMMA \
})

/**
 * Opaque handle to an asynchronous operation. See @ref Asynchronous-Operations for more information.
 *
 * Default values can be set using @ref DoeWGPU_FUTURE_INIT as initializer.
 */
typedef struct DoeWGPUFuture {
    /**
     * Opaque id of the @ref DoeWGPUFuture
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t id;
} DoeWGPUFuture DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUFuture.
 */
#define DoeWGPU_FUTURE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUFuture, { \
    /*.id=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_INSTANCE_LIMITS_INIT as initializer.
 */
typedef struct DoeWGPUInstanceLimits {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The maximum number @ref DoeWGPUFutureWaitInfo supported in a call to ::DoewgpuInstanceWaitAny with `timeoutNS > 0`.
     *
     * The `INIT` macro sets this to `0`.
     */
    size_t timedWaitAnyMaxCount;
} DoeWGPUInstanceLimits DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUInstanceLimits.
 */
#define DoeWGPU_INSTANCE_LIMITS_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUInstanceLimits, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.timedWaitAnyMaxCount=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_MULTISAMPLE_STATE_INIT as initializer.
 */
typedef struct DoeWGPUMultisampleState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t count;
    /**
     * The `INIT` macro sets this to `0xFFFFFFFF`.
     */
    uint32_t mask;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool alphaToCoverageEnabled;
} DoeWGPUMultisampleState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUMultisampleState.
 */
#define DoeWGPU_MULTISAMPLE_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUMultisampleState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.count=*/1 _wgpu_COMMA \
    /*.mask=*/0xFFFFFFFF _wgpu_COMMA \
    /*.alphaToCoverageEnabled=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_ORIGIN_3D_INIT as initializer.
 */
typedef struct DoeWGPUOrigin3D {
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t x;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t y;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t z;
} DoeWGPUOrigin3D DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUOrigin3D.
 */
#define DoeWGPU_ORIGIN_3D_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUOrigin3D, { \
    /*.x=*/0 _wgpu_COMMA \
    /*.y=*/0 _wgpu_COMMA \
    /*.z=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_PASS_TIMESTAMP_WRITES_INIT as initializer.
 */
typedef struct DoeWGPUPassTimestampWrites {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Query set to write timestamps to.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUQuerySet querySet;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_QUERY_SET_INDEX_UNDEFINED.
     */
    uint32_t beginningOfPassWriteIndex;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_QUERY_SET_INDEX_UNDEFINED.
     */
    uint32_t endOfPassWriteIndex;
} DoeWGPUPassTimestampWrites DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUPassTimestampWrites.
 */
#define DoeWGPU_PASS_TIMESTAMP_WRITES_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUPassTimestampWrites, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.querySet=*/NULL _wgpu_COMMA \
    /*.beginningOfPassWriteIndex=*/DoeWGPU_QUERY_SET_INDEX_UNDEFINED _wgpu_COMMA \
    /*.endOfPassWriteIndex=*/DoeWGPU_QUERY_SET_INDEX_UNDEFINED _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_PIPELINE_LAYOUT_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUPipelineLayoutDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * Array count for `bindGroupLayouts`. The `INIT` macro sets this to 0.
     */
    size_t bindGroupLayoutCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUBindGroupLayout const * bindGroupLayouts;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t immediateSize;
} DoeWGPUPipelineLayoutDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUPipelineLayoutDescriptor.
 */
#define DoeWGPU_PIPELINE_LAYOUT_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUPipelineLayoutDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.bindGroupLayoutCount=*/0 _wgpu_COMMA \
    /*.bindGroupLayouts=*/NULL _wgpu_COMMA \
    /*.immediateSize=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_PRIMITIVE_STATE_INIT as initializer.
 */
typedef struct DoeWGPUPrimitiveState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If set to @ref DoeWGPUPrimitiveTopology_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUPrimitiveTopology_TriangleList.
     *
     * The `INIT` macro sets this to @ref DoeWGPUPrimitiveTopology_Undefined.
     */
    DoeWGPUPrimitiveTopology topology;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUIndexFormat_Undefined.
     */
    DoeWGPUIndexFormat stripIndexFormat;
    /**
     * If set to @ref DoeWGPUFrontFace_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUFrontFace_CCW.
     *
     * The `INIT` macro sets this to @ref DoeWGPUFrontFace_Undefined.
     */
    DoeWGPUFrontFace frontFace;
    /**
     * If set to @ref DoeWGPUCullMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUCullMode_None.
     *
     * The `INIT` macro sets this to @ref DoeWGPUCullMode_Undefined.
     */
    DoeWGPUCullMode cullMode;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool unclippedDepth;
} DoeWGPUPrimitiveState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUPrimitiveState.
 */
#define DoeWGPU_PRIMITIVE_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUPrimitiveState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.topology=*/DoeWGPUPrimitiveTopology_Undefined _wgpu_COMMA \
    /*.stripIndexFormat=*/DoeWGPUIndexFormat_Undefined _wgpu_COMMA \
    /*.frontFace=*/DoeWGPUFrontFace_Undefined _wgpu_COMMA \
    /*.cullMode=*/DoeWGPUCullMode_Undefined _wgpu_COMMA \
    /*.unclippedDepth=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_QUERY_SET_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUQuerySetDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to (@ref DoeWGPUQueryType)0.
     */
    DoeWGPUQueryType type;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t count;
} DoeWGPUQuerySetDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUQuerySetDescriptor.
 */
#define DoeWGPU_QUERY_SET_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUQuerySetDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.type=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUQueryType) _wgpu_COMMA \
    /*.count=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_QUEUE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUQueueDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPUQueueDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUQueueDescriptor.
 */
#define DoeWGPU_QUEUE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUQueueDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_BUNDLE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPURenderBundleDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPURenderBundleDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderBundleDescriptor.
 */
#define DoeWGPU_RENDER_BUNDLE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderBundleDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_BUNDLE_ENCODER_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPURenderBundleEncoderDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * Array count for `colorFormats`. The `INIT` macro sets this to 0.
     */
    size_t colorFormatCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTextureFormat const * colorFormats;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat depthStencilFormat;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t sampleCount;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool depthReadOnly;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool stencilReadOnly;
} DoeWGPURenderBundleEncoderDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderBundleEncoderDescriptor.
 */
#define DoeWGPU_RENDER_BUNDLE_ENCODER_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderBundleEncoderDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.colorFormatCount=*/0 _wgpu_COMMA \
    /*.colorFormats=*/NULL _wgpu_COMMA \
    /*.depthStencilFormat=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.sampleCount=*/1 _wgpu_COMMA \
    /*.depthReadOnly=*/DoeWGPU_FALSE _wgpu_COMMA \
    /*.stencilReadOnly=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_PASS_DEPTH_STENCIL_ATTACHMENT_INIT as initializer.
 */
typedef struct DoeWGPURenderPassDepthStencilAttachment {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTextureView view;
    /**
     * The `INIT` macro sets this to @ref DoeWGPULoadOp_Undefined.
     */
    DoeWGPULoadOp depthLoadOp;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUStoreOp_Undefined.
     */
    DoeWGPUStoreOp depthStoreOp;
    /**
     * This is a @ref NullableFloatingPointType.
     *
     * If `NaN`, indicates an `undefined` value (as defined by the JS spec).
     * Use @ref DoeWGPU_DEPTH_CLEAR_VALUE_UNDEFINED to indicate this semantically.
     *
     * If infinite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_DEPTH_CLEAR_VALUE_UNDEFINED.
     */
    float depthClearValue;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool depthReadOnly;
    /**
     * The `INIT` macro sets this to @ref DoeWGPULoadOp_Undefined.
     */
    DoeWGPULoadOp stencilLoadOp;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUStoreOp_Undefined.
     */
    DoeWGPUStoreOp stencilStoreOp;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t stencilClearValue;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool stencilReadOnly;
} DoeWGPURenderPassDepthStencilAttachment DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderPassDepthStencilAttachment.
 */
#define DoeWGPU_RENDER_PASS_DEPTH_STENCIL_ATTACHMENT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderPassDepthStencilAttachment, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.view=*/NULL _wgpu_COMMA \
    /*.depthLoadOp=*/DoeWGPULoadOp_Undefined _wgpu_COMMA \
    /*.depthStoreOp=*/DoeWGPUStoreOp_Undefined _wgpu_COMMA \
    /*.depthClearValue=*/DoeWGPU_DEPTH_CLEAR_VALUE_UNDEFINED _wgpu_COMMA \
    /*.depthReadOnly=*/DoeWGPU_FALSE _wgpu_COMMA \
    /*.stencilLoadOp=*/DoeWGPULoadOp_Undefined _wgpu_COMMA \
    /*.stencilStoreOp=*/DoeWGPUStoreOp_Undefined _wgpu_COMMA \
    /*.stencilClearValue=*/0 _wgpu_COMMA \
    /*.stencilReadOnly=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_PASS_MAX_DRAW_COUNT_INIT as initializer.
 */
typedef struct DoeWGPURenderPassMaxDrawCount {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to `50000000`.
     */
    uint64_t maxDrawCount;
} DoeWGPURenderPassMaxDrawCount DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderPassMaxDrawCount.
 */
#define DoeWGPU_RENDER_PASS_MAX_DRAW_COUNT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderPassMaxDrawCount, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_RenderPassMaxDrawCount _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.maxDrawCount=*/50000000 _wgpu_COMMA \
})

/**
 * Extension providing requestAdapter options for implementations with WebXR interop (i.e. Wasm).
 *
 * Default values can be set using @ref DoeWGPU_REQUEST_ADAPTER_WEBXR_OPTIONS_INIT as initializer.
 */
typedef struct DoeWGPURequestAdapterWebXROptions {
    DoeWGPUChainedStruct chain;
    /**
     * Sets the `xrCompatible` option in the JS API.
     *
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool xrCompatible;
} DoeWGPURequestAdapterWebXROptions DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURequestAdapterWebXROptions.
 */
#define DoeWGPU_REQUEST_ADAPTER_WEBXR_OPTIONS_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURequestAdapterWebXROptions, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_RequestAdapterWebXROptions _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.xrCompatible=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SAMPLER_BINDING_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUSamplerBindingLayout {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If set to @ref DoeWGPUSamplerBindingType_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUSamplerBindingType_Filtering.
     *
     * The `INIT` macro sets this to @ref DoeWGPUSamplerBindingType_Undefined.
     */
    DoeWGPUSamplerBindingType type;
} DoeWGPUSamplerBindingLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSamplerBindingLayout.
 */
#define DoeWGPU_SAMPLER_BINDING_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSamplerBindingLayout, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.type=*/DoeWGPUSamplerBindingType_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SAMPLER_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUSamplerDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * If set to @ref DoeWGPUAddressMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUAddressMode_ClampToEdge.
     *
     * The `INIT` macro sets this to @ref DoeWGPUAddressMode_Undefined.
     */
    DoeWGPUAddressMode addressModeU;
    /**
     * If set to @ref DoeWGPUAddressMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUAddressMode_ClampToEdge.
     *
     * The `INIT` macro sets this to @ref DoeWGPUAddressMode_Undefined.
     */
    DoeWGPUAddressMode addressModeV;
    /**
     * If set to @ref DoeWGPUAddressMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUAddressMode_ClampToEdge.
     *
     * The `INIT` macro sets this to @ref DoeWGPUAddressMode_Undefined.
     */
    DoeWGPUAddressMode addressModeW;
    /**
     * If set to @ref DoeWGPUFilterMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUFilterMode_Nearest.
     *
     * The `INIT` macro sets this to @ref DoeWGPUFilterMode_Undefined.
     */
    DoeWGPUFilterMode magFilter;
    /**
     * If set to @ref DoeWGPUFilterMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUFilterMode_Nearest.
     *
     * The `INIT` macro sets this to @ref DoeWGPUFilterMode_Undefined.
     */
    DoeWGPUFilterMode minFilter;
    /**
     * If set to @ref DoeWGPUFilterMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUMipmapFilterMode_Nearest.
     *
     * The `INIT` macro sets this to @ref DoeWGPUMipmapFilterMode_Undefined.
     */
    DoeWGPUMipmapFilterMode mipmapFilter;
    /**
     * TODO
     *
     * If non-finite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to `0.f`.
     */
    float lodMinClamp;
    /**
     * TODO
     *
     * If non-finite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to `32.f`.
     */
    float lodMaxClamp;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUCompareFunction_Undefined.
     */
    DoeWGPUCompareFunction compare;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint16_t maxAnisotropy;
} DoeWGPUSamplerDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSamplerDescriptor.
 */
#define DoeWGPU_SAMPLER_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSamplerDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.addressModeU=*/DoeWGPUAddressMode_Undefined _wgpu_COMMA \
    /*.addressModeV=*/DoeWGPUAddressMode_Undefined _wgpu_COMMA \
    /*.addressModeW=*/DoeWGPUAddressMode_Undefined _wgpu_COMMA \
    /*.magFilter=*/DoeWGPUFilterMode_Undefined _wgpu_COMMA \
    /*.minFilter=*/DoeWGPUFilterMode_Undefined _wgpu_COMMA \
    /*.mipmapFilter=*/DoeWGPUMipmapFilterMode_Undefined _wgpu_COMMA \
    /*.lodMinClamp=*/0.f _wgpu_COMMA \
    /*.lodMaxClamp=*/32.f _wgpu_COMMA \
    /*.compare=*/DoeWGPUCompareFunction_Undefined _wgpu_COMMA \
    /*.maxAnisotropy=*/1 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SHADER_SOURCE_SPIRV_INIT as initializer.
 */
typedef struct DoeWGPUShaderSourceSPIRV {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t codeSize;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    uint32_t const * code;
} DoeWGPUShaderSourceSPIRV DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUShaderSourceSPIRV.
 */
#define DoeWGPU_SHADER_SOURCE_SPIRV_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUShaderSourceSPIRV, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_ShaderSourceSPIRV _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.codeSize=*/0 _wgpu_COMMA \
    /*.code=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SHADER_SOURCE_WGSL_INIT as initializer.
 */
typedef struct DoeWGPUShaderSourceWGSL {
    DoeWGPUChainedStruct chain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView code;
} DoeWGPUShaderSourceWGSL DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUShaderSourceWGSL.
 */
#define DoeWGPU_SHADER_SOURCE_WGSL_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUShaderSourceWGSL, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_ShaderSourceWGSL _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.code=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_STENCIL_FACE_STATE_INIT as initializer.
 */
typedef struct DoeWGPUStencilFaceState {
    /**
     * If set to @ref DoeWGPUCompareFunction_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUCompareFunction_Always.
     *
     * The `INIT` macro sets this to @ref DoeWGPUCompareFunction_Undefined.
     */
    DoeWGPUCompareFunction compare;
    /**
     * If set to @ref DoeWGPUStencilOperation_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUStencilOperation_Keep.
     *
     * The `INIT` macro sets this to @ref DoeWGPUStencilOperation_Undefined.
     */
    DoeWGPUStencilOperation failOp;
    /**
     * If set to @ref DoeWGPUStencilOperation_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUStencilOperation_Keep.
     *
     * The `INIT` macro sets this to @ref DoeWGPUStencilOperation_Undefined.
     */
    DoeWGPUStencilOperation depthFailOp;
    /**
     * If set to @ref DoeWGPUStencilOperation_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUStencilOperation_Keep.
     *
     * The `INIT` macro sets this to @ref DoeWGPUStencilOperation_Undefined.
     */
    DoeWGPUStencilOperation passOp;
} DoeWGPUStencilFaceState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUStencilFaceState.
 */
#define DoeWGPU_STENCIL_FACE_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUStencilFaceState, { \
    /*.compare=*/DoeWGPUCompareFunction_Undefined _wgpu_COMMA \
    /*.failOp=*/DoeWGPUStencilOperation_Undefined _wgpu_COMMA \
    /*.depthFailOp=*/DoeWGPUStencilOperation_Undefined _wgpu_COMMA \
    /*.passOp=*/DoeWGPUStencilOperation_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_STORAGE_TEXTURE_BINDING_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUStorageTextureBindingLayout {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If set to @ref DoeWGPUStorageTextureAccess_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUStorageTextureAccess_WriteOnly.
     *
     * The `INIT` macro sets this to @ref DoeWGPUStorageTextureAccess_Undefined.
     */
    DoeWGPUStorageTextureAccess access;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * If set to @ref DoeWGPUTextureViewDimension_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureViewDimension_2D.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureViewDimension_Undefined.
     */
    DoeWGPUTextureViewDimension viewDimension;
} DoeWGPUStorageTextureBindingLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUStorageTextureBindingLayout.
 */
#define DoeWGPU_STORAGE_TEXTURE_BINDING_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUStorageTextureBindingLayout, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.access=*/DoeWGPUStorageTextureAccess_Undefined _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.viewDimension=*/DoeWGPUTextureViewDimension_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SUPPORTED_FEATURES_INIT as initializer.
 */
typedef struct DoeWGPUSupportedFeatures {
    /**
     * Array count for `features`. The `INIT` macro sets this to 0.
     */
    size_t featureCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUFeatureName const * features;
} DoeWGPUSupportedFeatures DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSupportedFeatures.
 */
#define DoeWGPU_SUPPORTED_FEATURES_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSupportedFeatures, { \
    /*.featureCount=*/0 _wgpu_COMMA \
    /*.features=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SUPPORTED_INSTANCE_FEATURES_INIT as initializer.
 */
typedef struct DoeWGPUSupportedInstanceFeatures {
    /**
     * Array count for `features`. The `INIT` macro sets this to 0.
     */
    size_t featureCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUInstanceFeatureName const * features;
} DoeWGPUSupportedInstanceFeatures DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSupportedInstanceFeatures.
 */
#define DoeWGPU_SUPPORTED_INSTANCE_FEATURES_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSupportedInstanceFeatures, { \
    /*.featureCount=*/0 _wgpu_COMMA \
    /*.features=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SUPPORTED_WGSL_LANGUAGE_FEATURES_INIT as initializer.
 */
typedef struct DoeWGPUSupportedWGSLLanguageFeatures {
    /**
     * Array count for `features`. The `INIT` macro sets this to 0.
     */
    size_t featureCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUWGSLLanguageFeatureName const * features;
} DoeWGPUSupportedWGSLLanguageFeatures DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSupportedWGSLLanguageFeatures.
 */
#define DoeWGPU_SUPPORTED_WGSL_LANGUAGE_FEATURES_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSupportedWGSLLanguageFeatures, { \
    /*.featureCount=*/0 _wgpu_COMMA \
    /*.features=*/NULL _wgpu_COMMA \
})

/**
 * Filled by @ref DoewgpuSurfaceGetCapabilities with what's supported for @ref DoewgpuSurfaceConfigure for a pair of @ref DoeWGPUSurface and @ref DoeWGPUAdapter.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_CAPABILITIES_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceCapabilities {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The bit set of supported @ref DoeWGPUTextureUsage bits.
     * Guaranteed to contain @ref DoeWGPUTextureUsage_RenderAttachment.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureUsage_None.
     */
    DoeWGPUTextureUsage usages;
    /**
     * Array count for `formats`. The `INIT` macro sets this to 0.
     */
    size_t formatCount;
    /**
     * A list of supported @ref DoeWGPUTextureFormat values, in order of preference.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTextureFormat const * formats;
    /**
     * Array count for `presentModes`. The `INIT` macro sets this to 0.
     */
    size_t presentModeCount;
    /**
     * A list of supported @ref DoeWGPUPresentMode values.
     * Guaranteed to contain @ref DoeWGPUPresentMode_Fifo.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUPresentMode const * presentModes;
    /**
     * Array count for `alphaModes`. The `INIT` macro sets this to 0.
     */
    size_t alphaModeCount;
    /**
     * A list of supported @ref DoeWGPUCompositeAlphaMode values.
     * @ref DoeWGPUCompositeAlphaMode_Auto will be an alias for the first element and will never be present in this array.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUCompositeAlphaMode const * alphaModes;
} DoeWGPUSurfaceCapabilities DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceCapabilities.
 */
#define DoeWGPU_SURFACE_CAPABILITIES_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceCapabilities, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.usages=*/DoeWGPUTextureUsage_None _wgpu_COMMA \
    /*.formatCount=*/0 _wgpu_COMMA \
    /*.formats=*/NULL _wgpu_COMMA \
    /*.presentModeCount=*/0 _wgpu_COMMA \
    /*.presentModes=*/NULL _wgpu_COMMA \
    /*.alphaModeCount=*/0 _wgpu_COMMA \
    /*.alphaModes=*/NULL _wgpu_COMMA \
})

/**
 * Extension of @ref DoeWGPUSurfaceConfiguration for color spaces and HDR.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_COLOR_MANAGEMENT_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceColorManagement {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to (@ref DoeWGPUPredefinedColorSpace)0.
     */
    DoeWGPUPredefinedColorSpace colorSpace;
    /**
     * The `INIT` macro sets this to (@ref DoeWGPUToneMappingMode)0.
     */
    DoeWGPUToneMappingMode toneMappingMode;
} DoeWGPUSurfaceColorManagement DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceColorManagement.
 */
#define DoeWGPU_SURFACE_COLOR_MANAGEMENT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceColorManagement, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceColorManagement _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.colorSpace=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUPredefinedColorSpace) _wgpu_COMMA \
    /*.toneMappingMode=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUToneMappingMode) _wgpu_COMMA \
})

/**
 * Options to @ref DoewgpuSurfaceConfigure for defining how a @ref DoeWGPUSurface will be rendered to and presented to the user.
 * See @ref Surface-Configuration for more details.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_CONFIGURATION_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceConfiguration {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The @ref DoeWGPUDevice to use to render to surface's textures.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUDevice device;
    /**
     * The @ref DoeWGPUTextureFormat of the surface's textures.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * The @ref DoeWGPUTextureUsage of the surface's textures.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureUsage_RenderAttachment.
     */
    DoeWGPUTextureUsage usage;
    /**
     * The width of the surface's textures.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint32_t width;
    /**
     * The height of the surface's textures.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint32_t height;
    /**
     * Array count for `viewFormats`. The `INIT` macro sets this to 0.
     */
    size_t viewFormatCount;
    /**
     * The additional @ref DoeWGPUTextureFormat for @ref DoeWGPUTextureView format reinterpretation of the surface's textures.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTextureFormat const * viewFormats;
    /**
     * How the surface's frames will be composited on the screen.
     *
     * If set to @ref DoeWGPUCompositeAlphaMode_Auto,
     * [defaults] to @ref DoeWGPUCompositeAlphaMode_Inherit in native (allowing the mode
     * to be configured externally), and to @ref DoeWGPUCompositeAlphaMode_Opaque in Wasm.
     *
     * The `INIT` macro sets this to @ref DoeWGPUCompositeAlphaMode_Auto.
     */
    DoeWGPUCompositeAlphaMode alphaMode;
    /**
     * When and in which order the surface's frames will be shown on the screen.
     *
     * If set to @ref DoeWGPUPresentMode_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUPresentMode_Fifo.
     *
     * The `INIT` macro sets this to @ref DoeWGPUPresentMode_Undefined.
     */
    DoeWGPUPresentMode presentMode;
} DoeWGPUSurfaceConfiguration DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceConfiguration.
 */
#define DoeWGPU_SURFACE_CONFIGURATION_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceConfiguration, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.device=*/NULL _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.usage=*/DoeWGPUTextureUsage_RenderAttachment _wgpu_COMMA \
    /*.width=*/0 _wgpu_COMMA \
    /*.height=*/0 _wgpu_COMMA \
    /*.viewFormatCount=*/0 _wgpu_COMMA \
    /*.viewFormats=*/NULL _wgpu_COMMA \
    /*.alphaMode=*/DoeWGPUCompositeAlphaMode_Auto _wgpu_COMMA \
    /*.presentMode=*/DoeWGPUPresentMode_Undefined _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping an Android [`ANativeWindow`](https://developer.android.com/ndk/reference/group/a-native-window).
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_ANDROID_NATIVE_WINDOW_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceAndroidNativeWindow {
    DoeWGPUChainedStruct chain;
    /**
     * The pointer to the [`ANativeWindow`](https://developer.android.com/ndk/reference/group/a-native-window) that will be wrapped by the @ref DoeWGPUSurface.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * window;
} DoeWGPUSurfaceSourceAndroidNativeWindow DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceAndroidNativeWindow.
 */
#define DoeWGPU_SURFACE_SOURCE_ANDROID_NATIVE_WINDOW_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceAndroidNativeWindow, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceAndroidNativeWindow _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.window=*/NULL _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping a [`CAMetalLayer`](https://developer.apple.com/documentation/quartzcore/cametallayer?language=objc).
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_METAL_LAYER_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceMetalLayer {
    DoeWGPUChainedStruct chain;
    /**
     * The pointer to the [`CAMetalLayer`](https://developer.apple.com/documentation/quartzcore/cametallayer?language=objc) that will be wrapped by the @ref DoeWGPUSurface.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * layer;
} DoeWGPUSurfaceSourceMetalLayer DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceMetalLayer.
 */
#define DoeWGPU_SURFACE_SOURCE_METAL_LAYER_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceMetalLayer, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceMetalLayer _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.layer=*/NULL _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping a [Wayland](https://wayland.freedesktop.org/) [`wl_surface`](https://wayland.freedesktop.org/docs/html/apa.html#protocol-spec-wl_surface).
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_WAYLAND_SURFACE_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceWaylandSurface {
    DoeWGPUChainedStruct chain;
    /**
     * A [`wl_display`](https://wayland.freedesktop.org/docs/html/apa.html#protocol-spec-wl_display) for this Wayland instance.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * display;
    /**
     * A [`wl_surface`](https://wayland.freedesktop.org/docs/html/apa.html#protocol-spec-wl_surface) that will be wrapped by the @ref DoeWGPUSurface
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * surface;
} DoeWGPUSurfaceSourceWaylandSurface DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceWaylandSurface.
 */
#define DoeWGPU_SURFACE_SOURCE_WAYLAND_SURFACE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceWaylandSurface, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceWaylandSurface _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.display=*/NULL _wgpu_COMMA \
    /*.surface=*/NULL _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping a Windows [`HWND`](https://learn.microsoft.com/en-us/windows/apps/develop/ui-input/retrieve-hwnd).
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_WINDOWS_HWND_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceWindowsHWND {
    DoeWGPUChainedStruct chain;
    /**
     * The [`HINSTANCE`](https://learn.microsoft.com/en-us/windows/win32/learnwin32/winmain--the-application-entry-point) for this application.
     * Most commonly `GetModuleHandle(nullptr)`.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * hinstance;
    /**
     * The [`HWND`](https://learn.microsoft.com/en-us/windows/apps/develop/ui-input/retrieve-hwnd) that will be wrapped by the @ref DoeWGPUSurface.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * hwnd;
} DoeWGPUSurfaceSourceWindowsHWND DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceWindowsHWND.
 */
#define DoeWGPU_SURFACE_SOURCE_WINDOWS_HWND_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceWindowsHWND, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceWindowsHWND _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.hinstance=*/NULL _wgpu_COMMA \
    /*.hwnd=*/NULL _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping an [XCB](https://xcb.freedesktop.org/) `xcb_window_t`.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_XCB_WINDOW_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceXCBWindow {
    DoeWGPUChainedStruct chain;
    /**
     * The `xcb_connection_t` for the connection to the X server.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * connection;
    /**
     * The `xcb_window_t` for the window that will be wrapped by the @ref DoeWGPUSurface.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint32_t window;
} DoeWGPUSurfaceSourceXCBWindow DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceXCBWindow.
 */
#define DoeWGPU_SURFACE_SOURCE_XCB_WINDOW_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceXCBWindow, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceXCBWindow _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.connection=*/NULL _wgpu_COMMA \
    /*.window=*/0 _wgpu_COMMA \
})

/**
 * Chained in @ref DoeWGPUSurfaceDescriptor to make an @ref DoeWGPUSurface wrapping an [Xlib](https://www.x.org/releases/current/doc/libX11/libX11/libX11.html) `Window`.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_SOURCE_XLIB_WINDOW_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceSourceXlibWindow {
    DoeWGPUChainedStruct chain;
    /**
     * A pointer to the [`Display`](https://www.x.org/releases/current/doc/libX11/libX11/libX11.html#Opening_the_Display) connected to the X server.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    void * display;
    /**
     * The [`Window`](https://www.x.org/releases/current/doc/libX11/libX11/libX11.html#Creating_Windows) that will be wrapped by the @ref DoeWGPUSurface.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t window;
} DoeWGPUSurfaceSourceXlibWindow DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceSourceXlibWindow.
 */
#define DoeWGPU_SURFACE_SOURCE_XLIB_WINDOW_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceSourceXlibWindow, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_SurfaceSourceXlibWindow _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.display=*/NULL _wgpu_COMMA \
    /*.window=*/0 _wgpu_COMMA \
})

/**
 * Queried each frame from a @ref DoeWGPUSurface to get a @ref DoeWGPUTexture to render to along with some metadata.
 * See @ref Surface-Presenting for more details.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_TEXTURE_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceTexture {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The @ref DoeWGPUTexture representing the frame that will be shown on the surface.
     * It is @ref ReturnedWithOwnership from @ref DoewgpuSurfaceGetCurrentTexture.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTexture texture;
    /**
     * Whether the call to @ref DoewgpuSurfaceGetCurrentTexture succeeded and a hint as to why it might not have.
     *
     * The `INIT` macro sets this to (@ref DoeWGPUSurfaceGetCurrentTextureStatus)0.
     */
    DoeWGPUSurfaceGetCurrentTextureStatus status;
} DoeWGPUSurfaceTexture DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceTexture.
 */
#define DoeWGPU_SURFACE_TEXTURE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceTexture, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.texture=*/NULL _wgpu_COMMA \
    /*.status=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUSurfaceGetCurrentTextureStatus) _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXEL_COPY_BUFFER_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUTexelCopyBufferLayout {
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint64_t offset;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_COPY_STRIDE_UNDEFINED.
     */
    uint32_t bytesPerRow;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_COPY_STRIDE_UNDEFINED.
     */
    uint32_t rowsPerImage;
} DoeWGPUTexelCopyBufferLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTexelCopyBufferLayout.
 */
#define DoeWGPU_TEXEL_COPY_BUFFER_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTexelCopyBufferLayout, { \
    /*.offset=*/0 _wgpu_COMMA \
    /*.bytesPerRow=*/DoeWGPU_COPY_STRIDE_UNDEFINED _wgpu_COMMA \
    /*.rowsPerImage=*/DoeWGPU_COPY_STRIDE_UNDEFINED _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXTURE_BINDING_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUTextureBindingLayout {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If set to @ref DoeWGPUTextureSampleType_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureSampleType_Float.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureSampleType_Undefined.
     */
    DoeWGPUTextureSampleType sampleType;
    /**
     * If set to @ref DoeWGPUTextureViewDimension_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureViewDimension_2D.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureViewDimension_Undefined.
     */
    DoeWGPUTextureViewDimension viewDimension;
    /**
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool multisampled;
} DoeWGPUTextureBindingLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureBindingLayout.
 */
#define DoeWGPU_TEXTURE_BINDING_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureBindingLayout, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.sampleType=*/DoeWGPUTextureSampleType_Undefined _wgpu_COMMA \
    /*.viewDimension=*/DoeWGPUTextureViewDimension_Undefined _wgpu_COMMA \
    /*.multisampled=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Note: While Compatibility Mode is optional to implement, this extension struct
 * is required to be accepted (but per the WebGPU spec, its contents are ignored
 * on devices that have the @ref DoeWGPUFeatureName_CoreFeaturesAndLimits feature).
 *
 * Default values can be set using @ref DoeWGPU_TEXTURE_BINDING_VIEW_DIMENSION_INIT as initializer.
 */
typedef struct DoeWGPUTextureBindingViewDimension {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureViewDimension_Undefined.
     */
    DoeWGPUTextureViewDimension textureBindingViewDimension;
} DoeWGPUTextureBindingViewDimension DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureBindingViewDimension.
 */
#define DoeWGPU_TEXTURE_BINDING_VIEW_DIMENSION_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureBindingViewDimension, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_TextureBindingViewDimension _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.textureBindingViewDimension=*/DoeWGPUTextureViewDimension_Undefined _wgpu_COMMA \
})

/**
 * When accessed by a shader, the red/green/blue/alpha channels are replaced
 * by the value corresponding to the component specified in r, g, b, and a,
 * respectively unlike the JS API which uses a string of length four, with
 * each character mapping to the texture view's red/green/blue/alpha channels.
 *
 * Default values can be set using @ref DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_INIT as initializer.
 */
typedef struct DoeWGPUTextureComponentSwizzle {
    /**
     * The value that replaces the red channel in the shader.
     *
     * If set to @ref DoeWGPUComponentSwizzle_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUComponentSwizzle_R.
     *
     * The `INIT` macro sets this to @ref DoeWGPUComponentSwizzle_Undefined.
     */
    DoeWGPUComponentSwizzle r;
    /**
     * The value that replaces the green channel in the shader.
     *
     * If set to @ref DoeWGPUComponentSwizzle_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUComponentSwizzle_G.
     *
     * The `INIT` macro sets this to @ref DoeWGPUComponentSwizzle_Undefined.
     */
    DoeWGPUComponentSwizzle g;
    /**
     * The value that replaces the blue channel in the shader.
     *
     * If set to @ref DoeWGPUComponentSwizzle_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUComponentSwizzle_B.
     *
     * The `INIT` macro sets this to @ref DoeWGPUComponentSwizzle_Undefined.
     */
    DoeWGPUComponentSwizzle b;
    /**
     * The value that replaces the alpha channel in the shader.
     *
     * If set to @ref DoeWGPUComponentSwizzle_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUComponentSwizzle_A.
     *
     * The `INIT` macro sets this to @ref DoeWGPUComponentSwizzle_Undefined.
     */
    DoeWGPUComponentSwizzle a;
} DoeWGPUTextureComponentSwizzle DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureComponentSwizzle.
 */
#define DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureComponentSwizzle, { \
    /*.r=*/DoeWGPUComponentSwizzle_Undefined _wgpu_COMMA \
    /*.g=*/DoeWGPUComponentSwizzle_Undefined _wgpu_COMMA \
    /*.b=*/DoeWGPUComponentSwizzle_Undefined _wgpu_COMMA \
    /*.a=*/DoeWGPUComponentSwizzle_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_VERTEX_ATTRIBUTE_INIT as initializer.
 */
typedef struct DoeWGPUVertexAttribute {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to (@ref DoeWGPUVertexFormat)0.
     */
    DoeWGPUVertexFormat format;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint64_t offset;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t shaderLocation;
} DoeWGPUVertexAttribute DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUVertexAttribute.
 */
#define DoeWGPU_VERTEX_ATTRIBUTE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUVertexAttribute, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.format=*/_wgpu_ENUM_ZERO_INIT(DoeWGPUVertexFormat) _wgpu_COMMA \
    /*.offset=*/0 _wgpu_COMMA \
    /*.shaderLocation=*/0 _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BIND_GROUP_ENTRY_INIT as initializer.
 */
typedef struct DoeWGPUBindGroupEntry {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Binding index in the bind group.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint32_t binding;
    /**
     * Set this if the binding is a buffer object.
     * Otherwise must be null.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUBuffer buffer;
    /**
     * If the binding is a buffer, this is the byte offset of the binding range.
     * Otherwise ignored.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint64_t offset;
    /**
     * If the binding is a buffer, this is the byte size of the binding range
     * (@ref DoeWGPU_WHOLE_SIZE means the binding ends at the end of the buffer).
     * Otherwise ignored.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_WHOLE_SIZE.
     */
    uint64_t size;
    /**
     * Set this if the binding is a sampler object.
     * Otherwise must be null.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUSampler sampler;
    /**
     * Set this if the binding is a texture view object.
     * Otherwise must be null.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUTextureView textureView;
} DoeWGPUBindGroupEntry DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBindGroupEntry.
 */
#define DoeWGPU_BIND_GROUP_ENTRY_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBindGroupEntry, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.binding=*/0 _wgpu_COMMA \
    /*.buffer=*/NULL _wgpu_COMMA \
    /*.offset=*/0 _wgpu_COMMA \
    /*.size=*/DoeWGPU_WHOLE_SIZE _wgpu_COMMA \
    /*.sampler=*/NULL _wgpu_COMMA \
    /*.textureView=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BIND_GROUP_LAYOUT_ENTRY_INIT as initializer.
 */
typedef struct DoeWGPUBindGroupLayoutEntry {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t binding;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUShaderStage_None.
     */
    DoeWGPUShaderStage visibility;
    /**
     * If non-zero, this entry defines a binding array with this size.
     *
     * The `INIT` macro sets this to `0`.
     */
    uint32_t bindingArraySize;
    /**
     * The `INIT` macro sets this to zero (which sets the entry to `BindingNotUsed`).
     */
    DoeWGPUBufferBindingLayout buffer;
    /**
     * The `INIT` macro sets this to zero (which sets the entry to `BindingNotUsed`).
     */
    DoeWGPUSamplerBindingLayout sampler;
    /**
     * The `INIT` macro sets this to zero (which sets the entry to `BindingNotUsed`).
     */
    DoeWGPUTextureBindingLayout texture;
    /**
     * The `INIT` macro sets this to zero (which sets the entry to `BindingNotUsed`).
     */
    DoeWGPUStorageTextureBindingLayout storageTexture;
} DoeWGPUBindGroupLayoutEntry DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBindGroupLayoutEntry.
 */
#define DoeWGPU_BIND_GROUP_LAYOUT_ENTRY_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBindGroupLayoutEntry, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.binding=*/0 _wgpu_COMMA \
    /*.visibility=*/DoeWGPUShaderStage_None _wgpu_COMMA \
    /*.bindingArraySize=*/0 _wgpu_COMMA \
    /*.buffer=*/_wgpu_STRUCT_ZERO_INIT _wgpu_COMMA \
    /*.sampler=*/_wgpu_STRUCT_ZERO_INIT _wgpu_COMMA \
    /*.texture=*/_wgpu_STRUCT_ZERO_INIT _wgpu_COMMA \
    /*.storageTexture=*/_wgpu_STRUCT_ZERO_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BLEND_STATE_INIT as initializer.
 */
typedef struct DoeWGPUBlendState {
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_BLEND_COMPONENT_INIT.
     */
    DoeWGPUBlendComponent color;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_BLEND_COMPONENT_INIT.
     */
    DoeWGPUBlendComponent alpha;
} DoeWGPUBlendState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBlendState.
 */
#define DoeWGPU_BLEND_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBlendState, { \
    /*.color=*/DoeWGPU_BLEND_COMPONENT_INIT _wgpu_COMMA \
    /*.alpha=*/DoeWGPU_BLEND_COMPONENT_INIT _wgpu_COMMA \
})

/**
 * This is an @ref ImplementationAllocatedStructChain root.
 * Arbitrary chains must be handled gracefully by the application!
 *
 * Default values can be set using @ref DoeWGPU_COMPILATION_INFO_INIT as initializer.
 */
typedef struct DoeWGPUCompilationInfo {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Array count for `messages`. The `INIT` macro sets this to 0.
     */
    size_t messageCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUCompilationMessage const * messages;
} DoeWGPUCompilationInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUCompilationInfo.
 */
#define DoeWGPU_COMPILATION_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUCompilationInfo, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.messageCount=*/0 _wgpu_COMMA \
    /*.messages=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COMPUTE_PASS_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUComputePassDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUPassTimestampWrites const * timestampWrites;
} DoeWGPUComputePassDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUComputePassDescriptor.
 */
#define DoeWGPU_COMPUTE_PASS_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUComputePassDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.timestampWrites=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COMPUTE_STATE_INIT as initializer.
 */
typedef struct DoeWGPUComputeState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUShaderModule module;
    /**
     * This is a \ref NullableInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView entryPoint;
    /**
     * Array count for `constants`. The `INIT` macro sets this to 0.
     */
    size_t constantCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUConstantEntry const * constants;
} DoeWGPUComputeState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUComputeState.
 */
#define DoeWGPU_COMPUTE_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUComputeState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.module=*/NULL _wgpu_COMMA \
    /*.entryPoint=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.constantCount=*/0 _wgpu_COMMA \
    /*.constants=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_DEPTH_STENCIL_STATE_INIT as initializer.
 */
typedef struct DoeWGPUDepthStencilState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUOptionalBool_Undefined.
     */
    DoeWGPUOptionalBool depthWriteEnabled;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUCompareFunction_Undefined.
     */
    DoeWGPUCompareFunction depthCompare;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_STENCIL_FACE_STATE_INIT.
     */
    DoeWGPUStencilFaceState stencilFront;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_STENCIL_FACE_STATE_INIT.
     */
    DoeWGPUStencilFaceState stencilBack;
    /**
     * The `INIT` macro sets this to `0xFFFFFFFF`.
     */
    uint32_t stencilReadMask;
    /**
     * The `INIT` macro sets this to `0xFFFFFFFF`.
     */
    uint32_t stencilWriteMask;
    /**
     * The `INIT` macro sets this to `0`.
     */
    int32_t depthBias;
    /**
     * TODO
     *
     * If non-finite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to `0.f`.
     */
    float depthBiasSlopeScale;
    /**
     * TODO
     *
     * If non-finite, produces a @ref NonFiniteFloatValueError.
     *
     * The `INIT` macro sets this to `0.f`.
     */
    float depthBiasClamp;
} DoeWGPUDepthStencilState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUDepthStencilState.
 */
#define DoeWGPU_DEPTH_STENCIL_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUDepthStencilState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.depthWriteEnabled=*/DoeWGPUOptionalBool_Undefined _wgpu_COMMA \
    /*.depthCompare=*/DoeWGPUCompareFunction_Undefined _wgpu_COMMA \
    /*.stencilFront=*/DoeWGPU_STENCIL_FACE_STATE_INIT _wgpu_COMMA \
    /*.stencilBack=*/DoeWGPU_STENCIL_FACE_STATE_INIT _wgpu_COMMA \
    /*.stencilReadMask=*/0xFFFFFFFF _wgpu_COMMA \
    /*.stencilWriteMask=*/0xFFFFFFFF _wgpu_COMMA \
    /*.depthBias=*/0 _wgpu_COMMA \
    /*.depthBiasSlopeScale=*/0.f _wgpu_COMMA \
    /*.depthBiasClamp=*/0.f _wgpu_COMMA \
})

/**
 * Struct holding a future to wait on, and a `completed` boolean flag.
 *
 * Default values can be set using @ref DoeWGPU_FUTURE_WAIT_INFO_INIT as initializer.
 */
typedef struct DoeWGPUFutureWaitInfo {
    /**
     * The future to wait on.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_FUTURE_INIT.
     */
    DoeWGPUFuture future;
    /**
     * Whether or not the future completed.
     *
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool completed;
} DoeWGPUFutureWaitInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUFutureWaitInfo.
 */
#define DoeWGPU_FUTURE_WAIT_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUFutureWaitInfo, { \
    /*.future=*/DoeWGPU_FUTURE_INIT _wgpu_COMMA \
    /*.completed=*/DoeWGPU_FALSE _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_INSTANCE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUInstanceDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Array count for `requiredFeatures`. The `INIT` macro sets this to 0.
     */
    size_t requiredFeatureCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUInstanceFeatureName const * requiredFeatures;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUInstanceLimits const * requiredLimits;
} DoeWGPUInstanceDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUInstanceDescriptor.
 */
#define DoeWGPU_INSTANCE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUInstanceDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.requiredFeatureCount=*/0 _wgpu_COMMA \
    /*.requiredFeatures=*/NULL _wgpu_COMMA \
    /*.requiredLimits=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_LIMITS_INIT as initializer.
 */
typedef struct DoeWGPULimits {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxTextureDimension1D;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxTextureDimension2D;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxTextureDimension3D;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxTextureArrayLayers;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxBindGroups;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxBindGroupsPlusVertexBuffers;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxBindingsPerBindGroup;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxDynamicUniformBuffersPerPipelineLayout;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxDynamicStorageBuffersPerPipelineLayout;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxSampledTexturesPerShaderStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxSamplersPerShaderStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageBuffersPerShaderStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxStorageTexturesPerShaderStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxUniformBuffersPerShaderStage;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U64_UNDEFINED.
     */
    uint64_t maxUniformBufferBindingSize;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U64_UNDEFINED.
     */
    uint64_t maxStorageBufferBindingSize;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t minUniformBufferOffsetAlignment;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t minStorageBufferOffsetAlignment;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxVertexBuffers;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U64_UNDEFINED.
     */
    uint64_t maxBufferSize;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxVertexAttributes;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxVertexBufferArrayStride;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxInterStageShaderVariables;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxColorAttachments;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxColorAttachmentBytesPerSample;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeWorkgroupStorageSize;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeInvocationsPerWorkgroup;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeWorkgroupSizeX;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeWorkgroupSizeY;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeWorkgroupSizeZ;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxComputeWorkgroupsPerDimension;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_LIMIT_U32_UNDEFINED.
     */
    uint32_t maxImmediateSize;
} DoeWGPULimits DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPULimits.
 */
#define DoeWGPU_LIMITS_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPULimits, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.maxTextureDimension1D=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxTextureDimension2D=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxTextureDimension3D=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxTextureArrayLayers=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxBindGroups=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxBindGroupsPlusVertexBuffers=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxBindingsPerBindGroup=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxDynamicUniformBuffersPerPipelineLayout=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxDynamicStorageBuffersPerPipelineLayout=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxSampledTexturesPerShaderStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxSamplersPerShaderStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxStorageBuffersPerShaderStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxStorageTexturesPerShaderStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxUniformBuffersPerShaderStage=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxUniformBufferBindingSize=*/DoeWGPU_LIMIT_U64_UNDEFINED _wgpu_COMMA \
    /*.maxStorageBufferBindingSize=*/DoeWGPU_LIMIT_U64_UNDEFINED _wgpu_COMMA \
    /*.minUniformBufferOffsetAlignment=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.minStorageBufferOffsetAlignment=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxVertexBuffers=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxBufferSize=*/DoeWGPU_LIMIT_U64_UNDEFINED _wgpu_COMMA \
    /*.maxVertexAttributes=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxVertexBufferArrayStride=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxInterStageShaderVariables=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxColorAttachments=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxColorAttachmentBytesPerSample=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeWorkgroupStorageSize=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeInvocationsPerWorkgroup=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeWorkgroupSizeX=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeWorkgroupSizeY=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeWorkgroupSizeZ=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxComputeWorkgroupsPerDimension=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
    /*.maxImmediateSize=*/DoeWGPU_LIMIT_U32_UNDEFINED _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_PASS_COLOR_ATTACHMENT_INIT as initializer.
 */
typedef struct DoeWGPURenderPassColorAttachment {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * If `NULL`, indicates a hole in the parent
     * @ref DoeWGPURenderPassDescriptor::colorAttachments array.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUTextureView view;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_DEPTH_SLICE_UNDEFINED.
     */
    uint32_t depthSlice;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUTextureView resolveTarget;
    /**
     * The `INIT` macro sets this to @ref DoeWGPULoadOp_Undefined.
     */
    DoeWGPULoadOp loadOp;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUStoreOp_Undefined.
     */
    DoeWGPUStoreOp storeOp;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_COLOR_INIT.
     */
    DoeWGPUColor clearValue;
} DoeWGPURenderPassColorAttachment DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderPassColorAttachment.
 */
#define DoeWGPU_RENDER_PASS_COLOR_ATTACHMENT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderPassColorAttachment, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.view=*/NULL _wgpu_COMMA \
    /*.depthSlice=*/DoeWGPU_DEPTH_SLICE_UNDEFINED _wgpu_COMMA \
    /*.resolveTarget=*/NULL _wgpu_COMMA \
    /*.loadOp=*/DoeWGPULoadOp_Undefined _wgpu_COMMA \
    /*.storeOp=*/DoeWGPUStoreOp_Undefined _wgpu_COMMA \
    /*.clearValue=*/DoeWGPU_COLOR_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_REQUEST_ADAPTER_OPTIONS_INIT as initializer.
 */
typedef struct DoeWGPURequestAdapterOptions {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * "Feature level" for the adapter request. If an adapter is returned, it must support the features and limits in the requested feature level.
     *
     * If set to @ref DoeWGPUFeatureLevel_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUFeatureLevel_Core.
     * Additionally, implementations may ignore @ref DoeWGPUFeatureLevel_Compatibility
     * and provide @ref DoeWGPUFeatureLevel_Core instead.
     *
     * The `INIT` macro sets this to @ref DoeWGPUFeatureLevel_Undefined.
     */
    DoeWGPUFeatureLevel featureLevel;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUPowerPreference_Undefined.
     */
    DoeWGPUPowerPreference powerPreference;
    /**
     * If true, requires the adapter to be a "fallback" adapter as defined by the JS spec.
     * If this is not possible, the request returns null.
     *
     * The `INIT` macro sets this to `DoeWGPU_FALSE`.
     */
    DoeWGPUBool forceFallbackAdapter;
    /**
     * If set, requires the adapter to have a particular backend type.
     * If this is not possible, the request returns null.
     *
     * The `INIT` macro sets this to @ref DoeWGPUBackendType_Undefined.
     */
    DoeWGPUBackendType backendType;
    /**
     * If set, requires the adapter to be able to output to a particular surface.
     * If this is not possible, the request returns null.
     *
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUSurface compatibleSurface;
} DoeWGPURequestAdapterOptions DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURequestAdapterOptions.
 */
#define DoeWGPU_REQUEST_ADAPTER_OPTIONS_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURequestAdapterOptions, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.featureLevel=*/DoeWGPUFeatureLevel_Undefined _wgpu_COMMA \
    /*.powerPreference=*/DoeWGPUPowerPreference_Undefined _wgpu_COMMA \
    /*.forceFallbackAdapter=*/DoeWGPU_FALSE _wgpu_COMMA \
    /*.backendType=*/DoeWGPUBackendType_Undefined _wgpu_COMMA \
    /*.compatibleSurface=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_SHADER_MODULE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUShaderModuleDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPUShaderModuleDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUShaderModuleDescriptor.
 */
#define DoeWGPU_SHADER_MODULE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUShaderModuleDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * The root descriptor for the creation of an @ref DoeWGPUSurface with @ref DoewgpuInstanceCreateSurface.
 * It isn't sufficient by itself and must have one of the `DoeWGPUSurfaceSource*` in its chain.
 * See @ref Surface-Creation for more details.
 *
 * Default values can be set using @ref DoeWGPU_SURFACE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUSurfaceDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * Label used to refer to the object.
     *
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
} DoeWGPUSurfaceDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUSurfaceDescriptor.
 */
#define DoeWGPU_SURFACE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUSurfaceDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXEL_COPY_BUFFER_INFO_INIT as initializer.
 */
typedef struct DoeWGPUTexelCopyBufferInfo {
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_TEXEL_COPY_BUFFER_LAYOUT_INIT.
     */
    DoeWGPUTexelCopyBufferLayout layout;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUBuffer buffer;
} DoeWGPUTexelCopyBufferInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTexelCopyBufferInfo.
 */
#define DoeWGPU_TEXEL_COPY_BUFFER_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTexelCopyBufferInfo, { \
    /*.layout=*/DoeWGPU_TEXEL_COPY_BUFFER_LAYOUT_INIT _wgpu_COMMA \
    /*.buffer=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXEL_COPY_TEXTURE_INFO_INIT as initializer.
 */
typedef struct DoeWGPUTexelCopyTextureInfo {
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTexture texture;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t mipLevel;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_ORIGIN_3D_INIT.
     */
    DoeWGPUOrigin3D origin;
    /**
     * If set to @ref DoeWGPUTextureAspect_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureAspect_All.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureAspect_Undefined.
     */
    DoeWGPUTextureAspect aspect;
} DoeWGPUTexelCopyTextureInfo DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTexelCopyTextureInfo.
 */
#define DoeWGPU_TEXEL_COPY_TEXTURE_INFO_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTexelCopyTextureInfo, { \
    /*.texture=*/NULL _wgpu_COMMA \
    /*.mipLevel=*/0 _wgpu_COMMA \
    /*.origin=*/DoeWGPU_ORIGIN_3D_INIT _wgpu_COMMA \
    /*.aspect=*/DoeWGPUTextureAspect_Undefined _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUTextureComponentSwizzleDescriptor {
    DoeWGPUChainedStruct chain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_INIT.
     */
    DoeWGPUTextureComponentSwizzle swizzle;
} DoeWGPUTextureComponentSwizzleDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureComponentSwizzleDescriptor.
 */
#define DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureComponentSwizzleDescriptor, { \
    /*.chain=*/_wgpu_MAKE_INIT_STRUCT(DoeWGPUChainedStruct, { \
        /*.next=*/NULL _wgpu_COMMA \
        /*.sType=*/DoeWGPUSType_TextureComponentSwizzleDescriptor _wgpu_COMMA \
    }) _wgpu_COMMA \
    /*.swizzle=*/DoeWGPU_TEXTURE_COMPONENT_SWIZZLE_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXTURE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUTextureDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureUsage_None.
     */
    DoeWGPUTextureUsage usage;
    /**
     * If set to @ref DoeWGPUTextureDimension_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureDimension_2D.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureDimension_Undefined.
     */
    DoeWGPUTextureDimension dimension;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_EXTENT_3D_INIT.
     */
    DoeWGPUExtent3D size;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t mipLevelCount;
    /**
     * The `INIT` macro sets this to `1`.
     */
    uint32_t sampleCount;
    /**
     * Array count for `viewFormats`. The `INIT` macro sets this to 0.
     */
    size_t viewFormatCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUTextureFormat const * viewFormats;
} DoeWGPUTextureDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureDescriptor.
 */
#define DoeWGPU_TEXTURE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.usage=*/DoeWGPUTextureUsage_None _wgpu_COMMA \
    /*.dimension=*/DoeWGPUTextureDimension_Undefined _wgpu_COMMA \
    /*.size=*/DoeWGPU_EXTENT_3D_INIT _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.mipLevelCount=*/1 _wgpu_COMMA \
    /*.sampleCount=*/1 _wgpu_COMMA \
    /*.viewFormatCount=*/0 _wgpu_COMMA \
    /*.viewFormats=*/NULL _wgpu_COMMA \
})

/**
 * If `attributes` is empty *and* `stepMode` is @ref DoeWGPUVertexStepMode_Undefined,
 * indicates a "hole" in the parent @ref DoeWGPUVertexState `buffers` array,
 * with behavior equivalent to `null` in the JS API.
 *
 * If `attributes` is empty but `stepMode` is *not* @ref DoeWGPUVertexStepMode_Undefined,
 * indicates a vertex buffer with no attributes, with behavior equivalent to
 * `{ attributes: [] }` in the JS API. (TODO: If the JS API changes not to
 * distinguish these cases, then this distinction doesn't matter and we can
 * remove this documentation.)
 *
 * If `stepMode` is @ref DoeWGPUVertexStepMode_Undefined but `attributes` is *not* empty,
 * `stepMode` [defaults](@ref SentinelValues) to @ref DoeWGPUVertexStepMode_Vertex.
 *
 * Default values can be set using @ref DoeWGPU_VERTEX_BUFFER_LAYOUT_INIT as initializer.
 */
typedef struct DoeWGPUVertexBufferLayout {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUVertexStepMode_Undefined.
     */
    DoeWGPUVertexStepMode stepMode;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint64_t arrayStride;
    /**
     * Array count for `attributes`. The `INIT` macro sets this to 0.
     */
    size_t attributeCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUVertexAttribute const * attributes;
} DoeWGPUVertexBufferLayout DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUVertexBufferLayout.
 */
#define DoeWGPU_VERTEX_BUFFER_LAYOUT_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUVertexBufferLayout, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.stepMode=*/DoeWGPUVertexStepMode_Undefined _wgpu_COMMA \
    /*.arrayStride=*/0 _wgpu_COMMA \
    /*.attributeCount=*/0 _wgpu_COMMA \
    /*.attributes=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BIND_GROUP_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUBindGroupDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUBindGroupLayout layout;
    /**
     * Array count for `entries`. The `INIT` macro sets this to 0.
     */
    size_t entryCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUBindGroupEntry const * entries;
} DoeWGPUBindGroupDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBindGroupDescriptor.
 */
#define DoeWGPU_BIND_GROUP_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBindGroupDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.layout=*/NULL _wgpu_COMMA \
    /*.entryCount=*/0 _wgpu_COMMA \
    /*.entries=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_BIND_GROUP_LAYOUT_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUBindGroupLayoutDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * Array count for `entries`. The `INIT` macro sets this to 0.
     */
    size_t entryCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUBindGroupLayoutEntry const * entries;
} DoeWGPUBindGroupLayoutDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUBindGroupLayoutDescriptor.
 */
#define DoeWGPU_BIND_GROUP_LAYOUT_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUBindGroupLayoutDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.entryCount=*/0 _wgpu_COMMA \
    /*.entries=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COLOR_TARGET_STATE_INIT as initializer.
 */
typedef struct DoeWGPUColorTargetState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The texture format of the target. If @ref DoeWGPUTextureFormat_Undefined,
     * indicates a "hole" in the parent @ref DoeWGPUFragmentState `targets` array:
     * the pipeline does not output a value at this `location`.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUBlendState const * blend;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUColorWriteMask_All.
     */
    DoeWGPUColorWriteMask writeMask;
} DoeWGPUColorTargetState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUColorTargetState.
 */
#define DoeWGPU_COLOR_TARGET_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUColorTargetState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.blend=*/NULL _wgpu_COMMA \
    /*.writeMask=*/DoeWGPUColorWriteMask_All _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_COMPUTE_PIPELINE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUComputePipelineDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUPipelineLayout layout;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_COMPUTE_STATE_INIT.
     */
    DoeWGPUComputeState compute;
} DoeWGPUComputePipelineDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUComputePipelineDescriptor.
 */
#define DoeWGPU_COMPUTE_PIPELINE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUComputePipelineDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.layout=*/NULL _wgpu_COMMA \
    /*.compute=*/DoeWGPU_COMPUTE_STATE_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_DEVICE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUDeviceDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * Array count for `requiredFeatures`. The `INIT` macro sets this to 0.
     */
    size_t requiredFeatureCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUFeatureName const * requiredFeatures;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPULimits const * requiredLimits;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_QUEUE_DESCRIPTOR_INIT.
     */
    DoeWGPUQueueDescriptor defaultQueue;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_DEVICE_LOST_CALLBACK_INFO_INIT.
     */
    DoeWGPUDeviceLostCallbackInfo deviceLostCallbackInfo;
    /**
     * Called when there is an uncaptured error on this device, from any thread.
     * See @ref ErrorScopes.
     *
     * **Important:** This callback does not have a configurable @ref DoeWGPUCallbackMode; it may be called at any time (like @ref DoeWGPUCallbackMode_AllowSpontaneous). As such, calls into the `webgpu.h` API from this callback are unsafe. See @ref CallbackReentrancy.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_UNCAPTURED_ERROR_CALLBACK_INFO_INIT.
     */
    DoeWGPUUncapturedErrorCallbackInfo uncapturedErrorCallbackInfo;
} DoeWGPUDeviceDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUDeviceDescriptor.
 */
#define DoeWGPU_DEVICE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUDeviceDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.requiredFeatureCount=*/0 _wgpu_COMMA \
    /*.requiredFeatures=*/NULL _wgpu_COMMA \
    /*.requiredLimits=*/NULL _wgpu_COMMA \
    /*.defaultQueue=*/DoeWGPU_QUEUE_DESCRIPTOR_INIT _wgpu_COMMA \
    /*.deviceLostCallbackInfo=*/DoeWGPU_DEVICE_LOST_CALLBACK_INFO_INIT _wgpu_COMMA \
    /*.uncapturedErrorCallbackInfo=*/DoeWGPU_UNCAPTURED_ERROR_CALLBACK_INFO_INIT _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_PASS_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPURenderPassDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * Array count for `colorAttachments`. The `INIT` macro sets this to 0.
     */
    size_t colorAttachmentCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPURenderPassColorAttachment const * colorAttachments;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPURenderPassDepthStencilAttachment const * depthStencilAttachment;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUQuerySet occlusionQuerySet;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUPassTimestampWrites const * timestampWrites;
} DoeWGPURenderPassDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderPassDescriptor.
 */
#define DoeWGPU_RENDER_PASS_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderPassDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.colorAttachmentCount=*/0 _wgpu_COMMA \
    /*.colorAttachments=*/NULL _wgpu_COMMA \
    /*.depthStencilAttachment=*/NULL _wgpu_COMMA \
    /*.occlusionQuerySet=*/NULL _wgpu_COMMA \
    /*.timestampWrites=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_TEXTURE_VIEW_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPUTextureViewDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureFormat_Undefined.
     */
    DoeWGPUTextureFormat format;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureViewDimension_Undefined.
     */
    DoeWGPUTextureViewDimension dimension;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t baseMipLevel;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_MIP_LEVEL_COUNT_UNDEFINED.
     */
    uint32_t mipLevelCount;
    /**
     * The `INIT` macro sets this to `0`.
     */
    uint32_t baseArrayLayer;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_ARRAY_LAYER_COUNT_UNDEFINED.
     */
    uint32_t arrayLayerCount;
    /**
     * If set to @ref DoeWGPUTextureAspect_Undefined,
     * [defaults](@ref SentinelValues) to @ref DoeWGPUTextureAspect_All.
     *
     * The `INIT` macro sets this to @ref DoeWGPUTextureAspect_Undefined.
     */
    DoeWGPUTextureAspect aspect;
    /**
     * The `INIT` macro sets this to @ref DoeWGPUTextureUsage_None.
     */
    DoeWGPUTextureUsage usage;
} DoeWGPUTextureViewDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUTextureViewDescriptor.
 */
#define DoeWGPU_TEXTURE_VIEW_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUTextureViewDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.format=*/DoeWGPUTextureFormat_Undefined _wgpu_COMMA \
    /*.dimension=*/DoeWGPUTextureViewDimension_Undefined _wgpu_COMMA \
    /*.baseMipLevel=*/0 _wgpu_COMMA \
    /*.mipLevelCount=*/DoeWGPU_MIP_LEVEL_COUNT_UNDEFINED _wgpu_COMMA \
    /*.baseArrayLayer=*/0 _wgpu_COMMA \
    /*.arrayLayerCount=*/DoeWGPU_ARRAY_LAYER_COUNT_UNDEFINED _wgpu_COMMA \
    /*.aspect=*/DoeWGPUTextureAspect_Undefined _wgpu_COMMA \
    /*.usage=*/DoeWGPUTextureUsage_None _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_VERTEX_STATE_INIT as initializer.
 */
typedef struct DoeWGPUVertexState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUShaderModule module;
    /**
     * This is a \ref NullableInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView entryPoint;
    /**
     * Array count for `constants`. The `INIT` macro sets this to 0.
     */
    size_t constantCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUConstantEntry const * constants;
    /**
     * Array count for `buffers`. The `INIT` macro sets this to 0.
     */
    size_t bufferCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUVertexBufferLayout const * buffers;
} DoeWGPUVertexState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUVertexState.
 */
#define DoeWGPU_VERTEX_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUVertexState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.module=*/NULL _wgpu_COMMA \
    /*.entryPoint=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.constantCount=*/0 _wgpu_COMMA \
    /*.constants=*/NULL _wgpu_COMMA \
    /*.bufferCount=*/0 _wgpu_COMMA \
    /*.buffers=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_FRAGMENT_STATE_INIT as initializer.
 */
typedef struct DoeWGPUFragmentState {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUShaderModule module;
    /**
     * This is a \ref NullableInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView entryPoint;
    /**
     * Array count for `constants`. The `INIT` macro sets this to 0.
     */
    size_t constantCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUConstantEntry const * constants;
    /**
     * Array count for `targets`. The `INIT` macro sets this to 0.
     */
    size_t targetCount;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPUColorTargetState const * targets;
} DoeWGPUFragmentState DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPUFragmentState.
 */
#define DoeWGPU_FRAGMENT_STATE_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPUFragmentState, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.module=*/NULL _wgpu_COMMA \
    /*.entryPoint=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.constantCount=*/0 _wgpu_COMMA \
    /*.constants=*/NULL _wgpu_COMMA \
    /*.targetCount=*/0 _wgpu_COMMA \
    /*.targets=*/NULL _wgpu_COMMA \
})

/**
 * Default values can be set using @ref DoeWGPU_RENDER_PIPELINE_DESCRIPTOR_INIT as initializer.
 */
typedef struct DoeWGPURenderPipelineDescriptor {
    DoeWGPUChainedStruct * nextInChain;
    /**
     * This is a \ref NonNullInputString.
     *
     * The `INIT` macro sets this to @ref DoeWGPU_STRING_VIEW_INIT.
     */
    DoeWGPUStringView label;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUPipelineLayout layout;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_VERTEX_STATE_INIT.
     */
    DoeWGPUVertexState vertex;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_PRIMITIVE_STATE_INIT.
     */
    DoeWGPUPrimitiveState primitive;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUDepthStencilState const * depthStencil;
    /**
     * The `INIT` macro sets this to @ref DoeWGPU_MULTISAMPLE_STATE_INIT.
     */
    DoeWGPUMultisampleState multisample;
    /**
     * The `INIT` macro sets this to `NULL`.
     */
    DoeWGPU_NULLABLE DoeWGPUFragmentState const * fragment;
} DoeWGPURenderPipelineDescriptor DoeWGPU_STRUCTURE_ATTRIBUTE;

/**
 * Initializer for @ref DoeWGPURenderPipelineDescriptor.
 */
#define DoeWGPU_RENDER_PIPELINE_DESCRIPTOR_INIT _wgpu_MAKE_INIT_STRUCT(DoeWGPURenderPipelineDescriptor, { \
    /*.nextInChain=*/NULL _wgpu_COMMA \
    /*.label=*/DoeWGPU_STRING_VIEW_INIT _wgpu_COMMA \
    /*.layout=*/NULL _wgpu_COMMA \
    /*.vertex=*/DoeWGPU_VERTEX_STATE_INIT _wgpu_COMMA \
    /*.primitive=*/DoeWGPU_PRIMITIVE_STATE_INIT _wgpu_COMMA \
    /*.depthStencil=*/NULL _wgpu_COMMA \
    /*.multisample=*/DoeWGPU_MULTISAMPLE_STATE_INIT _wgpu_COMMA \
    /*.fragment=*/NULL _wgpu_COMMA \
})

/** @} */

#ifdef __cplusplus
extern "C" {
#endif

#if !defined(DoeWGPU_SKIP_PROCS)
// Global procs
/**
 * Proc pointer type for @ref DoewgpuCreateInstance:
 * > @copydoc DoewgpuCreateInstance
 */
typedef DoeWGPUInstance (*DoeWGPUProcCreateInstance)(DoeWGPU_NULLABLE DoeWGPUInstanceDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuGetInstanceFeatures:
 * > @copydoc DoewgpuGetInstanceFeatures
 */
typedef void (*DoeWGPUProcGetInstanceFeatures)(DoeWGPUSupportedInstanceFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuGetInstanceLimits:
 * > @copydoc DoewgpuGetInstanceLimits
 */
typedef DoeWGPUStatus (*DoeWGPUProcGetInstanceLimits)(DoeWGPUInstanceLimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuHasInstanceFeature:
 * > @copydoc DoewgpuHasInstanceFeature
 */
typedef DoeWGPUBool (*DoeWGPUProcHasInstanceFeature)(DoeWGPUInstanceFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuGetProcAddress:
 * > @copydoc DoewgpuGetProcAddress
 */
typedef DoeWGPUProc (*DoeWGPUProcGetProcAddress)(DoeWGPUStringView procName) DoeWGPU_FUNCTION_ATTRIBUTE;


// Procs of Adapter
/**
 * Proc pointer type for @ref DoewgpuAdapterGetFeatures:
 * > @copydoc DoewgpuAdapterGetFeatures
 */
typedef void (*DoeWGPUProcAdapterGetFeatures)(DoeWGPUAdapter adapter, DoeWGPUSupportedFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterGetInfo:
 * > @copydoc DoewgpuAdapterGetInfo
 */
typedef DoeWGPUStatus (*DoeWGPUProcAdapterGetInfo)(DoeWGPUAdapter adapter, DoeWGPUAdapterInfo * info) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterGetLimits:
 * > @copydoc DoewgpuAdapterGetLimits
 */
typedef DoeWGPUStatus (*DoeWGPUProcAdapterGetLimits)(DoeWGPUAdapter adapter, DoeWGPULimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterHasFeature:
 * > @copydoc DoewgpuAdapterHasFeature
 */
typedef DoeWGPUBool (*DoeWGPUProcAdapterHasFeature)(DoeWGPUAdapter adapter, DoeWGPUFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterRequestDevice:
 * > @copydoc DoewgpuAdapterRequestDevice
 */
typedef DoeWGPUFuture (*DoeWGPUProcAdapterRequestDevice)(DoeWGPUAdapter adapter, DoeWGPU_NULLABLE DoeWGPUDeviceDescriptor const * descriptor, DoeWGPURequestDeviceCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterAddRef:
 * > @copydoc DoewgpuAdapterAddRef
 */
typedef void (*DoeWGPUProcAdapterAddRef)(DoeWGPUAdapter adapter) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuAdapterRelease:
 * > @copydoc DoewgpuAdapterRelease
 */
typedef void (*DoeWGPUProcAdapterRelease)(DoeWGPUAdapter adapter) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of AdapterInfo
/**
 * Proc pointer type for @ref DoewgpuAdapterInfoFreeMembers:
 * > @copydoc DoewgpuAdapterInfoFreeMembers
 */
typedef void (*DoeWGPUProcAdapterInfoFreeMembers)(DoeWGPUAdapterInfo adapterInfo) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of BindGroup
/**
 * Proc pointer type for @ref DoewgpuBindGroupSetLabel:
 * > @copydoc DoewgpuBindGroupSetLabel
 */
typedef void (*DoeWGPUProcBindGroupSetLabel)(DoeWGPUBindGroup bindGroup, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBindGroupAddRef:
 * > @copydoc DoewgpuBindGroupAddRef
 */
typedef void (*DoeWGPUProcBindGroupAddRef)(DoeWGPUBindGroup bindGroup) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBindGroupRelease:
 * > @copydoc DoewgpuBindGroupRelease
 */
typedef void (*DoeWGPUProcBindGroupRelease)(DoeWGPUBindGroup bindGroup) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of BindGroupLayout
/**
 * Proc pointer type for @ref DoewgpuBindGroupLayoutSetLabel:
 * > @copydoc DoewgpuBindGroupLayoutSetLabel
 */
typedef void (*DoeWGPUProcBindGroupLayoutSetLabel)(DoeWGPUBindGroupLayout bindGroupLayout, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBindGroupLayoutAddRef:
 * > @copydoc DoewgpuBindGroupLayoutAddRef
 */
typedef void (*DoeWGPUProcBindGroupLayoutAddRef)(DoeWGPUBindGroupLayout bindGroupLayout) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBindGroupLayoutRelease:
 * > @copydoc DoewgpuBindGroupLayoutRelease
 */
typedef void (*DoeWGPUProcBindGroupLayoutRelease)(DoeWGPUBindGroupLayout bindGroupLayout) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Buffer
/**
 * Proc pointer type for @ref DoewgpuBufferDestroy:
 * > @copydoc DoewgpuBufferDestroy
 */
typedef void (*DoeWGPUProcBufferDestroy)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferGetConstMappedRange:
 * > @copydoc DoewgpuBufferGetConstMappedRange
 */
typedef void const * (*DoeWGPUProcBufferGetConstMappedRange)(DoeWGPUBuffer buffer, size_t offset, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferGetMappedRange:
 * > @copydoc DoewgpuBufferGetMappedRange
 */
typedef void * (*DoeWGPUProcBufferGetMappedRange)(DoeWGPUBuffer buffer, size_t offset, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferGetMapState:
 * > @copydoc DoewgpuBufferGetMapState
 */
typedef DoeWGPUBufferMapState (*DoeWGPUProcBufferGetMapState)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferGetSize:
 * > @copydoc DoewgpuBufferGetSize
 */
typedef uint64_t (*DoeWGPUProcBufferGetSize)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferGetUsage:
 * > @copydoc DoewgpuBufferGetUsage
 */
typedef DoeWGPUBufferUsage (*DoeWGPUProcBufferGetUsage)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferMapAsync:
 * > @copydoc DoewgpuBufferMapAsync
 */
typedef DoeWGPUFuture (*DoeWGPUProcBufferMapAsync)(DoeWGPUBuffer buffer, DoeWGPUMapMode mode, size_t offset, size_t size, DoeWGPUBufferMapCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferReadMappedRange:
 * > @copydoc DoewgpuBufferReadMappedRange
 */
typedef DoeWGPUStatus (*DoeWGPUProcBufferReadMappedRange)(DoeWGPUBuffer buffer, size_t offset, void * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferSetLabel:
 * > @copydoc DoewgpuBufferSetLabel
 */
typedef void (*DoeWGPUProcBufferSetLabel)(DoeWGPUBuffer buffer, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferUnmap:
 * > @copydoc DoewgpuBufferUnmap
 */
typedef void (*DoeWGPUProcBufferUnmap)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferWriteMappedRange:
 * > @copydoc DoewgpuBufferWriteMappedRange
 */
typedef DoeWGPUStatus (*DoeWGPUProcBufferWriteMappedRange)(DoeWGPUBuffer buffer, size_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferAddRef:
 * > @copydoc DoewgpuBufferAddRef
 */
typedef void (*DoeWGPUProcBufferAddRef)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuBufferRelease:
 * > @copydoc DoewgpuBufferRelease
 */
typedef void (*DoeWGPUProcBufferRelease)(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of CommandBuffer
/**
 * Proc pointer type for @ref DoewgpuCommandBufferSetLabel:
 * > @copydoc DoewgpuCommandBufferSetLabel
 */
typedef void (*DoeWGPUProcCommandBufferSetLabel)(DoeWGPUCommandBuffer commandBuffer, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandBufferAddRef:
 * > @copydoc DoewgpuCommandBufferAddRef
 */
typedef void (*DoeWGPUProcCommandBufferAddRef)(DoeWGPUCommandBuffer commandBuffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandBufferRelease:
 * > @copydoc DoewgpuCommandBufferRelease
 */
typedef void (*DoeWGPUProcCommandBufferRelease)(DoeWGPUCommandBuffer commandBuffer) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of CommandEncoder
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderBeginComputePass:
 * > @copydoc DoewgpuCommandEncoderBeginComputePass
 */
typedef DoeWGPUComputePassEncoder (*DoeWGPUProcCommandEncoderBeginComputePass)(DoeWGPUCommandEncoder commandEncoder, DoeWGPU_NULLABLE DoeWGPUComputePassDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderBeginRenderPass:
 * > @copydoc DoewgpuCommandEncoderBeginRenderPass
 */
typedef DoeWGPURenderPassEncoder (*DoeWGPUProcCommandEncoderBeginRenderPass)(DoeWGPUCommandEncoder commandEncoder, DoeWGPURenderPassDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderClearBuffer:
 * > @copydoc DoewgpuCommandEncoderClearBuffer
 */
typedef void (*DoeWGPUProcCommandEncoderClearBuffer)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderCopyBufferToBuffer:
 * > @copydoc DoewgpuCommandEncoderCopyBufferToBuffer
 */
typedef void (*DoeWGPUProcCommandEncoderCopyBufferToBuffer)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUBuffer source, uint64_t sourceOffset, DoeWGPUBuffer destination, uint64_t destinationOffset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderCopyBufferToTexture:
 * > @copydoc DoewgpuCommandEncoderCopyBufferToTexture
 */
typedef void (*DoeWGPUProcCommandEncoderCopyBufferToTexture)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyBufferInfo const * source, DoeWGPUTexelCopyTextureInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderCopyTextureToBuffer:
 * > @copydoc DoewgpuCommandEncoderCopyTextureToBuffer
 */
typedef void (*DoeWGPUProcCommandEncoderCopyTextureToBuffer)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyTextureInfo const * source, DoeWGPUTexelCopyBufferInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderCopyTextureToTexture:
 * > @copydoc DoewgpuCommandEncoderCopyTextureToTexture
 */
typedef void (*DoeWGPUProcCommandEncoderCopyTextureToTexture)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyTextureInfo const * source, DoeWGPUTexelCopyTextureInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderFinish:
 * > @copydoc DoewgpuCommandEncoderFinish
 */
typedef DoeWGPUCommandBuffer (*DoeWGPUProcCommandEncoderFinish)(DoeWGPUCommandEncoder commandEncoder, DoeWGPU_NULLABLE DoeWGPUCommandBufferDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderInsertDebugMarker:
 * > @copydoc DoewgpuCommandEncoderInsertDebugMarker
 */
typedef void (*DoeWGPUProcCommandEncoderInsertDebugMarker)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderPopDebugGroup:
 * > @copydoc DoewgpuCommandEncoderPopDebugGroup
 */
typedef void (*DoeWGPUProcCommandEncoderPopDebugGroup)(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderPushDebugGroup:
 * > @copydoc DoewgpuCommandEncoderPushDebugGroup
 */
typedef void (*DoeWGPUProcCommandEncoderPushDebugGroup)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderResolveQuerySet:
 * > @copydoc DoewgpuCommandEncoderResolveQuerySet
 */
typedef void (*DoeWGPUProcCommandEncoderResolveQuerySet)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUQuerySet querySet, uint32_t firstQuery, uint32_t queryCount, DoeWGPUBuffer destination, uint64_t destinationOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderSetLabel:
 * > @copydoc DoewgpuCommandEncoderSetLabel
 */
typedef void (*DoeWGPUProcCommandEncoderSetLabel)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderWriteTimestamp:
 * > @copydoc DoewgpuCommandEncoderWriteTimestamp
 */
typedef void (*DoeWGPUProcCommandEncoderWriteTimestamp)(DoeWGPUCommandEncoder commandEncoder, DoeWGPUQuerySet querySet, uint32_t queryIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderAddRef:
 * > @copydoc DoewgpuCommandEncoderAddRef
 */
typedef void (*DoeWGPUProcCommandEncoderAddRef)(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuCommandEncoderRelease:
 * > @copydoc DoewgpuCommandEncoderRelease
 */
typedef void (*DoeWGPUProcCommandEncoderRelease)(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of ComputePassEncoder
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderDispatchWorkgroups:
 * > @copydoc DoewgpuComputePassEncoderDispatchWorkgroups
 */
typedef void (*DoeWGPUProcComputePassEncoderDispatchWorkgroups)(DoeWGPUComputePassEncoder computePassEncoder, uint32_t workgroupCountX, uint32_t workgroupCountY, uint32_t workgroupCountZ) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderDispatchWorkgroupsIndirect:
 * > @copydoc DoewgpuComputePassEncoderDispatchWorkgroupsIndirect
 */
typedef void (*DoeWGPUProcComputePassEncoderDispatchWorkgroupsIndirect)(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderEnd:
 * > @copydoc DoewgpuComputePassEncoderEnd
 */
typedef void (*DoeWGPUProcComputePassEncoderEnd)(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderInsertDebugMarker:
 * > @copydoc DoewgpuComputePassEncoderInsertDebugMarker
 */
typedef void (*DoeWGPUProcComputePassEncoderInsertDebugMarker)(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderPopDebugGroup:
 * > @copydoc DoewgpuComputePassEncoderPopDebugGroup
 */
typedef void (*DoeWGPUProcComputePassEncoderPopDebugGroup)(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderPushDebugGroup:
 * > @copydoc DoewgpuComputePassEncoderPushDebugGroup
 */
typedef void (*DoeWGPUProcComputePassEncoderPushDebugGroup)(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderSetBindGroup:
 * > @copydoc DoewgpuComputePassEncoderSetBindGroup
 */
typedef void (*DoeWGPUProcComputePassEncoderSetBindGroup)(DoeWGPUComputePassEncoder computePassEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderSetImmediates:
 * > @copydoc DoewgpuComputePassEncoderSetImmediates
 */
typedef void (*DoeWGPUProcComputePassEncoderSetImmediates)(DoeWGPUComputePassEncoder computePassEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderSetLabel:
 * > @copydoc DoewgpuComputePassEncoderSetLabel
 */
typedef void (*DoeWGPUProcComputePassEncoderSetLabel)(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderSetPipeline:
 * > @copydoc DoewgpuComputePassEncoderSetPipeline
 */
typedef void (*DoeWGPUProcComputePassEncoderSetPipeline)(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUComputePipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderAddRef:
 * > @copydoc DoewgpuComputePassEncoderAddRef
 */
typedef void (*DoeWGPUProcComputePassEncoderAddRef)(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePassEncoderRelease:
 * > @copydoc DoewgpuComputePassEncoderRelease
 */
typedef void (*DoeWGPUProcComputePassEncoderRelease)(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of ComputePipeline
/**
 * Proc pointer type for @ref DoewgpuComputePipelineGetBindGroupLayout:
 * > @copydoc DoewgpuComputePipelineGetBindGroupLayout
 */
typedef DoeWGPUBindGroupLayout (*DoeWGPUProcComputePipelineGetBindGroupLayout)(DoeWGPUComputePipeline computePipeline, uint32_t groupIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePipelineSetLabel:
 * > @copydoc DoewgpuComputePipelineSetLabel
 */
typedef void (*DoeWGPUProcComputePipelineSetLabel)(DoeWGPUComputePipeline computePipeline, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePipelineAddRef:
 * > @copydoc DoewgpuComputePipelineAddRef
 */
typedef void (*DoeWGPUProcComputePipelineAddRef)(DoeWGPUComputePipeline computePipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuComputePipelineRelease:
 * > @copydoc DoewgpuComputePipelineRelease
 */
typedef void (*DoeWGPUProcComputePipelineRelease)(DoeWGPUComputePipeline computePipeline) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Device
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateBindGroup:
 * > @copydoc DoewgpuDeviceCreateBindGroup
 */
typedef DoeWGPUBindGroup (*DoeWGPUProcDeviceCreateBindGroup)(DoeWGPUDevice device, DoeWGPUBindGroupDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateBindGroupLayout:
 * > @copydoc DoewgpuDeviceCreateBindGroupLayout
 */
typedef DoeWGPUBindGroupLayout (*DoeWGPUProcDeviceCreateBindGroupLayout)(DoeWGPUDevice device, DoeWGPUBindGroupLayoutDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateBuffer:
 * > @copydoc DoewgpuDeviceCreateBuffer
 */
typedef DoeWGPU_NULLABLE DoeWGPUBuffer (*DoeWGPUProcDeviceCreateBuffer)(DoeWGPUDevice device, DoeWGPUBufferDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateCommandEncoder:
 * > @copydoc DoewgpuDeviceCreateCommandEncoder
 */
typedef DoeWGPUCommandEncoder (*DoeWGPUProcDeviceCreateCommandEncoder)(DoeWGPUDevice device, DoeWGPU_NULLABLE DoeWGPUCommandEncoderDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateComputePipeline:
 * > @copydoc DoewgpuDeviceCreateComputePipeline
 */
typedef DoeWGPUComputePipeline (*DoeWGPUProcDeviceCreateComputePipeline)(DoeWGPUDevice device, DoeWGPUComputePipelineDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateComputePipelineAsync:
 * > @copydoc DoewgpuDeviceCreateComputePipelineAsync
 */
typedef DoeWGPUFuture (*DoeWGPUProcDeviceCreateComputePipelineAsync)(DoeWGPUDevice device, DoeWGPUComputePipelineDescriptor const * descriptor, DoeWGPUCreateComputePipelineAsyncCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreatePipelineLayout:
 * > @copydoc DoewgpuDeviceCreatePipelineLayout
 */
typedef DoeWGPUPipelineLayout (*DoeWGPUProcDeviceCreatePipelineLayout)(DoeWGPUDevice device, DoeWGPUPipelineLayoutDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateQuerySet:
 * > @copydoc DoewgpuDeviceCreateQuerySet
 */
typedef DoeWGPUQuerySet (*DoeWGPUProcDeviceCreateQuerySet)(DoeWGPUDevice device, DoeWGPUQuerySetDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateRenderBundleEncoder:
 * > @copydoc DoewgpuDeviceCreateRenderBundleEncoder
 */
typedef DoeWGPURenderBundleEncoder (*DoeWGPUProcDeviceCreateRenderBundleEncoder)(DoeWGPUDevice device, DoeWGPURenderBundleEncoderDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateRenderPipeline:
 * > @copydoc DoewgpuDeviceCreateRenderPipeline
 */
typedef DoeWGPURenderPipeline (*DoeWGPUProcDeviceCreateRenderPipeline)(DoeWGPUDevice device, DoeWGPURenderPipelineDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateRenderPipelineAsync:
 * > @copydoc DoewgpuDeviceCreateRenderPipelineAsync
 */
typedef DoeWGPUFuture (*DoeWGPUProcDeviceCreateRenderPipelineAsync)(DoeWGPUDevice device, DoeWGPURenderPipelineDescriptor const * descriptor, DoeWGPUCreateRenderPipelineAsyncCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateSampler:
 * > @copydoc DoewgpuDeviceCreateSampler
 */
typedef DoeWGPUSampler (*DoeWGPUProcDeviceCreateSampler)(DoeWGPUDevice device, DoeWGPU_NULLABLE DoeWGPUSamplerDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateShaderModule:
 * > @copydoc DoewgpuDeviceCreateShaderModule
 */
typedef DoeWGPUShaderModule (*DoeWGPUProcDeviceCreateShaderModule)(DoeWGPUDevice device, DoeWGPUShaderModuleDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceCreateTexture:
 * > @copydoc DoewgpuDeviceCreateTexture
 */
typedef DoeWGPUTexture (*DoeWGPUProcDeviceCreateTexture)(DoeWGPUDevice device, DoeWGPUTextureDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceDestroy:
 * > @copydoc DoewgpuDeviceDestroy
 */
typedef void (*DoeWGPUProcDeviceDestroy)(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceGetAdapterInfo:
 * > @copydoc DoewgpuDeviceGetAdapterInfo
 */
typedef DoeWGPUStatus (*DoeWGPUProcDeviceGetAdapterInfo)(DoeWGPUDevice device, DoeWGPUAdapterInfo * adapterInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceGetFeatures:
 * > @copydoc DoewgpuDeviceGetFeatures
 */
typedef void (*DoeWGPUProcDeviceGetFeatures)(DoeWGPUDevice device, DoeWGPUSupportedFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceGetLimits:
 * > @copydoc DoewgpuDeviceGetLimits
 */
typedef DoeWGPUStatus (*DoeWGPUProcDeviceGetLimits)(DoeWGPUDevice device, DoeWGPULimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceGetLostFuture:
 * > @copydoc DoewgpuDeviceGetLostFuture
 */
typedef DoeWGPUFuture (*DoeWGPUProcDeviceGetLostFuture)(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceGetQueue:
 * > @copydoc DoewgpuDeviceGetQueue
 */
typedef DoeWGPUQueue (*DoeWGPUProcDeviceGetQueue)(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceHasFeature:
 * > @copydoc DoewgpuDeviceHasFeature
 */
typedef DoeWGPUBool (*DoeWGPUProcDeviceHasFeature)(DoeWGPUDevice device, DoeWGPUFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDevicePopErrorScope:
 * > @copydoc DoewgpuDevicePopErrorScope
 */
typedef DoeWGPUFuture (*DoeWGPUProcDevicePopErrorScope)(DoeWGPUDevice device, DoeWGPUPopErrorScopeCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDevicePushErrorScope:
 * > @copydoc DoewgpuDevicePushErrorScope
 */
typedef void (*DoeWGPUProcDevicePushErrorScope)(DoeWGPUDevice device, DoeWGPUErrorFilter filter) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceSetLabel:
 * > @copydoc DoewgpuDeviceSetLabel
 */
typedef void (*DoeWGPUProcDeviceSetLabel)(DoeWGPUDevice device, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceAddRef:
 * > @copydoc DoewgpuDeviceAddRef
 */
typedef void (*DoeWGPUProcDeviceAddRef)(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuDeviceRelease:
 * > @copydoc DoewgpuDeviceRelease
 */
typedef void (*DoeWGPUProcDeviceRelease)(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of ExternalTexture
/**
 * Proc pointer type for @ref DoewgpuExternalTextureSetLabel:
 * > @copydoc DoewgpuExternalTextureSetLabel
 */
typedef void (*DoeWGPUProcExternalTextureSetLabel)(DoeWGPUExternalTexture externalTexture, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuExternalTextureAddRef:
 * > @copydoc DoewgpuExternalTextureAddRef
 */
typedef void (*DoeWGPUProcExternalTextureAddRef)(DoeWGPUExternalTexture externalTexture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuExternalTextureRelease:
 * > @copydoc DoewgpuExternalTextureRelease
 */
typedef void (*DoeWGPUProcExternalTextureRelease)(DoeWGPUExternalTexture externalTexture) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Instance
/**
 * Proc pointer type for @ref DoewgpuInstanceCreateSurface:
 * > @copydoc DoewgpuInstanceCreateSurface
 */
typedef DoeWGPUSurface (*DoeWGPUProcInstanceCreateSurface)(DoeWGPUInstance instance, DoeWGPUSurfaceDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceGetWGSLLanguageFeatures:
 * > @copydoc DoewgpuInstanceGetWGSLLanguageFeatures
 */
typedef void (*DoeWGPUProcInstanceGetWGSLLanguageFeatures)(DoeWGPUInstance instance, DoeWGPUSupportedWGSLLanguageFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceHasWGSLLanguageFeature:
 * > @copydoc DoewgpuInstanceHasWGSLLanguageFeature
 */
typedef DoeWGPUBool (*DoeWGPUProcInstanceHasWGSLLanguageFeature)(DoeWGPUInstance instance, DoeWGPUWGSLLanguageFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceProcessEvents:
 * > @copydoc DoewgpuInstanceProcessEvents
 */
typedef void (*DoeWGPUProcInstanceProcessEvents)(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceRequestAdapter:
 * > @copydoc DoewgpuInstanceRequestAdapter
 */
typedef DoeWGPUFuture (*DoeWGPUProcInstanceRequestAdapter)(DoeWGPUInstance instance, DoeWGPU_NULLABLE DoeWGPURequestAdapterOptions const * options, DoeWGPURequestAdapterCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceWaitAny:
 * > @copydoc DoewgpuInstanceWaitAny
 */
typedef DoeWGPUWaitStatus (*DoeWGPUProcInstanceWaitAny)(DoeWGPUInstance instance, size_t futureCount, DoeWGPU_NULLABLE DoeWGPUFutureWaitInfo * futures, uint64_t timeoutNS) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceAddRef:
 * > @copydoc DoewgpuInstanceAddRef
 */
typedef void (*DoeWGPUProcInstanceAddRef)(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuInstanceRelease:
 * > @copydoc DoewgpuInstanceRelease
 */
typedef void (*DoeWGPUProcInstanceRelease)(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of PipelineLayout
/**
 * Proc pointer type for @ref DoewgpuPipelineLayoutSetLabel:
 * > @copydoc DoewgpuPipelineLayoutSetLabel
 */
typedef void (*DoeWGPUProcPipelineLayoutSetLabel)(DoeWGPUPipelineLayout pipelineLayout, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuPipelineLayoutAddRef:
 * > @copydoc DoewgpuPipelineLayoutAddRef
 */
typedef void (*DoeWGPUProcPipelineLayoutAddRef)(DoeWGPUPipelineLayout pipelineLayout) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuPipelineLayoutRelease:
 * > @copydoc DoewgpuPipelineLayoutRelease
 */
typedef void (*DoeWGPUProcPipelineLayoutRelease)(DoeWGPUPipelineLayout pipelineLayout) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of QuerySet
/**
 * Proc pointer type for @ref DoewgpuQuerySetDestroy:
 * > @copydoc DoewgpuQuerySetDestroy
 */
typedef void (*DoeWGPUProcQuerySetDestroy)(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQuerySetGetCount:
 * > @copydoc DoewgpuQuerySetGetCount
 */
typedef uint32_t (*DoeWGPUProcQuerySetGetCount)(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQuerySetGetType:
 * > @copydoc DoewgpuQuerySetGetType
 */
typedef DoeWGPUQueryType (*DoeWGPUProcQuerySetGetType)(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQuerySetSetLabel:
 * > @copydoc DoewgpuQuerySetSetLabel
 */
typedef void (*DoeWGPUProcQuerySetSetLabel)(DoeWGPUQuerySet querySet, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQuerySetAddRef:
 * > @copydoc DoewgpuQuerySetAddRef
 */
typedef void (*DoeWGPUProcQuerySetAddRef)(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQuerySetRelease:
 * > @copydoc DoewgpuQuerySetRelease
 */
typedef void (*DoeWGPUProcQuerySetRelease)(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Queue
/**
 * Proc pointer type for @ref DoewgpuQueueOnSubmittedWorkDone:
 * > @copydoc DoewgpuQueueOnSubmittedWorkDone
 */
typedef DoeWGPUFuture (*DoeWGPUProcQueueOnSubmittedWorkDone)(DoeWGPUQueue queue, DoeWGPUQueueWorkDoneCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueSetLabel:
 * > @copydoc DoewgpuQueueSetLabel
 */
typedef void (*DoeWGPUProcQueueSetLabel)(DoeWGPUQueue queue, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueSubmit:
 * > @copydoc DoewgpuQueueSubmit
 */
typedef void (*DoeWGPUProcQueueSubmit)(DoeWGPUQueue queue, size_t commandCount, DoeWGPUCommandBuffer const * commands) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueWriteBuffer:
 * > @copydoc DoewgpuQueueWriteBuffer
 */
typedef void (*DoeWGPUProcQueueWriteBuffer)(DoeWGPUQueue queue, DoeWGPUBuffer buffer, uint64_t bufferOffset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueWriteTexture:
 * > @copydoc DoewgpuQueueWriteTexture
 */
typedef void (*DoeWGPUProcQueueWriteTexture)(DoeWGPUQueue queue, DoeWGPUTexelCopyTextureInfo const * destination, void const * data, size_t dataSize, DoeWGPUTexelCopyBufferLayout const * dataLayout, DoeWGPUExtent3D const * writeSize) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueAddRef:
 * > @copydoc DoewgpuQueueAddRef
 */
typedef void (*DoeWGPUProcQueueAddRef)(DoeWGPUQueue queue) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuQueueRelease:
 * > @copydoc DoewgpuQueueRelease
 */
typedef void (*DoeWGPUProcQueueRelease)(DoeWGPUQueue queue) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of RenderBundle
/**
 * Proc pointer type for @ref DoewgpuRenderBundleSetLabel:
 * > @copydoc DoewgpuRenderBundleSetLabel
 */
typedef void (*DoeWGPUProcRenderBundleSetLabel)(DoeWGPURenderBundle renderBundle, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleAddRef:
 * > @copydoc DoewgpuRenderBundleAddRef
 */
typedef void (*DoeWGPUProcRenderBundleAddRef)(DoeWGPURenderBundle renderBundle) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleRelease:
 * > @copydoc DoewgpuRenderBundleRelease
 */
typedef void (*DoeWGPUProcRenderBundleRelease)(DoeWGPURenderBundle renderBundle) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of RenderBundleEncoder
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderDraw:
 * > @copydoc DoewgpuRenderBundleEncoderDraw
 */
typedef void (*DoeWGPUProcRenderBundleEncoderDraw)(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t vertexCount, uint32_t instanceCount, uint32_t firstVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderDrawIndexed:
 * > @copydoc DoewgpuRenderBundleEncoderDrawIndexed
 */
typedef void (*DoeWGPUProcRenderBundleEncoderDrawIndexed)(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t indexCount, uint32_t instanceCount, uint32_t firstIndex, int32_t baseVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderDrawIndexedIndirect:
 * > @copydoc DoewgpuRenderBundleEncoderDrawIndexedIndirect
 */
typedef void (*DoeWGPUProcRenderBundleEncoderDrawIndexedIndirect)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderDrawIndirect:
 * > @copydoc DoewgpuRenderBundleEncoderDrawIndirect
 */
typedef void (*DoeWGPUProcRenderBundleEncoderDrawIndirect)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderFinish:
 * > @copydoc DoewgpuRenderBundleEncoderFinish
 */
typedef DoeWGPURenderBundle (*DoeWGPUProcRenderBundleEncoderFinish)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPU_NULLABLE DoeWGPURenderBundleDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderInsertDebugMarker:
 * > @copydoc DoewgpuRenderBundleEncoderInsertDebugMarker
 */
typedef void (*DoeWGPUProcRenderBundleEncoderInsertDebugMarker)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderPopDebugGroup:
 * > @copydoc DoewgpuRenderBundleEncoderPopDebugGroup
 */
typedef void (*DoeWGPUProcRenderBundleEncoderPopDebugGroup)(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderPushDebugGroup:
 * > @copydoc DoewgpuRenderBundleEncoderPushDebugGroup
 */
typedef void (*DoeWGPUProcRenderBundleEncoderPushDebugGroup)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetBindGroup:
 * > @copydoc DoewgpuRenderBundleEncoderSetBindGroup
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetBindGroup)(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetImmediates:
 * > @copydoc DoewgpuRenderBundleEncoderSetImmediates
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetImmediates)(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetIndexBuffer:
 * > @copydoc DoewgpuRenderBundleEncoderSetIndexBuffer
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetIndexBuffer)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer buffer, DoeWGPUIndexFormat format, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetLabel:
 * > @copydoc DoewgpuRenderBundleEncoderSetLabel
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetLabel)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetPipeline:
 * > @copydoc DoewgpuRenderBundleEncoderSetPipeline
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetPipeline)(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPURenderPipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderSetVertexBuffer:
 * > @copydoc DoewgpuRenderBundleEncoderSetVertexBuffer
 */
typedef void (*DoeWGPUProcRenderBundleEncoderSetVertexBuffer)(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t slot, DoeWGPU_NULLABLE DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderAddRef:
 * > @copydoc DoewgpuRenderBundleEncoderAddRef
 */
typedef void (*DoeWGPUProcRenderBundleEncoderAddRef)(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderBundleEncoderRelease:
 * > @copydoc DoewgpuRenderBundleEncoderRelease
 */
typedef void (*DoeWGPUProcRenderBundleEncoderRelease)(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of RenderPassEncoder
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderBeginOcclusionQuery:
 * > @copydoc DoewgpuRenderPassEncoderBeginOcclusionQuery
 */
typedef void (*DoeWGPUProcRenderPassEncoderBeginOcclusionQuery)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t queryIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderDraw:
 * > @copydoc DoewgpuRenderPassEncoderDraw
 */
typedef void (*DoeWGPUProcRenderPassEncoderDraw)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t vertexCount, uint32_t instanceCount, uint32_t firstVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderDrawIndexed:
 * > @copydoc DoewgpuRenderPassEncoderDrawIndexed
 */
typedef void (*DoeWGPUProcRenderPassEncoderDrawIndexed)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t indexCount, uint32_t instanceCount, uint32_t firstIndex, int32_t baseVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderDrawIndexedIndirect:
 * > @copydoc DoewgpuRenderPassEncoderDrawIndexedIndirect
 */
typedef void (*DoeWGPUProcRenderPassEncoderDrawIndexedIndirect)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderDrawIndirect:
 * > @copydoc DoewgpuRenderPassEncoderDrawIndirect
 */
typedef void (*DoeWGPUProcRenderPassEncoderDrawIndirect)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderEnd:
 * > @copydoc DoewgpuRenderPassEncoderEnd
 */
typedef void (*DoeWGPUProcRenderPassEncoderEnd)(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderEndOcclusionQuery:
 * > @copydoc DoewgpuRenderPassEncoderEndOcclusionQuery
 */
typedef void (*DoeWGPUProcRenderPassEncoderEndOcclusionQuery)(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderExecuteBundles:
 * > @copydoc DoewgpuRenderPassEncoderExecuteBundles
 */
typedef void (*DoeWGPUProcRenderPassEncoderExecuteBundles)(DoeWGPURenderPassEncoder renderPassEncoder, size_t bundleCount, DoeWGPURenderBundle const * bundles) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderInsertDebugMarker:
 * > @copydoc DoewgpuRenderPassEncoderInsertDebugMarker
 */
typedef void (*DoeWGPUProcRenderPassEncoderInsertDebugMarker)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderPopDebugGroup:
 * > @copydoc DoewgpuRenderPassEncoderPopDebugGroup
 */
typedef void (*DoeWGPUProcRenderPassEncoderPopDebugGroup)(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderPushDebugGroup:
 * > @copydoc DoewgpuRenderPassEncoderPushDebugGroup
 */
typedef void (*DoeWGPUProcRenderPassEncoderPushDebugGroup)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetBindGroup:
 * > @copydoc DoewgpuRenderPassEncoderSetBindGroup
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetBindGroup)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetBlendConstant:
 * > @copydoc DoewgpuRenderPassEncoderSetBlendConstant
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetBlendConstant)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUColor const * color) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetImmediates:
 * > @copydoc DoewgpuRenderPassEncoderSetImmediates
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetImmediates)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetIndexBuffer:
 * > @copydoc DoewgpuRenderPassEncoderSetIndexBuffer
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetIndexBuffer)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer buffer, DoeWGPUIndexFormat format, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetLabel:
 * > @copydoc DoewgpuRenderPassEncoderSetLabel
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetLabel)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetPipeline:
 * > @copydoc DoewgpuRenderPassEncoderSetPipeline
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetPipeline)(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPURenderPipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetScissorRect:
 * > @copydoc DoewgpuRenderPassEncoderSetScissorRect
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetScissorRect)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t x, uint32_t y, uint32_t width, uint32_t height) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetStencilReference:
 * > @copydoc DoewgpuRenderPassEncoderSetStencilReference
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetStencilReference)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t reference) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetVertexBuffer:
 * > @copydoc DoewgpuRenderPassEncoderSetVertexBuffer
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetVertexBuffer)(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t slot, DoeWGPU_NULLABLE DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderSetViewport:
 * > @copydoc DoewgpuRenderPassEncoderSetViewport
 */
typedef void (*DoeWGPUProcRenderPassEncoderSetViewport)(DoeWGPURenderPassEncoder renderPassEncoder, float x, float y, float width, float height, float minDepth, float maxDepth) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderAddRef:
 * > @copydoc DoewgpuRenderPassEncoderAddRef
 */
typedef void (*DoeWGPUProcRenderPassEncoderAddRef)(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPassEncoderRelease:
 * > @copydoc DoewgpuRenderPassEncoderRelease
 */
typedef void (*DoeWGPUProcRenderPassEncoderRelease)(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of RenderPipeline
/**
 * Proc pointer type for @ref DoewgpuRenderPipelineGetBindGroupLayout:
 * > @copydoc DoewgpuRenderPipelineGetBindGroupLayout
 */
typedef DoeWGPUBindGroupLayout (*DoeWGPUProcRenderPipelineGetBindGroupLayout)(DoeWGPURenderPipeline renderPipeline, uint32_t groupIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPipelineSetLabel:
 * > @copydoc DoewgpuRenderPipelineSetLabel
 */
typedef void (*DoeWGPUProcRenderPipelineSetLabel)(DoeWGPURenderPipeline renderPipeline, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPipelineAddRef:
 * > @copydoc DoewgpuRenderPipelineAddRef
 */
typedef void (*DoeWGPUProcRenderPipelineAddRef)(DoeWGPURenderPipeline renderPipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuRenderPipelineRelease:
 * > @copydoc DoewgpuRenderPipelineRelease
 */
typedef void (*DoeWGPUProcRenderPipelineRelease)(DoeWGPURenderPipeline renderPipeline) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Sampler
/**
 * Proc pointer type for @ref DoewgpuSamplerSetLabel:
 * > @copydoc DoewgpuSamplerSetLabel
 */
typedef void (*DoeWGPUProcSamplerSetLabel)(DoeWGPUSampler sampler, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSamplerAddRef:
 * > @copydoc DoewgpuSamplerAddRef
 */
typedef void (*DoeWGPUProcSamplerAddRef)(DoeWGPUSampler sampler) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSamplerRelease:
 * > @copydoc DoewgpuSamplerRelease
 */
typedef void (*DoeWGPUProcSamplerRelease)(DoeWGPUSampler sampler) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of ShaderModule
/**
 * Proc pointer type for @ref DoewgpuShaderModuleGetCompilationInfo:
 * > @copydoc DoewgpuShaderModuleGetCompilationInfo
 */
typedef DoeWGPUFuture (*DoeWGPUProcShaderModuleGetCompilationInfo)(DoeWGPUShaderModule shaderModule, DoeWGPUCompilationInfoCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuShaderModuleSetLabel:
 * > @copydoc DoewgpuShaderModuleSetLabel
 */
typedef void (*DoeWGPUProcShaderModuleSetLabel)(DoeWGPUShaderModule shaderModule, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuShaderModuleAddRef:
 * > @copydoc DoewgpuShaderModuleAddRef
 */
typedef void (*DoeWGPUProcShaderModuleAddRef)(DoeWGPUShaderModule shaderModule) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuShaderModuleRelease:
 * > @copydoc DoewgpuShaderModuleRelease
 */
typedef void (*DoeWGPUProcShaderModuleRelease)(DoeWGPUShaderModule shaderModule) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of SupportedFeatures
/**
 * Proc pointer type for @ref DoewgpuSupportedFeaturesFreeMembers:
 * > @copydoc DoewgpuSupportedFeaturesFreeMembers
 */
typedef void (*DoeWGPUProcSupportedFeaturesFreeMembers)(DoeWGPUSupportedFeatures supportedFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of SupportedInstanceFeatures
/**
 * Proc pointer type for @ref DoewgpuSupportedInstanceFeaturesFreeMembers:
 * > @copydoc DoewgpuSupportedInstanceFeaturesFreeMembers
 */
typedef void (*DoeWGPUProcSupportedInstanceFeaturesFreeMembers)(DoeWGPUSupportedInstanceFeatures supportedInstanceFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of SupportedWGSLLanguageFeatures
/**
 * Proc pointer type for @ref DoewgpuSupportedWGSLLanguageFeaturesFreeMembers:
 * > @copydoc DoewgpuSupportedWGSLLanguageFeaturesFreeMembers
 */
typedef void (*DoeWGPUProcSupportedWGSLLanguageFeaturesFreeMembers)(DoeWGPUSupportedWGSLLanguageFeatures supportedWGSLLanguageFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Surface
/**
 * Proc pointer type for @ref DoewgpuSurfaceConfigure:
 * > @copydoc DoewgpuSurfaceConfigure
 */
typedef void (*DoeWGPUProcSurfaceConfigure)(DoeWGPUSurface surface, DoeWGPUSurfaceConfiguration const * config) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceGetCapabilities:
 * > @copydoc DoewgpuSurfaceGetCapabilities
 */
typedef DoeWGPUStatus (*DoeWGPUProcSurfaceGetCapabilities)(DoeWGPUSurface surface, DoeWGPUAdapter adapter, DoeWGPUSurfaceCapabilities * capabilities) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceGetCurrentTexture:
 * > @copydoc DoewgpuSurfaceGetCurrentTexture
 */
typedef void (*DoeWGPUProcSurfaceGetCurrentTexture)(DoeWGPUSurface surface, DoeWGPUSurfaceTexture * surfaceTexture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfacePresent:
 * > @copydoc DoewgpuSurfacePresent
 */
typedef DoeWGPUStatus (*DoeWGPUProcSurfacePresent)(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceSetLabel:
 * > @copydoc DoewgpuSurfaceSetLabel
 */
typedef void (*DoeWGPUProcSurfaceSetLabel)(DoeWGPUSurface surface, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceUnconfigure:
 * > @copydoc DoewgpuSurfaceUnconfigure
 */
typedef void (*DoeWGPUProcSurfaceUnconfigure)(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceAddRef:
 * > @copydoc DoewgpuSurfaceAddRef
 */
typedef void (*DoeWGPUProcSurfaceAddRef)(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuSurfaceRelease:
 * > @copydoc DoewgpuSurfaceRelease
 */
typedef void (*DoeWGPUProcSurfaceRelease)(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of SurfaceCapabilities
/**
 * Proc pointer type for @ref DoewgpuSurfaceCapabilitiesFreeMembers:
 * > @copydoc DoewgpuSurfaceCapabilitiesFreeMembers
 */
typedef void (*DoeWGPUProcSurfaceCapabilitiesFreeMembers)(DoeWGPUSurfaceCapabilities surfaceCapabilities) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of Texture
/**
 * Proc pointer type for @ref DoewgpuTextureCreateView:
 * > @copydoc DoewgpuTextureCreateView
 */
typedef DoeWGPUTextureView (*DoeWGPUProcTextureCreateView)(DoeWGPUTexture texture, DoeWGPU_NULLABLE DoeWGPUTextureViewDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureDestroy:
 * > @copydoc DoewgpuTextureDestroy
 */
typedef void (*DoeWGPUProcTextureDestroy)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetDepthOrArrayLayers:
 * > @copydoc DoewgpuTextureGetDepthOrArrayLayers
 */
typedef uint32_t (*DoeWGPUProcTextureGetDepthOrArrayLayers)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetDimension:
 * > @copydoc DoewgpuTextureGetDimension
 */
typedef DoeWGPUTextureDimension (*DoeWGPUProcTextureGetDimension)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetFormat:
 * > @copydoc DoewgpuTextureGetFormat
 */
typedef DoeWGPUTextureFormat (*DoeWGPUProcTextureGetFormat)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetHeight:
 * > @copydoc DoewgpuTextureGetHeight
 */
typedef uint32_t (*DoeWGPUProcTextureGetHeight)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetMipLevelCount:
 * > @copydoc DoewgpuTextureGetMipLevelCount
 */
typedef uint32_t (*DoeWGPUProcTextureGetMipLevelCount)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetSampleCount:
 * > @copydoc DoewgpuTextureGetSampleCount
 */
typedef uint32_t (*DoeWGPUProcTextureGetSampleCount)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetTextureBindingViewDimension:
 * > @copydoc DoewgpuTextureGetTextureBindingViewDimension
 */
typedef DoeWGPUTextureViewDimension (*DoeWGPUProcTextureGetTextureBindingViewDimension)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetUsage:
 * > @copydoc DoewgpuTextureGetUsage
 */
typedef DoeWGPUTextureUsage (*DoeWGPUProcTextureGetUsage)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureGetWidth:
 * > @copydoc DoewgpuTextureGetWidth
 */
typedef uint32_t (*DoeWGPUProcTextureGetWidth)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureSetLabel:
 * > @copydoc DoewgpuTextureSetLabel
 */
typedef void (*DoeWGPUProcTextureSetLabel)(DoeWGPUTexture texture, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureAddRef:
 * > @copydoc DoewgpuTextureAddRef
 */
typedef void (*DoeWGPUProcTextureAddRef)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureRelease:
 * > @copydoc DoewgpuTextureRelease
 */
typedef void (*DoeWGPUProcTextureRelease)(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;

// Procs of TextureView
/**
 * Proc pointer type for @ref DoewgpuTextureViewSetLabel:
 * > @copydoc DoewgpuTextureViewSetLabel
 */
typedef void (*DoeWGPUProcTextureViewSetLabel)(DoeWGPUTextureView textureView, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureViewAddRef:
 * > @copydoc DoewgpuTextureViewAddRef
 */
typedef void (*DoeWGPUProcTextureViewAddRef)(DoeWGPUTextureView textureView) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Proc pointer type for @ref DoewgpuTextureViewRelease:
 * > @copydoc DoewgpuTextureViewRelease
 */
typedef void (*DoeWGPUProcTextureViewRelease)(DoeWGPUTextureView textureView) DoeWGPU_FUNCTION_ATTRIBUTE;

#endif  // !defined(DoeWGPU_SKIP_PROCS)

#if !defined(DoeWGPU_SKIP_DECLARATIONS)
/**
 * \defgroup GlobalFunctions Global Functions
 * \brief Functions that are not specific to an object.
 *
 * @{
 */
/**
 * Create a DoeWGPUInstance
 *
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUInstance DoewgpuCreateInstance(DoeWGPU_NULLABLE DoeWGPUInstanceDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Get the list of @ref DoeWGPUInstanceFeatureName values supported by the instance.
 *
 * @param features
 * This parameter is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT void DoewgpuGetInstanceFeatures(DoeWGPUSupportedInstanceFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Get the limits supported by the instance.
 *
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuGetInstanceLimits(DoeWGPUInstanceLimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Check whether a particular @ref DoeWGPUInstanceFeatureName is supported by the instance.
 */
DoeWGPU_EXPORT DoeWGPUBool DoewgpuHasInstanceFeature(DoeWGPUInstanceFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Returns the "procedure address" (function pointer) of the named function.
 * The result must be cast to the appropriate proc pointer type.
 */
DoeWGPU_EXPORT DoeWGPUProc DoewgpuGetProcAddress(DoeWGPUStringView procName) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup Methods Methods
 * \brief Functions that are relative to a specific object.
 *
 * @{
 */

/**
 * \defgroup DoeWGPUAdapterMethods DoeWGPUAdapter methods
 * \brief Functions whose first argument has type DoeWGPUAdapter.
 *
 * @{
 */
/**
 * Get the list of @ref DoeWGPUFeatureName values supported by the adapter.
 *
 * @param features
 * This parameter is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT void DoewgpuAdapterGetFeatures(DoeWGPUAdapter adapter, DoeWGPUSupportedFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @param info
 * This parameter is @ref ReturnedWithOwnership.
 *
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuAdapterGetInfo(DoeWGPUAdapter adapter, DoeWGPUAdapterInfo * info) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuAdapterGetLimits(DoeWGPUAdapter adapter, DoeWGPULimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUBool DoewgpuAdapterHasFeature(DoeWGPUAdapter adapter, DoeWGPUFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuAdapterRequestDevice(DoeWGPUAdapter adapter, DoeWGPU_NULLABLE DoeWGPUDeviceDescriptor const * descriptor, DoeWGPURequestDeviceCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuAdapterAddRef(DoeWGPUAdapter adapter) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuAdapterRelease(DoeWGPUAdapter adapter) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUAdapterInfoMethods DoeWGPUAdapterInfo methods
 * \brief Functions whose first argument has type DoeWGPUAdapterInfo.
 *
 * @{
 */
/**
 * Frees members which were allocated by the API.
 */
DoeWGPU_EXPORT void DoewgpuAdapterInfoFreeMembers(DoeWGPUAdapterInfo adapterInfo) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUBindGroupMethods DoeWGPUBindGroup methods
 * \brief Functions whose first argument has type DoeWGPUBindGroup.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuBindGroupSetLabel(DoeWGPUBindGroup bindGroup, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBindGroupAddRef(DoeWGPUBindGroup bindGroup) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBindGroupRelease(DoeWGPUBindGroup bindGroup) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUBindGroupLayoutMethods DoeWGPUBindGroupLayout methods
 * \brief Functions whose first argument has type DoeWGPUBindGroupLayout.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuBindGroupLayoutSetLabel(DoeWGPUBindGroupLayout bindGroupLayout, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBindGroupLayoutAddRef(DoeWGPUBindGroupLayout bindGroupLayout) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBindGroupLayoutRelease(DoeWGPUBindGroupLayout bindGroupLayout) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUBufferMethods DoeWGPUBuffer methods
 * \brief Functions whose first argument has type DoeWGPUBuffer.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuBufferDestroy(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Returns a const pointer to beginning of the mapped range.
 * It must not be written; writing to this range causes undefined behavior.
 * See @ref MappedRangeBehavior for error conditions and guarantees.
 * This function is safe to call inside spontaneous callbacks (see @ref CallbackReentrancy).
 *
 * In Wasm, if `memcpy`ing from this range, prefer using @ref DoewgpuBufferReadMappedRange
 * instead for better performance.
 *
 * @param offset
 * Byte offset relative to the beginning of the buffer.
 *
 * @param size
 * Byte size of the range to get.
 * If this is @ref DoeWGPU_WHOLE_MAP_SIZE, it defaults to `buffer.size - offset`.
 * The returned pointer is valid for exactly this many bytes.
 */
DoeWGPU_EXPORT void const * DoewgpuBufferGetConstMappedRange(DoeWGPUBuffer buffer, size_t offset, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Returns a mutable pointer to beginning of the mapped range.
 * See @ref MappedRangeBehavior for error conditions and guarantees.
 * This function is safe to call inside spontaneous callbacks (see @ref CallbackReentrancy).
 *
 * In Wasm, if `memcpy`ing into this range, prefer using @ref DoewgpuBufferWriteMappedRange
 * instead for better performance.
 *
 * @param offset
 * Byte offset relative to the beginning of the buffer.
 *
 * @param size
 * Byte size of the range to get.
 * If this is @ref DoeWGPU_WHOLE_MAP_SIZE, it defaults to `buffer.size - offset`.
 * The returned pointer is valid for exactly this many bytes.
 */
DoeWGPU_EXPORT void * DoewgpuBufferGetMappedRange(DoeWGPUBuffer buffer, size_t offset, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUBufferMapState DoewgpuBufferGetMapState(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint64_t DoewgpuBufferGetSize(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUBufferUsage DoewgpuBufferGetUsage(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @param mode
 * The mapping mode (read or write).
 *
 * @param offset
 * Byte offset relative to beginning of the buffer.
 *
 * @param size
 * Byte size of the region to map.
 * If this is @ref DoeWGPU_WHOLE_MAP_SIZE, it defaults to `buffer.size - offset`.
 */
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuBufferMapAsync(DoeWGPUBuffer buffer, DoeWGPUMapMode mode, size_t offset, size_t size, DoeWGPUBufferMapCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Copies a range of data from the buffer mapping into the provided destination pointer.
 * See @ref MappedRangeBehavior for error conditions and guarantees.
 * This function is safe to call inside spontaneous callbacks (see @ref CallbackReentrancy).
 *
 * In Wasm, this is more efficient than copying from a mapped range into a `malloc`'d range.
 *
 * @param offset
 * Byte offset relative to the beginning of the buffer.
 *
 * @param data
 * Destination, to read buffer data into.
 *
 * @param size
 * Number of bytes of data to read from the buffer.
 * (Note @ref DoeWGPU_WHOLE_MAP_SIZE is *not* accepted here.)
 *
 * @returns
 * @ref DoeWGPUStatus_Error if the copy did not occur.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuBufferReadMappedRange(DoeWGPUBuffer buffer, size_t offset, void * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBufferSetLabel(DoeWGPUBuffer buffer, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBufferUnmap(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Copies a range of data from the provided source pointer into the buffer mapping.
 * See @ref MappedRangeBehavior for error conditions and guarantees.
 * This function is safe to call inside spontaneous callbacks (see @ref CallbackReentrancy).
 *
 * In Wasm, this is more efficient than copying from a `malloc`'d range into a mapped range.
 *
 * @param offset
 * Byte offset relative to the beginning of the buffer.
 *
 * @param data
 * Source, to write buffer data from.
 *
 * @param size
 * Number of bytes of data to write to the buffer.
 * (Note @ref DoeWGPU_WHOLE_MAP_SIZE is *not* accepted here.)
 *
 * @returns
 * @ref DoeWGPUStatus_Error if the copy did not occur.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuBufferWriteMappedRange(DoeWGPUBuffer buffer, size_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBufferAddRef(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuBufferRelease(DoeWGPUBuffer buffer) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUCommandBufferMethods DoeWGPUCommandBuffer methods
 * \brief Functions whose first argument has type DoeWGPUCommandBuffer.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuCommandBufferSetLabel(DoeWGPUCommandBuffer commandBuffer, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandBufferAddRef(DoeWGPUCommandBuffer commandBuffer) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandBufferRelease(DoeWGPUCommandBuffer commandBuffer) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUCommandEncoderMethods DoeWGPUCommandEncoder methods
 * \brief Functions whose first argument has type DoeWGPUCommandEncoder.
 *
 * @{
 */
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUComputePassEncoder DoewgpuCommandEncoderBeginComputePass(DoeWGPUCommandEncoder commandEncoder, DoeWGPU_NULLABLE DoeWGPUComputePassDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPURenderPassEncoder DoewgpuCommandEncoderBeginRenderPass(DoeWGPUCommandEncoder commandEncoder, DoeWGPURenderPassDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderClearBuffer(DoeWGPUCommandEncoder commandEncoder, DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderCopyBufferToBuffer(DoeWGPUCommandEncoder commandEncoder, DoeWGPUBuffer source, uint64_t sourceOffset, DoeWGPUBuffer destination, uint64_t destinationOffset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderCopyBufferToTexture(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyBufferInfo const * source, DoeWGPUTexelCopyTextureInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderCopyTextureToBuffer(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyTextureInfo const * source, DoeWGPUTexelCopyBufferInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderCopyTextureToTexture(DoeWGPUCommandEncoder commandEncoder, DoeWGPUTexelCopyTextureInfo const * source, DoeWGPUTexelCopyTextureInfo const * destination, DoeWGPUExtent3D const * copySize) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUCommandBuffer DoewgpuCommandEncoderFinish(DoeWGPUCommandEncoder commandEncoder, DoeWGPU_NULLABLE DoeWGPUCommandBufferDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderInsertDebugMarker(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderPopDebugGroup(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderPushDebugGroup(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderResolveQuerySet(DoeWGPUCommandEncoder commandEncoder, DoeWGPUQuerySet querySet, uint32_t firstQuery, uint32_t queryCount, DoeWGPUBuffer destination, uint64_t destinationOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderSetLabel(DoeWGPUCommandEncoder commandEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderWriteTimestamp(DoeWGPUCommandEncoder commandEncoder, DoeWGPUQuerySet querySet, uint32_t queryIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderAddRef(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuCommandEncoderRelease(DoeWGPUCommandEncoder commandEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUComputePassEncoderMethods DoeWGPUComputePassEncoder methods
 * \brief Functions whose first argument has type DoeWGPUComputePassEncoder.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuComputePassEncoderDispatchWorkgroups(DoeWGPUComputePassEncoder computePassEncoder, uint32_t workgroupCountX, uint32_t workgroupCountY, uint32_t workgroupCountZ) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderDispatchWorkgroupsIndirect(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderEnd(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderInsertDebugMarker(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderPopDebugGroup(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderPushDebugGroup(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderSetBindGroup(DoeWGPUComputePassEncoder computePassEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderSetImmediates(DoeWGPUComputePassEncoder computePassEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderSetLabel(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderSetPipeline(DoeWGPUComputePassEncoder computePassEncoder, DoeWGPUComputePipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderAddRef(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePassEncoderRelease(DoeWGPUComputePassEncoder computePassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUComputePipelineMethods DoeWGPUComputePipeline methods
 * \brief Functions whose first argument has type DoeWGPUComputePipeline.
 *
 * @{
 */
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUBindGroupLayout DoewgpuComputePipelineGetBindGroupLayout(DoeWGPUComputePipeline computePipeline, uint32_t groupIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePipelineSetLabel(DoeWGPUComputePipeline computePipeline, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePipelineAddRef(DoeWGPUComputePipeline computePipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuComputePipelineRelease(DoeWGPUComputePipeline computePipeline) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUDeviceMethods DoeWGPUDevice methods
 * \brief Functions whose first argument has type DoeWGPUDevice.
 *
 * @{
 */
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUBindGroup DoewgpuDeviceCreateBindGroup(DoeWGPUDevice device, DoeWGPUBindGroupDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUBindGroupLayout DoewgpuDeviceCreateBindGroupLayout(DoeWGPUDevice device, DoeWGPUBindGroupLayoutDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * TODO
 *
 * If @ref DoeWGPUBufferDescriptor::mappedAtCreation is `true` and the mapping allocation fails,
 * returns `NULL`.
 *
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPU_NULLABLE DoeWGPUBuffer DoewgpuDeviceCreateBuffer(DoeWGPUDevice device, DoeWGPUBufferDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUCommandEncoder DoewgpuDeviceCreateCommandEncoder(DoeWGPUDevice device, DoeWGPU_NULLABLE DoeWGPUCommandEncoderDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUComputePipeline DoewgpuDeviceCreateComputePipeline(DoeWGPUDevice device, DoeWGPUComputePipelineDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuDeviceCreateComputePipelineAsync(DoeWGPUDevice device, DoeWGPUComputePipelineDescriptor const * descriptor, DoeWGPUCreateComputePipelineAsyncCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUPipelineLayout DoewgpuDeviceCreatePipelineLayout(DoeWGPUDevice device, DoeWGPUPipelineLayoutDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUQuerySet DoewgpuDeviceCreateQuerySet(DoeWGPUDevice device, DoeWGPUQuerySetDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPURenderBundleEncoder DoewgpuDeviceCreateRenderBundleEncoder(DoeWGPUDevice device, DoeWGPURenderBundleEncoderDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPURenderPipeline DoewgpuDeviceCreateRenderPipeline(DoeWGPUDevice device, DoeWGPURenderPipelineDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuDeviceCreateRenderPipelineAsync(DoeWGPUDevice device, DoeWGPURenderPipelineDescriptor const * descriptor, DoeWGPUCreateRenderPipelineAsyncCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUSampler DoewgpuDeviceCreateSampler(DoeWGPUDevice device, DoeWGPU_NULLABLE DoeWGPUSamplerDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUShaderModule DoewgpuDeviceCreateShaderModule(DoeWGPUDevice device, DoeWGPUShaderModuleDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUTexture DoewgpuDeviceCreateTexture(DoeWGPUDevice device, DoeWGPUTextureDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuDeviceDestroy(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @param adapterInfo
 * This parameter is @ref ReturnedWithOwnership.
 *
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuDeviceGetAdapterInfo(DoeWGPUDevice device, DoeWGPUAdapterInfo * adapterInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Get the list of @ref DoeWGPUFeatureName values supported by the device.
 *
 * @param features
 * This parameter is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT void DoewgpuDeviceGetFeatures(DoeWGPUDevice device, DoeWGPUSupportedFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuDeviceGetLimits(DoeWGPUDevice device, DoeWGPULimits * limits) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * The @ref DoeWGPUFuture for the device-lost event of the device.
 */
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuDeviceGetLostFuture(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUQueue DoewgpuDeviceGetQueue(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUBool DoewgpuDeviceHasFeature(DoeWGPUDevice device, DoeWGPUFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Pops an error scope to the current thread's error scope stack,
 * asynchronously returning the result. See @ref ErrorScopes.
 */
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuDevicePopErrorScope(DoeWGPUDevice device, DoeWGPUPopErrorScopeCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Pushes an error scope to the current thread's error scope stack.
 * See @ref ErrorScopes.
 */
DoeWGPU_EXPORT void DoewgpuDevicePushErrorScope(DoeWGPUDevice device, DoeWGPUErrorFilter filter) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuDeviceSetLabel(DoeWGPUDevice device, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuDeviceAddRef(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuDeviceRelease(DoeWGPUDevice device) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUExternalTextureMethods DoeWGPUExternalTexture methods
 * \brief Functions whose first argument has type DoeWGPUExternalTexture.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuExternalTextureSetLabel(DoeWGPUExternalTexture externalTexture, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuExternalTextureAddRef(DoeWGPUExternalTexture externalTexture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuExternalTextureRelease(DoeWGPUExternalTexture externalTexture) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUInstanceMethods DoeWGPUInstance methods
 * \brief Functions whose first argument has type DoeWGPUInstance.
 *
 * @{
 */
/**
 * Creates a @ref DoeWGPUSurface, see @ref Surface-Creation for more details.
 *
 * @param descriptor
 * The description of the @ref DoeWGPUSurface to create.
 *
 * @returns
 * A new @ref DoeWGPUSurface for this descriptor (or an error @ref DoeWGPUSurface).
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUSurface DoewgpuInstanceCreateSurface(DoeWGPUInstance instance, DoeWGPUSurfaceDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Get the list of @ref DoeWGPUWGSLLanguageFeatureName values supported by the instance.
 */
DoeWGPU_EXPORT void DoewgpuInstanceGetWGSLLanguageFeatures(DoeWGPUInstance instance, DoeWGPUSupportedWGSLLanguageFeatures * features) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUBool DoewgpuInstanceHasWGSLLanguageFeature(DoeWGPUInstance instance, DoeWGPUWGSLLanguageFeatureName feature) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Processes asynchronous events on this `DoeWGPUInstance`, calling any callbacks for asynchronous operations created with @ref DoeWGPUCallbackMode_AllowProcessEvents.
 *
 * See @ref Process-Events for more information.
 */
DoeWGPU_EXPORT void DoewgpuInstanceProcessEvents(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuInstanceRequestAdapter(DoeWGPUInstance instance, DoeWGPU_NULLABLE DoeWGPURequestAdapterOptions const * options, DoeWGPURequestAdapterCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Wait for at least one DoeWGPUFuture in `futures` to complete, and call callbacks of the respective completed asynchronous operations.
 *
 * See @ref Wait-Any for more information.
 */
DoeWGPU_EXPORT DoeWGPUWaitStatus DoewgpuInstanceWaitAny(DoeWGPUInstance instance, size_t futureCount, DoeWGPU_NULLABLE DoeWGPUFutureWaitInfo * futures, uint64_t timeoutNS) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuInstanceAddRef(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuInstanceRelease(DoeWGPUInstance instance) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUPipelineLayoutMethods DoeWGPUPipelineLayout methods
 * \brief Functions whose first argument has type DoeWGPUPipelineLayout.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuPipelineLayoutSetLabel(DoeWGPUPipelineLayout pipelineLayout, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuPipelineLayoutAddRef(DoeWGPUPipelineLayout pipelineLayout) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuPipelineLayoutRelease(DoeWGPUPipelineLayout pipelineLayout) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUQuerySetMethods DoeWGPUQuerySet methods
 * \brief Functions whose first argument has type DoeWGPUQuerySet.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuQuerySetDestroy(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuQuerySetGetCount(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUQueryType DoewgpuQuerySetGetType(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQuerySetSetLabel(DoeWGPUQuerySet querySet, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQuerySetAddRef(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQuerySetRelease(DoeWGPUQuerySet querySet) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUQueueMethods DoeWGPUQueue methods
 * \brief Functions whose first argument has type DoeWGPUQueue.
 *
 * @{
 */
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuQueueOnSubmittedWorkDone(DoeWGPUQueue queue, DoeWGPUQueueWorkDoneCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQueueSetLabel(DoeWGPUQueue queue, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQueueSubmit(DoeWGPUQueue queue, size_t commandCount, DoeWGPUCommandBuffer const * commands) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Produces a @ref DeviceError both content-timeline (`size` alignment) and device-timeline
 * errors defined by the WebGPU specification.
 */
DoeWGPU_EXPORT void DoewgpuQueueWriteBuffer(DoeWGPUQueue queue, DoeWGPUBuffer buffer, uint64_t bufferOffset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQueueWriteTexture(DoeWGPUQueue queue, DoeWGPUTexelCopyTextureInfo const * destination, void const * data, size_t dataSize, DoeWGPUTexelCopyBufferLayout const * dataLayout, DoeWGPUExtent3D const * writeSize) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQueueAddRef(DoeWGPUQueue queue) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuQueueRelease(DoeWGPUQueue queue) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPURenderBundleMethods DoeWGPURenderBundle methods
 * \brief Functions whose first argument has type DoeWGPURenderBundle.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuRenderBundleSetLabel(DoeWGPURenderBundle renderBundle, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleAddRef(DoeWGPURenderBundle renderBundle) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleRelease(DoeWGPURenderBundle renderBundle) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPURenderBundleEncoderMethods DoeWGPURenderBundleEncoder methods
 * \brief Functions whose first argument has type DoeWGPURenderBundleEncoder.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderDraw(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t vertexCount, uint32_t instanceCount, uint32_t firstVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderDrawIndexed(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t indexCount, uint32_t instanceCount, uint32_t firstIndex, int32_t baseVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderDrawIndexedIndirect(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderDrawIndirect(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPURenderBundle DoewgpuRenderBundleEncoderFinish(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPU_NULLABLE DoeWGPURenderBundleDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderInsertDebugMarker(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderPopDebugGroup(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderPushDebugGroup(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetBindGroup(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetImmediates(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetIndexBuffer(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUBuffer buffer, DoeWGPUIndexFormat format, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetLabel(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetPipeline(DoeWGPURenderBundleEncoder renderBundleEncoder, DoeWGPURenderPipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderSetVertexBuffer(DoeWGPURenderBundleEncoder renderBundleEncoder, uint32_t slot, DoeWGPU_NULLABLE DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderAddRef(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderBundleEncoderRelease(DoeWGPURenderBundleEncoder renderBundleEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPURenderPassEncoderMethods DoeWGPURenderPassEncoder methods
 * \brief Functions whose first argument has type DoeWGPURenderPassEncoder.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderBeginOcclusionQuery(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t queryIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderDraw(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t vertexCount, uint32_t instanceCount, uint32_t firstVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderDrawIndexed(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t indexCount, uint32_t instanceCount, uint32_t firstIndex, int32_t baseVertex, uint32_t firstInstance) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderDrawIndexedIndirect(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderDrawIndirect(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer indirectBuffer, uint64_t indirectOffset) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderEnd(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderEndOcclusionQuery(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderExecuteBundles(DoeWGPURenderPassEncoder renderPassEncoder, size_t bundleCount, DoeWGPURenderBundle const * bundles) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderInsertDebugMarker(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView markerLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderPopDebugGroup(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderPushDebugGroup(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView groupLabel) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetBindGroup(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t groupIndex, DoeWGPU_NULLABLE DoeWGPUBindGroup group, size_t dynamicOffsetCount, uint32_t const * dynamicOffsets) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * @param color
 * The RGBA blend constant. Represents an `f32` color using @ref DoubleAsSupertype.
 */
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetBlendConstant(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUColor const * color) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetImmediates(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t offset, void const * data, size_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetIndexBuffer(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUBuffer buffer, DoeWGPUIndexFormat format, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetLabel(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetPipeline(DoeWGPURenderPassEncoder renderPassEncoder, DoeWGPURenderPipeline pipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetScissorRect(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t x, uint32_t y, uint32_t width, uint32_t height) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetStencilReference(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t reference) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetVertexBuffer(DoeWGPURenderPassEncoder renderPassEncoder, uint32_t slot, DoeWGPU_NULLABLE DoeWGPUBuffer buffer, uint64_t offset, uint64_t size) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * TODO
 *
 * If any argument is non-finite, produces a @ref NonFiniteFloatValueError.
 */
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderSetViewport(DoeWGPURenderPassEncoder renderPassEncoder, float x, float y, float width, float height, float minDepth, float maxDepth) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderAddRef(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPassEncoderRelease(DoeWGPURenderPassEncoder renderPassEncoder) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPURenderPipelineMethods DoeWGPURenderPipeline methods
 * \brief Functions whose first argument has type DoeWGPURenderPipeline.
 *
 * @{
 */
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUBindGroupLayout DoewgpuRenderPipelineGetBindGroupLayout(DoeWGPURenderPipeline renderPipeline, uint32_t groupIndex) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPipelineSetLabel(DoeWGPURenderPipeline renderPipeline, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPipelineAddRef(DoeWGPURenderPipeline renderPipeline) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuRenderPipelineRelease(DoeWGPURenderPipeline renderPipeline) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSamplerMethods DoeWGPUSampler methods
 * \brief Functions whose first argument has type DoeWGPUSampler.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuSamplerSetLabel(DoeWGPUSampler sampler, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuSamplerAddRef(DoeWGPUSampler sampler) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuSamplerRelease(DoeWGPUSampler sampler) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUShaderModuleMethods DoeWGPUShaderModule methods
 * \brief Functions whose first argument has type DoeWGPUShaderModule.
 *
 * @{
 */
DoeWGPU_EXPORT DoeWGPUFuture DoewgpuShaderModuleGetCompilationInfo(DoeWGPUShaderModule shaderModule, DoeWGPUCompilationInfoCallbackInfo callbackInfo) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuShaderModuleSetLabel(DoeWGPUShaderModule shaderModule, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuShaderModuleAddRef(DoeWGPUShaderModule shaderModule) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuShaderModuleRelease(DoeWGPUShaderModule shaderModule) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSupportedFeaturesMethods DoeWGPUSupportedFeatures methods
 * \brief Functions whose first argument has type DoeWGPUSupportedFeatures.
 *
 * @{
 */
/**
 * Frees members which were allocated by the API.
 */
DoeWGPU_EXPORT void DoewgpuSupportedFeaturesFreeMembers(DoeWGPUSupportedFeatures supportedFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSupportedInstanceFeaturesMethods DoeWGPUSupportedInstanceFeatures methods
 * \brief Functions whose first argument has type DoeWGPUSupportedInstanceFeatures.
 *
 * @{
 */
/**
 * Frees members which were allocated by the API.
 */
DoeWGPU_EXPORT void DoewgpuSupportedInstanceFeaturesFreeMembers(DoeWGPUSupportedInstanceFeatures supportedInstanceFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSupportedWGSLLanguageFeaturesMethods DoeWGPUSupportedWGSLLanguageFeatures methods
 * \brief Functions whose first argument has type DoeWGPUSupportedWGSLLanguageFeatures.
 *
 * @{
 */
/**
 * Frees members which were allocated by the API.
 */
DoeWGPU_EXPORT void DoewgpuSupportedWGSLLanguageFeaturesFreeMembers(DoeWGPUSupportedWGSLLanguageFeatures supportedWGSLLanguageFeatures) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSurfaceMethods DoeWGPUSurface methods
 * \brief Functions whose first argument has type DoeWGPUSurface.
 *
 * @{
 */
/**
 * Configures parameters for rendering to `surface`.
 * Produces a @ref DeviceError for all content-timeline errors defined by the WebGPU specification.
 *
 * See @ref Surface-Configuration for more details.
 *
 * @param config
 * The new configuration to use.
 */
DoeWGPU_EXPORT void DoewgpuSurfaceConfigure(DoeWGPUSurface surface, DoeWGPUSurfaceConfiguration const * config) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Provides information on how `adapter` is able to use `surface`.
 * See @ref Surface-Capabilities for more details.
 *
 * @param adapter
 * The @ref DoeWGPUAdapter to get capabilities for presenting to this @ref DoeWGPUSurface.
 *
 * @param capabilities
 * The structure to fill capabilities in.
 * It may contain memory allocations so @ref DoewgpuSurfaceCapabilitiesFreeMembers must be called to avoid memory leaks.
 * This parameter is @ref ReturnedWithOwnership.
 *
 * @returns
 * Indicates if there was an @ref OutStructChainError.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuSurfaceGetCapabilities(DoeWGPUSurface surface, DoeWGPUAdapter adapter, DoeWGPUSurfaceCapabilities * capabilities) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Returns the @ref DoeWGPUTexture to render to `surface` this frame along with metadata on the frame.
 * Returns `NULL` and @ref DoeWGPUSurfaceGetCurrentTextureStatus_Error if the surface is not configured.
 *
 * See @ref Surface-Presenting for more details.
 *
 * @param surfaceTexture
 * The structure to fill the @ref DoeWGPUTexture and metadata in.
 */
DoeWGPU_EXPORT void DoewgpuSurfaceGetCurrentTexture(DoeWGPUSurface surface, DoeWGPUSurfaceTexture * surfaceTexture) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Shows `surface`'s current texture to the user.
 * See @ref Surface-Presenting for more details.
 *
 * @returns
 * Returns @ref DoeWGPUStatus_Error if the surface doesn't have a current texture.
 */
DoeWGPU_EXPORT DoeWGPUStatus DoewgpuSurfacePresent(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Modifies the label used to refer to `surface`.
 *
 * @param label
 * The new label.
 */
DoeWGPU_EXPORT void DoewgpuSurfaceSetLabel(DoeWGPUSurface surface, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
/**
 * Removes the configuration for `surface`.
 * See @ref Surface-Configuration for more details.
 */
DoeWGPU_EXPORT void DoewgpuSurfaceUnconfigure(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuSurfaceAddRef(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuSurfaceRelease(DoeWGPUSurface surface) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUSurfaceCapabilitiesMethods DoeWGPUSurfaceCapabilities methods
 * \brief Functions whose first argument has type DoeWGPUSurfaceCapabilities.
 *
 * @{
 */
/**
 * Frees members which were allocated by the API.
 */
DoeWGPU_EXPORT void DoewgpuSurfaceCapabilitiesFreeMembers(DoeWGPUSurfaceCapabilities surfaceCapabilities) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUTextureMethods DoeWGPUTexture methods
 * \brief Functions whose first argument has type DoeWGPUTexture.
 *
 * @{
 */
/**
 * @returns
 * This value is @ref ReturnedWithOwnership.
 */
DoeWGPU_EXPORT DoeWGPUTextureView DoewgpuTextureCreateView(DoeWGPUTexture texture, DoeWGPU_NULLABLE DoeWGPUTextureViewDescriptor const * descriptor) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureDestroy(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuTextureGetDepthOrArrayLayers(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUTextureDimension DoewgpuTextureGetDimension(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUTextureFormat DoewgpuTextureGetFormat(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuTextureGetHeight(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuTextureGetMipLevelCount(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuTextureGetSampleCount(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUTextureViewDimension DoewgpuTextureGetTextureBindingViewDimension(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT DoeWGPUTextureUsage DoewgpuTextureGetUsage(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT uint32_t DoewgpuTextureGetWidth(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureSetLabel(DoeWGPUTexture texture, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureAddRef(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureRelease(DoeWGPUTexture texture) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/**
 * \defgroup DoeWGPUTextureViewMethods DoeWGPUTextureView methods
 * \brief Functions whose first argument has type DoeWGPUTextureView.
 *
 * @{
 */
DoeWGPU_EXPORT void DoewgpuTextureViewSetLabel(DoeWGPUTextureView textureView, DoeWGPUStringView label) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureViewAddRef(DoeWGPUTextureView textureView) DoeWGPU_FUNCTION_ATTRIBUTE;
DoeWGPU_EXPORT void DoewgpuTextureViewRelease(DoeWGPUTextureView textureView) DoeWGPU_FUNCTION_ATTRIBUTE;

/** @} */

/** @} */

#endif  // !defined(DoeWGPU_SKIP_DECLARATIONS)

#ifdef __cplusplus
} // extern "C"
#endif

#endif // DOE_WEBGPU_H_
