const bridge = @import("adapter.zig");
const c = bridge.c;
const F_createInstance = @typeInfo(@typeInfo(c.WGPUProcCreateInstance).optional.child).pointer.child;
pub fn createInstance(a0: @typeInfo(F_createInstance).@"fn".params[0].type.?) callconv(.c) bridge.Return("createInstance") {
    return bridge.invoke("createInstance", .{a0});
}
const F_getInstanceFeatures = @typeInfo(@typeInfo(c.WGPUProcGetInstanceFeatures).optional.child).pointer.child;
pub fn getInstanceFeatures(a0: @typeInfo(F_getInstanceFeatures).@"fn".params[0].type.?) callconv(.c) bridge.Return("getInstanceFeatures") {
    return bridge.invoke("getInstanceFeatures", .{a0});
}
const F_getInstanceLimits = @typeInfo(@typeInfo(c.WGPUProcGetInstanceLimits).optional.child).pointer.child;
pub fn getInstanceLimits(a0: @typeInfo(F_getInstanceLimits).@"fn".params[0].type.?) callconv(.c) bridge.Return("getInstanceLimits") {
    return bridge.invoke("getInstanceLimits", .{a0});
}
const F_hasInstanceFeature = @typeInfo(@typeInfo(c.WGPUProcHasInstanceFeature).optional.child).pointer.child;
pub fn hasInstanceFeature(a0: @typeInfo(F_hasInstanceFeature).@"fn".params[0].type.?) callconv(.c) bridge.Return("hasInstanceFeature") {
    return bridge.invoke("hasInstanceFeature", .{a0});
}
const F_getProcAddress = @typeInfo(@typeInfo(c.WGPUProcGetProcAddress).optional.child).pointer.child;
pub fn getProcAddress(a0: @typeInfo(F_getProcAddress).@"fn".params[0].type.?) callconv(.c) bridge.Return("getProcAddress") {
    return bridge.invoke("getProcAddress", .{a0});
}
const F_adapterCreateDevice = @typeInfo(@typeInfo(c.WGPUProcAdapterCreateDevice).optional.child).pointer.child;
pub fn adapterCreateDevice(a0: @typeInfo(F_adapterCreateDevice).@"fn".params[0].type.?, a1: @typeInfo(F_adapterCreateDevice).@"fn".params[1].type.?) callconv(.c) bridge.Return("adapterCreateDevice") {
    return bridge.invoke("adapterCreateDevice", .{a0, a1});
}
const F_adapterGetFeatures = @typeInfo(@typeInfo(c.WGPUProcAdapterGetFeatures).optional.child).pointer.child;
pub fn adapterGetFeatures(a0: @typeInfo(F_adapterGetFeatures).@"fn".params[0].type.?, a1: @typeInfo(F_adapterGetFeatures).@"fn".params[1].type.?) callconv(.c) bridge.Return("adapterGetFeatures") {
    return bridge.invoke("adapterGetFeatures", .{a0, a1});
}
const F_adapterGetFormatCapabilities = @typeInfo(@typeInfo(c.WGPUProcAdapterGetFormatCapabilities).optional.child).pointer.child;
pub fn adapterGetFormatCapabilities(a0: @typeInfo(F_adapterGetFormatCapabilities).@"fn".params[0].type.?, a1: @typeInfo(F_adapterGetFormatCapabilities).@"fn".params[1].type.?, a2: @typeInfo(F_adapterGetFormatCapabilities).@"fn".params[2].type.?) callconv(.c) bridge.Return("adapterGetFormatCapabilities") {
    return bridge.invoke("adapterGetFormatCapabilities", .{a0, a1, a2});
}
const F_adapterGetInfo = @typeInfo(@typeInfo(c.WGPUProcAdapterGetInfo).optional.child).pointer.child;
pub fn adapterGetInfo(a0: @typeInfo(F_adapterGetInfo).@"fn".params[0].type.?, a1: @typeInfo(F_adapterGetInfo).@"fn".params[1].type.?) callconv(.c) bridge.Return("adapterGetInfo") {
    return bridge.invoke("adapterGetInfo", .{a0, a1});
}
const F_adapterGetInstance = @typeInfo(@typeInfo(c.WGPUProcAdapterGetInstance).optional.child).pointer.child;
pub fn adapterGetInstance(a0: @typeInfo(F_adapterGetInstance).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterGetInstance") {
    return bridge.invoke("adapterGetInstance", .{a0});
}
const F_adapterGetLimits = @typeInfo(@typeInfo(c.WGPUProcAdapterGetLimits).optional.child).pointer.child;
pub fn adapterGetLimits(a0: @typeInfo(F_adapterGetLimits).@"fn".params[0].type.?, a1: @typeInfo(F_adapterGetLimits).@"fn".params[1].type.?) callconv(.c) bridge.Return("adapterGetLimits") {
    return bridge.invoke("adapterGetLimits", .{a0, a1});
}
const F_adapterHasFeature = @typeInfo(@typeInfo(c.WGPUProcAdapterHasFeature).optional.child).pointer.child;
pub fn adapterHasFeature(a0: @typeInfo(F_adapterHasFeature).@"fn".params[0].type.?, a1: @typeInfo(F_adapterHasFeature).@"fn".params[1].type.?) callconv(.c) bridge.Return("adapterHasFeature") {
    return bridge.invoke("adapterHasFeature", .{a0, a1});
}
const F_adapterRequestDevice = @typeInfo(@typeInfo(c.WGPUProcAdapterRequestDevice).optional.child).pointer.child;
pub fn adapterRequestDevice(a0: @typeInfo(F_adapterRequestDevice).@"fn".params[0].type.?, a1: @typeInfo(F_adapterRequestDevice).@"fn".params[1].type.?, a2: @typeInfo(F_adapterRequestDevice).@"fn".params[2].type.?) callconv(.c) bridge.Return("adapterRequestDevice") {
    return bridge.invoke("adapterRequestDevice", .{a0, a1, a2});
}
const F_adapterAddRef = @typeInfo(@typeInfo(c.WGPUProcAdapterAddRef).optional.child).pointer.child;
pub fn adapterAddRef(a0: @typeInfo(F_adapterAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterAddRef") {
    return bridge.invoke("adapterAddRef", .{a0});
}
const F_adapterRelease = @typeInfo(@typeInfo(c.WGPUProcAdapterRelease).optional.child).pointer.child;
pub fn adapterRelease(a0: @typeInfo(F_adapterRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterRelease") {
    return bridge.invoke("adapterRelease", .{a0});
}
const F_adapterInfoFreeMembers = @typeInfo(@typeInfo(c.WGPUProcAdapterInfoFreeMembers).optional.child).pointer.child;
pub fn adapterInfoFreeMembers(a0: @typeInfo(F_adapterInfoFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterInfoFreeMembers") {
    return bridge.invoke("adapterInfoFreeMembers", .{a0});
}
const F_adapterPropertiesMemoryHeapsFreeMembers = @typeInfo(@typeInfo(c.WGPUProcAdapterPropertiesMemoryHeapsFreeMembers).optional.child).pointer.child;
pub fn adapterPropertiesMemoryHeapsFreeMembers(a0: @typeInfo(F_adapterPropertiesMemoryHeapsFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterPropertiesMemoryHeapsFreeMembers") {
    return bridge.invoke("adapterPropertiesMemoryHeapsFreeMembers", .{a0});
}
const F_adapterPropertiesSubgroupMatrixConfigsFreeMembers = @typeInfo(@typeInfo(c.WGPUProcAdapterPropertiesSubgroupMatrixConfigsFreeMembers).optional.child).pointer.child;
pub fn adapterPropertiesSubgroupMatrixConfigsFreeMembers(a0: @typeInfo(F_adapterPropertiesSubgroupMatrixConfigsFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("adapterPropertiesSubgroupMatrixConfigsFreeMembers") {
    return bridge.invoke("adapterPropertiesSubgroupMatrixConfigsFreeMembers", .{a0});
}
const F_bindGroupSetLabel = @typeInfo(@typeInfo(c.WGPUProcBindGroupSetLabel).optional.child).pointer.child;
pub fn bindGroupSetLabel(a0: @typeInfo(F_bindGroupSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_bindGroupSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("bindGroupSetLabel") {
    return bridge.invoke("bindGroupSetLabel", .{a0, a1});
}
const F_bindGroupAddRef = @typeInfo(@typeInfo(c.WGPUProcBindGroupAddRef).optional.child).pointer.child;
pub fn bindGroupAddRef(a0: @typeInfo(F_bindGroupAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("bindGroupAddRef") {
    return bridge.invoke("bindGroupAddRef", .{a0});
}
const F_bindGroupRelease = @typeInfo(@typeInfo(c.WGPUProcBindGroupRelease).optional.child).pointer.child;
pub fn bindGroupRelease(a0: @typeInfo(F_bindGroupRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("bindGroupRelease") {
    return bridge.invoke("bindGroupRelease", .{a0});
}
const F_bindGroupLayoutSetLabel = @typeInfo(@typeInfo(c.WGPUProcBindGroupLayoutSetLabel).optional.child).pointer.child;
pub fn bindGroupLayoutSetLabel(a0: @typeInfo(F_bindGroupLayoutSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_bindGroupLayoutSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("bindGroupLayoutSetLabel") {
    return bridge.invoke("bindGroupLayoutSetLabel", .{a0, a1});
}
const F_bindGroupLayoutAddRef = @typeInfo(@typeInfo(c.WGPUProcBindGroupLayoutAddRef).optional.child).pointer.child;
pub fn bindGroupLayoutAddRef(a0: @typeInfo(F_bindGroupLayoutAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("bindGroupLayoutAddRef") {
    return bridge.invoke("bindGroupLayoutAddRef", .{a0});
}
const F_bindGroupLayoutRelease = @typeInfo(@typeInfo(c.WGPUProcBindGroupLayoutRelease).optional.child).pointer.child;
pub fn bindGroupLayoutRelease(a0: @typeInfo(F_bindGroupLayoutRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("bindGroupLayoutRelease") {
    return bridge.invoke("bindGroupLayoutRelease", .{a0});
}
const F_bufferCreateTexelView = @typeInfo(@typeInfo(c.WGPUProcBufferCreateTexelView).optional.child).pointer.child;
pub fn bufferCreateTexelView(a0: @typeInfo(F_bufferCreateTexelView).@"fn".params[0].type.?, a1: @typeInfo(F_bufferCreateTexelView).@"fn".params[1].type.?) callconv(.c) bridge.Return("bufferCreateTexelView") {
    return bridge.invoke("bufferCreateTexelView", .{a0, a1});
}
const F_bufferDestroy = @typeInfo(@typeInfo(c.WGPUProcBufferDestroy).optional.child).pointer.child;
pub fn bufferDestroy(a0: @typeInfo(F_bufferDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferDestroy") {
    return bridge.invoke("bufferDestroy", .{a0});
}
const F_bufferGetConstMappedRange = @typeInfo(@typeInfo(c.WGPUProcBufferGetConstMappedRange).optional.child).pointer.child;
pub fn bufferGetConstMappedRange(a0: @typeInfo(F_bufferGetConstMappedRange).@"fn".params[0].type.?, a1: @typeInfo(F_bufferGetConstMappedRange).@"fn".params[1].type.?, a2: @typeInfo(F_bufferGetConstMappedRange).@"fn".params[2].type.?) callconv(.c) bridge.Return("bufferGetConstMappedRange") {
    return bridge.invoke("bufferGetConstMappedRange", .{a0, a1, a2});
}
const F_bufferGetMappedRange = @typeInfo(@typeInfo(c.WGPUProcBufferGetMappedRange).optional.child).pointer.child;
pub fn bufferGetMappedRange(a0: @typeInfo(F_bufferGetMappedRange).@"fn".params[0].type.?, a1: @typeInfo(F_bufferGetMappedRange).@"fn".params[1].type.?, a2: @typeInfo(F_bufferGetMappedRange).@"fn".params[2].type.?) callconv(.c) bridge.Return("bufferGetMappedRange") {
    return bridge.invoke("bufferGetMappedRange", .{a0, a1, a2});
}
const F_bufferGetMapState = @typeInfo(@typeInfo(c.WGPUProcBufferGetMapState).optional.child).pointer.child;
pub fn bufferGetMapState(a0: @typeInfo(F_bufferGetMapState).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferGetMapState") {
    return bridge.invoke("bufferGetMapState", .{a0});
}
const F_bufferGetSize = @typeInfo(@typeInfo(c.WGPUProcBufferGetSize).optional.child).pointer.child;
pub fn bufferGetSize(a0: @typeInfo(F_bufferGetSize).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferGetSize") {
    return bridge.invoke("bufferGetSize", .{a0});
}
const F_bufferGetUsage = @typeInfo(@typeInfo(c.WGPUProcBufferGetUsage).optional.child).pointer.child;
pub fn bufferGetUsage(a0: @typeInfo(F_bufferGetUsage).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferGetUsage") {
    return bridge.invoke("bufferGetUsage", .{a0});
}
const F_bufferMapAsync = @typeInfo(@typeInfo(c.WGPUProcBufferMapAsync).optional.child).pointer.child;
pub fn bufferMapAsync(a0: @typeInfo(F_bufferMapAsync).@"fn".params[0].type.?, a1: @typeInfo(F_bufferMapAsync).@"fn".params[1].type.?, a2: @typeInfo(F_bufferMapAsync).@"fn".params[2].type.?, a3: @typeInfo(F_bufferMapAsync).@"fn".params[3].type.?, a4: @typeInfo(F_bufferMapAsync).@"fn".params[4].type.?) callconv(.c) bridge.Return("bufferMapAsync") {
    return bridge.invoke("bufferMapAsync", .{a0, a1, a2, a3, a4});
}
const F_bufferReadMappedRange = @typeInfo(@typeInfo(c.WGPUProcBufferReadMappedRange).optional.child).pointer.child;
pub fn bufferReadMappedRange(a0: @typeInfo(F_bufferReadMappedRange).@"fn".params[0].type.?, a1: @typeInfo(F_bufferReadMappedRange).@"fn".params[1].type.?, a2: @typeInfo(F_bufferReadMappedRange).@"fn".params[2].type.?, a3: @typeInfo(F_bufferReadMappedRange).@"fn".params[3].type.?) callconv(.c) bridge.Return("bufferReadMappedRange") {
    return bridge.invoke("bufferReadMappedRange", .{a0, a1, a2, a3});
}
const F_bufferSetLabel = @typeInfo(@typeInfo(c.WGPUProcBufferSetLabel).optional.child).pointer.child;
pub fn bufferSetLabel(a0: @typeInfo(F_bufferSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_bufferSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("bufferSetLabel") {
    return bridge.invoke("bufferSetLabel", .{a0, a1});
}
const F_bufferUnmap = @typeInfo(@typeInfo(c.WGPUProcBufferUnmap).optional.child).pointer.child;
pub fn bufferUnmap(a0: @typeInfo(F_bufferUnmap).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferUnmap") {
    return bridge.invoke("bufferUnmap", .{a0});
}
const F_bufferWriteMappedRange = @typeInfo(@typeInfo(c.WGPUProcBufferWriteMappedRange).optional.child).pointer.child;
pub fn bufferWriteMappedRange(a0: @typeInfo(F_bufferWriteMappedRange).@"fn".params[0].type.?, a1: @typeInfo(F_bufferWriteMappedRange).@"fn".params[1].type.?, a2: @typeInfo(F_bufferWriteMappedRange).@"fn".params[2].type.?, a3: @typeInfo(F_bufferWriteMappedRange).@"fn".params[3].type.?) callconv(.c) bridge.Return("bufferWriteMappedRange") {
    return bridge.invoke("bufferWriteMappedRange", .{a0, a1, a2, a3});
}
const F_bufferAddRef = @typeInfo(@typeInfo(c.WGPUProcBufferAddRef).optional.child).pointer.child;
pub fn bufferAddRef(a0: @typeInfo(F_bufferAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferAddRef") {
    return bridge.invoke("bufferAddRef", .{a0});
}
const F_bufferRelease = @typeInfo(@typeInfo(c.WGPUProcBufferRelease).optional.child).pointer.child;
pub fn bufferRelease(a0: @typeInfo(F_bufferRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("bufferRelease") {
    return bridge.invoke("bufferRelease", .{a0});
}
const F_commandBufferSetLabel = @typeInfo(@typeInfo(c.WGPUProcCommandBufferSetLabel).optional.child).pointer.child;
pub fn commandBufferSetLabel(a0: @typeInfo(F_commandBufferSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_commandBufferSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandBufferSetLabel") {
    return bridge.invoke("commandBufferSetLabel", .{a0, a1});
}
const F_commandBufferAddRef = @typeInfo(@typeInfo(c.WGPUProcCommandBufferAddRef).optional.child).pointer.child;
pub fn commandBufferAddRef(a0: @typeInfo(F_commandBufferAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("commandBufferAddRef") {
    return bridge.invoke("commandBufferAddRef", .{a0});
}
const F_commandBufferRelease = @typeInfo(@typeInfo(c.WGPUProcCommandBufferRelease).optional.child).pointer.child;
pub fn commandBufferRelease(a0: @typeInfo(F_commandBufferRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("commandBufferRelease") {
    return bridge.invoke("commandBufferRelease", .{a0});
}
const F_commandEncoderBeginComputePass = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderBeginComputePass).optional.child).pointer.child;
pub fn commandEncoderBeginComputePass(a0: @typeInfo(F_commandEncoderBeginComputePass).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderBeginComputePass).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderBeginComputePass") {
    return bridge.invoke("commandEncoderBeginComputePass", .{a0, a1});
}
const F_commandEncoderBeginRenderPass = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderBeginRenderPass).optional.child).pointer.child;
pub fn commandEncoderBeginRenderPass(a0: @typeInfo(F_commandEncoderBeginRenderPass).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderBeginRenderPass).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderBeginRenderPass") {
    return bridge.invoke("commandEncoderBeginRenderPass", .{a0, a1});
}
const F_commandEncoderClearBuffer = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderClearBuffer).optional.child).pointer.child;
pub fn commandEncoderClearBuffer(a0: @typeInfo(F_commandEncoderClearBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderClearBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderClearBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderClearBuffer).@"fn".params[3].type.?) callconv(.c) bridge.Return("commandEncoderClearBuffer") {
    return bridge.invoke("commandEncoderClearBuffer", .{a0, a1, a2, a3});
}
const F_commandEncoderCopyBufferToBuffer = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderCopyBufferToBuffer).optional.child).pointer.child;
pub fn commandEncoderCopyBufferToBuffer(a0: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[4].type.?, a5: @typeInfo(F_commandEncoderCopyBufferToBuffer).@"fn".params[5].type.?) callconv(.c) bridge.Return("commandEncoderCopyBufferToBuffer") {
    return bridge.invoke("commandEncoderCopyBufferToBuffer", .{a0, a1, a2, a3, a4, a5});
}
const F_commandEncoderCopyBufferToTexture = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderCopyBufferToTexture).optional.child).pointer.child;
pub fn commandEncoderCopyBufferToTexture(a0: @typeInfo(F_commandEncoderCopyBufferToTexture).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderCopyBufferToTexture).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderCopyBufferToTexture).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderCopyBufferToTexture).@"fn".params[3].type.?) callconv(.c) bridge.Return("commandEncoderCopyBufferToTexture") {
    return bridge.invoke("commandEncoderCopyBufferToTexture", .{a0, a1, a2, a3});
}
const F_commandEncoderCopyTextureToBuffer = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderCopyTextureToBuffer).optional.child).pointer.child;
pub fn commandEncoderCopyTextureToBuffer(a0: @typeInfo(F_commandEncoderCopyTextureToBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderCopyTextureToBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderCopyTextureToBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderCopyTextureToBuffer).@"fn".params[3].type.?) callconv(.c) bridge.Return("commandEncoderCopyTextureToBuffer") {
    return bridge.invoke("commandEncoderCopyTextureToBuffer", .{a0, a1, a2, a3});
}
const F_commandEncoderCopyTextureToTexture = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderCopyTextureToTexture).optional.child).pointer.child;
pub fn commandEncoderCopyTextureToTexture(a0: @typeInfo(F_commandEncoderCopyTextureToTexture).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderCopyTextureToTexture).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderCopyTextureToTexture).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderCopyTextureToTexture).@"fn".params[3].type.?) callconv(.c) bridge.Return("commandEncoderCopyTextureToTexture") {
    return bridge.invoke("commandEncoderCopyTextureToTexture", .{a0, a1, a2, a3});
}
const F_commandEncoderFinish = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderFinish).optional.child).pointer.child;
pub fn commandEncoderFinish(a0: @typeInfo(F_commandEncoderFinish).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderFinish).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderFinish") {
    return bridge.invoke("commandEncoderFinish", .{a0, a1});
}
const F_commandEncoderInjectValidationError = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderInjectValidationError).optional.child).pointer.child;
pub fn commandEncoderInjectValidationError(a0: @typeInfo(F_commandEncoderInjectValidationError).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderInjectValidationError).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderInjectValidationError") {
    return bridge.invoke("commandEncoderInjectValidationError", .{a0, a1});
}
const F_commandEncoderInsertDebugMarker = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderInsertDebugMarker).optional.child).pointer.child;
pub fn commandEncoderInsertDebugMarker(a0: @typeInfo(F_commandEncoderInsertDebugMarker).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderInsertDebugMarker).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderInsertDebugMarker") {
    return bridge.invoke("commandEncoderInsertDebugMarker", .{a0, a1});
}
const F_commandEncoderPopDebugGroup = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderPopDebugGroup).optional.child).pointer.child;
pub fn commandEncoderPopDebugGroup(a0: @typeInfo(F_commandEncoderPopDebugGroup).@"fn".params[0].type.?) callconv(.c) bridge.Return("commandEncoderPopDebugGroup") {
    return bridge.invoke("commandEncoderPopDebugGroup", .{a0});
}
const F_commandEncoderPushDebugGroup = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderPushDebugGroup).optional.child).pointer.child;
pub fn commandEncoderPushDebugGroup(a0: @typeInfo(F_commandEncoderPushDebugGroup).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderPushDebugGroup).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderPushDebugGroup") {
    return bridge.invoke("commandEncoderPushDebugGroup", .{a0, a1});
}
const F_commandEncoderResolveQuerySet = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderResolveQuerySet).optional.child).pointer.child;
pub fn commandEncoderResolveQuerySet(a0: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[3].type.?, a4: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[4].type.?, a5: @typeInfo(F_commandEncoderResolveQuerySet).@"fn".params[5].type.?) callconv(.c) bridge.Return("commandEncoderResolveQuerySet") {
    return bridge.invoke("commandEncoderResolveQuerySet", .{a0, a1, a2, a3, a4, a5});
}
const F_commandEncoderSetLabel = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderSetLabel).optional.child).pointer.child;
pub fn commandEncoderSetLabel(a0: @typeInfo(F_commandEncoderSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderSetLabel") {
    return bridge.invoke("commandEncoderSetLabel", .{a0, a1});
}
const F_commandEncoderSetResourceTable = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderSetResourceTable).optional.child).pointer.child;
pub fn commandEncoderSetResourceTable(a0: @typeInfo(F_commandEncoderSetResourceTable).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderSetResourceTable).@"fn".params[1].type.?) callconv(.c) bridge.Return("commandEncoderSetResourceTable") {
    return bridge.invoke("commandEncoderSetResourceTable", .{a0, a1});
}
const F_commandEncoderWriteBuffer = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderWriteBuffer).optional.child).pointer.child;
pub fn commandEncoderWriteBuffer(a0: @typeInfo(F_commandEncoderWriteBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderWriteBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderWriteBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_commandEncoderWriteBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_commandEncoderWriteBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("commandEncoderWriteBuffer") {
    return bridge.invoke("commandEncoderWriteBuffer", .{a0, a1, a2, a3, a4});
}
const F_commandEncoderWriteTimestamp = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderWriteTimestamp).optional.child).pointer.child;
pub fn commandEncoderWriteTimestamp(a0: @typeInfo(F_commandEncoderWriteTimestamp).@"fn".params[0].type.?, a1: @typeInfo(F_commandEncoderWriteTimestamp).@"fn".params[1].type.?, a2: @typeInfo(F_commandEncoderWriteTimestamp).@"fn".params[2].type.?) callconv(.c) bridge.Return("commandEncoderWriteTimestamp") {
    return bridge.invoke("commandEncoderWriteTimestamp", .{a0, a1, a2});
}
const F_commandEncoderAddRef = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderAddRef).optional.child).pointer.child;
pub fn commandEncoderAddRef(a0: @typeInfo(F_commandEncoderAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("commandEncoderAddRef") {
    return bridge.invoke("commandEncoderAddRef", .{a0});
}
const F_commandEncoderRelease = @typeInfo(@typeInfo(c.WGPUProcCommandEncoderRelease).optional.child).pointer.child;
pub fn commandEncoderRelease(a0: @typeInfo(F_commandEncoderRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("commandEncoderRelease") {
    return bridge.invoke("commandEncoderRelease", .{a0});
}
const F_computePassEncoderDispatchWorkgroups = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderDispatchWorkgroups).optional.child).pointer.child;
pub fn computePassEncoderDispatchWorkgroups(a0: @typeInfo(F_computePassEncoderDispatchWorkgroups).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderDispatchWorkgroups).@"fn".params[1].type.?, a2: @typeInfo(F_computePassEncoderDispatchWorkgroups).@"fn".params[2].type.?, a3: @typeInfo(F_computePassEncoderDispatchWorkgroups).@"fn".params[3].type.?) callconv(.c) bridge.Return("computePassEncoderDispatchWorkgroups") {
    return bridge.invoke("computePassEncoderDispatchWorkgroups", .{a0, a1, a2, a3});
}
const F_computePassEncoderDispatchWorkgroupsIndirect = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderDispatchWorkgroupsIndirect).optional.child).pointer.child;
pub fn computePassEncoderDispatchWorkgroupsIndirect(a0: @typeInfo(F_computePassEncoderDispatchWorkgroupsIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderDispatchWorkgroupsIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_computePassEncoderDispatchWorkgroupsIndirect).@"fn".params[2].type.?) callconv(.c) bridge.Return("computePassEncoderDispatchWorkgroupsIndirect") {
    return bridge.invoke("computePassEncoderDispatchWorkgroupsIndirect", .{a0, a1, a2});
}
const F_computePassEncoderEnd = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderEnd).optional.child).pointer.child;
pub fn computePassEncoderEnd(a0: @typeInfo(F_computePassEncoderEnd).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePassEncoderEnd") {
    return bridge.invoke("computePassEncoderEnd", .{a0});
}
const F_computePassEncoderInsertDebugMarker = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderInsertDebugMarker).optional.child).pointer.child;
pub fn computePassEncoderInsertDebugMarker(a0: @typeInfo(F_computePassEncoderInsertDebugMarker).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderInsertDebugMarker).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePassEncoderInsertDebugMarker") {
    return bridge.invoke("computePassEncoderInsertDebugMarker", .{a0, a1});
}
const F_computePassEncoderPopDebugGroup = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderPopDebugGroup).optional.child).pointer.child;
pub fn computePassEncoderPopDebugGroup(a0: @typeInfo(F_computePassEncoderPopDebugGroup).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePassEncoderPopDebugGroup") {
    return bridge.invoke("computePassEncoderPopDebugGroup", .{a0});
}
const F_computePassEncoderPushDebugGroup = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderPushDebugGroup).optional.child).pointer.child;
pub fn computePassEncoderPushDebugGroup(a0: @typeInfo(F_computePassEncoderPushDebugGroup).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderPushDebugGroup).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePassEncoderPushDebugGroup") {
    return bridge.invoke("computePassEncoderPushDebugGroup", .{a0, a1});
}
const F_computePassEncoderSetBindGroup = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderSetBindGroup).optional.child).pointer.child;
pub fn computePassEncoderSetBindGroup(a0: @typeInfo(F_computePassEncoderSetBindGroup).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderSetBindGroup).@"fn".params[1].type.?, a2: @typeInfo(F_computePassEncoderSetBindGroup).@"fn".params[2].type.?, a3: @typeInfo(F_computePassEncoderSetBindGroup).@"fn".params[3].type.?, a4: @typeInfo(F_computePassEncoderSetBindGroup).@"fn".params[4].type.?) callconv(.c) bridge.Return("computePassEncoderSetBindGroup") {
    return bridge.invoke("computePassEncoderSetBindGroup", .{a0, a1, a2, a3, a4});
}
const F_computePassEncoderSetImmediates = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderSetImmediates).optional.child).pointer.child;
pub fn computePassEncoderSetImmediates(a0: @typeInfo(F_computePassEncoderSetImmediates).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderSetImmediates).@"fn".params[1].type.?, a2: @typeInfo(F_computePassEncoderSetImmediates).@"fn".params[2].type.?, a3: @typeInfo(F_computePassEncoderSetImmediates).@"fn".params[3].type.?) callconv(.c) bridge.Return("computePassEncoderSetImmediates") {
    return bridge.invoke("computePassEncoderSetImmediates", .{a0, a1, a2, a3});
}
const F_computePassEncoderSetLabel = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderSetLabel).optional.child).pointer.child;
pub fn computePassEncoderSetLabel(a0: @typeInfo(F_computePassEncoderSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePassEncoderSetLabel") {
    return bridge.invoke("computePassEncoderSetLabel", .{a0, a1});
}
const F_computePassEncoderSetPipeline = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderSetPipeline).optional.child).pointer.child;
pub fn computePassEncoderSetPipeline(a0: @typeInfo(F_computePassEncoderSetPipeline).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderSetPipeline).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePassEncoderSetPipeline") {
    return bridge.invoke("computePassEncoderSetPipeline", .{a0, a1});
}
const F_computePassEncoderWriteTimestamp = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderWriteTimestamp).optional.child).pointer.child;
pub fn computePassEncoderWriteTimestamp(a0: @typeInfo(F_computePassEncoderWriteTimestamp).@"fn".params[0].type.?, a1: @typeInfo(F_computePassEncoderWriteTimestamp).@"fn".params[1].type.?, a2: @typeInfo(F_computePassEncoderWriteTimestamp).@"fn".params[2].type.?) callconv(.c) bridge.Return("computePassEncoderWriteTimestamp") {
    return bridge.invoke("computePassEncoderWriteTimestamp", .{a0, a1, a2});
}
const F_computePassEncoderAddRef = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderAddRef).optional.child).pointer.child;
pub fn computePassEncoderAddRef(a0: @typeInfo(F_computePassEncoderAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePassEncoderAddRef") {
    return bridge.invoke("computePassEncoderAddRef", .{a0});
}
const F_computePassEncoderRelease = @typeInfo(@typeInfo(c.WGPUProcComputePassEncoderRelease).optional.child).pointer.child;
pub fn computePassEncoderRelease(a0: @typeInfo(F_computePassEncoderRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePassEncoderRelease") {
    return bridge.invoke("computePassEncoderRelease", .{a0});
}
const F_computePipelineGetBindGroupLayout = @typeInfo(@typeInfo(c.WGPUProcComputePipelineGetBindGroupLayout).optional.child).pointer.child;
pub fn computePipelineGetBindGroupLayout(a0: @typeInfo(F_computePipelineGetBindGroupLayout).@"fn".params[0].type.?, a1: @typeInfo(F_computePipelineGetBindGroupLayout).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePipelineGetBindGroupLayout") {
    return bridge.invoke("computePipelineGetBindGroupLayout", .{a0, a1});
}
const F_computePipelineSetLabel = @typeInfo(@typeInfo(c.WGPUProcComputePipelineSetLabel).optional.child).pointer.child;
pub fn computePipelineSetLabel(a0: @typeInfo(F_computePipelineSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_computePipelineSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("computePipelineSetLabel") {
    return bridge.invoke("computePipelineSetLabel", .{a0, a1});
}
const F_computePipelineAddRef = @typeInfo(@typeInfo(c.WGPUProcComputePipelineAddRef).optional.child).pointer.child;
pub fn computePipelineAddRef(a0: @typeInfo(F_computePipelineAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePipelineAddRef") {
    return bridge.invoke("computePipelineAddRef", .{a0});
}
const F_computePipelineRelease = @typeInfo(@typeInfo(c.WGPUProcComputePipelineRelease).optional.child).pointer.child;
pub fn computePipelineRelease(a0: @typeInfo(F_computePipelineRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("computePipelineRelease") {
    return bridge.invoke("computePipelineRelease", .{a0});
}
const F_dawnDrmFormatCapabilitiesFreeMembers = @typeInfo(@typeInfo(c.WGPUProcDawnDrmFormatCapabilitiesFreeMembers).optional.child).pointer.child;
pub fn dawnDrmFormatCapabilitiesFreeMembers(a0: @typeInfo(F_dawnDrmFormatCapabilitiesFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("dawnDrmFormatCapabilitiesFreeMembers") {
    return bridge.invoke("dawnDrmFormatCapabilitiesFreeMembers", .{a0});
}
const F_deviceCreateBindGroup = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateBindGroup).optional.child).pointer.child;
pub fn deviceCreateBindGroup(a0: @typeInfo(F_deviceCreateBindGroup).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateBindGroup).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateBindGroup") {
    return bridge.invoke("deviceCreateBindGroup", .{a0, a1});
}
const F_deviceCreateBindGroupLayout = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateBindGroupLayout).optional.child).pointer.child;
pub fn deviceCreateBindGroupLayout(a0: @typeInfo(F_deviceCreateBindGroupLayout).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateBindGroupLayout).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateBindGroupLayout") {
    return bridge.invoke("deviceCreateBindGroupLayout", .{a0, a1});
}
const F_deviceCreateBuffer = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateBuffer).optional.child).pointer.child;
pub fn deviceCreateBuffer(a0: @typeInfo(F_deviceCreateBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateBuffer).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateBuffer") {
    return bridge.invoke("deviceCreateBuffer", .{a0, a1});
}
const F_deviceCreateCommandEncoder = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateCommandEncoder).optional.child).pointer.child;
pub fn deviceCreateCommandEncoder(a0: @typeInfo(F_deviceCreateCommandEncoder).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateCommandEncoder).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateCommandEncoder") {
    return bridge.invoke("deviceCreateCommandEncoder", .{a0, a1});
}
const F_deviceCreateComputePipeline = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateComputePipeline).optional.child).pointer.child;
pub fn deviceCreateComputePipeline(a0: @typeInfo(F_deviceCreateComputePipeline).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateComputePipeline).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateComputePipeline") {
    return bridge.invoke("deviceCreateComputePipeline", .{a0, a1});
}
const F_deviceCreateComputePipelineAsync = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateComputePipelineAsync).optional.child).pointer.child;
pub fn deviceCreateComputePipelineAsync(a0: @typeInfo(F_deviceCreateComputePipelineAsync).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateComputePipelineAsync).@"fn".params[1].type.?, a2: @typeInfo(F_deviceCreateComputePipelineAsync).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceCreateComputePipelineAsync") {
    return bridge.invoke("deviceCreateComputePipelineAsync", .{a0, a1, a2});
}
const F_deviceCreateErrorBuffer = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateErrorBuffer).optional.child).pointer.child;
pub fn deviceCreateErrorBuffer(a0: @typeInfo(F_deviceCreateErrorBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateErrorBuffer).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateErrorBuffer") {
    return bridge.invoke("deviceCreateErrorBuffer", .{a0, a1});
}
const F_deviceCreateErrorExternalTexture = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateErrorExternalTexture).optional.child).pointer.child;
pub fn deviceCreateErrorExternalTexture(a0: @typeInfo(F_deviceCreateErrorExternalTexture).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceCreateErrorExternalTexture") {
    return bridge.invoke("deviceCreateErrorExternalTexture", .{a0});
}
const F_deviceCreateErrorShaderModule = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateErrorShaderModule).optional.child).pointer.child;
pub fn deviceCreateErrorShaderModule(a0: @typeInfo(F_deviceCreateErrorShaderModule).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateErrorShaderModule).@"fn".params[1].type.?, a2: @typeInfo(F_deviceCreateErrorShaderModule).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceCreateErrorShaderModule") {
    return bridge.invoke("deviceCreateErrorShaderModule", .{a0, a1, a2});
}
const F_deviceCreateErrorTexture = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateErrorTexture).optional.child).pointer.child;
pub fn deviceCreateErrorTexture(a0: @typeInfo(F_deviceCreateErrorTexture).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateErrorTexture).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateErrorTexture") {
    return bridge.invoke("deviceCreateErrorTexture", .{a0, a1});
}
const F_deviceCreateExternalTexture = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateExternalTexture).optional.child).pointer.child;
pub fn deviceCreateExternalTexture(a0: @typeInfo(F_deviceCreateExternalTexture).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateExternalTexture).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateExternalTexture") {
    return bridge.invoke("deviceCreateExternalTexture", .{a0, a1});
}
const F_deviceCreatePipelineLayout = @typeInfo(@typeInfo(c.WGPUProcDeviceCreatePipelineLayout).optional.child).pointer.child;
pub fn deviceCreatePipelineLayout(a0: @typeInfo(F_deviceCreatePipelineLayout).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreatePipelineLayout).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreatePipelineLayout") {
    return bridge.invoke("deviceCreatePipelineLayout", .{a0, a1});
}
const F_deviceCreateQuerySet = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateQuerySet).optional.child).pointer.child;
pub fn deviceCreateQuerySet(a0: @typeInfo(F_deviceCreateQuerySet).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateQuerySet).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateQuerySet") {
    return bridge.invoke("deviceCreateQuerySet", .{a0, a1});
}
const F_deviceCreateRenderBundleEncoder = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateRenderBundleEncoder).optional.child).pointer.child;
pub fn deviceCreateRenderBundleEncoder(a0: @typeInfo(F_deviceCreateRenderBundleEncoder).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateRenderBundleEncoder).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateRenderBundleEncoder") {
    return bridge.invoke("deviceCreateRenderBundleEncoder", .{a0, a1});
}
const F_deviceCreateRenderPipeline = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateRenderPipeline).optional.child).pointer.child;
pub fn deviceCreateRenderPipeline(a0: @typeInfo(F_deviceCreateRenderPipeline).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateRenderPipeline).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateRenderPipeline") {
    return bridge.invoke("deviceCreateRenderPipeline", .{a0, a1});
}
const F_deviceCreateRenderPipelineAsync = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateRenderPipelineAsync).optional.child).pointer.child;
pub fn deviceCreateRenderPipelineAsync(a0: @typeInfo(F_deviceCreateRenderPipelineAsync).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateRenderPipelineAsync).@"fn".params[1].type.?, a2: @typeInfo(F_deviceCreateRenderPipelineAsync).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceCreateRenderPipelineAsync") {
    return bridge.invoke("deviceCreateRenderPipelineAsync", .{a0, a1, a2});
}
const F_deviceCreateResourceTable = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateResourceTable).optional.child).pointer.child;
pub fn deviceCreateResourceTable(a0: @typeInfo(F_deviceCreateResourceTable).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateResourceTable).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateResourceTable") {
    return bridge.invoke("deviceCreateResourceTable", .{a0, a1});
}
const F_deviceCreateSampler = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateSampler).optional.child).pointer.child;
pub fn deviceCreateSampler(a0: @typeInfo(F_deviceCreateSampler).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateSampler).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateSampler") {
    return bridge.invoke("deviceCreateSampler", .{a0, a1});
}
const F_deviceCreateShaderModule = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateShaderModule).optional.child).pointer.child;
pub fn deviceCreateShaderModule(a0: @typeInfo(F_deviceCreateShaderModule).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateShaderModule).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateShaderModule") {
    return bridge.invoke("deviceCreateShaderModule", .{a0, a1});
}
const F_deviceCreateTexture = @typeInfo(@typeInfo(c.WGPUProcDeviceCreateTexture).optional.child).pointer.child;
pub fn deviceCreateTexture(a0: @typeInfo(F_deviceCreateTexture).@"fn".params[0].type.?, a1: @typeInfo(F_deviceCreateTexture).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceCreateTexture") {
    return bridge.invoke("deviceCreateTexture", .{a0, a1});
}
const F_deviceDestroy = @typeInfo(@typeInfo(c.WGPUProcDeviceDestroy).optional.child).pointer.child;
pub fn deviceDestroy(a0: @typeInfo(F_deviceDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceDestroy") {
    return bridge.invoke("deviceDestroy", .{a0});
}
const F_deviceForceLoss = @typeInfo(@typeInfo(c.WGPUProcDeviceForceLoss).optional.child).pointer.child;
pub fn deviceForceLoss(a0: @typeInfo(F_deviceForceLoss).@"fn".params[0].type.?, a1: @typeInfo(F_deviceForceLoss).@"fn".params[1].type.?, a2: @typeInfo(F_deviceForceLoss).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceForceLoss") {
    return bridge.invoke("deviceForceLoss", .{a0, a1, a2});
}
const F_deviceGetAdapter = @typeInfo(@typeInfo(c.WGPUProcDeviceGetAdapter).optional.child).pointer.child;
pub fn deviceGetAdapter(a0: @typeInfo(F_deviceGetAdapter).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceGetAdapter") {
    return bridge.invoke("deviceGetAdapter", .{a0});
}
const F_deviceGetAdapterInfo = @typeInfo(@typeInfo(c.WGPUProcDeviceGetAdapterInfo).optional.child).pointer.child;
pub fn deviceGetAdapterInfo(a0: @typeInfo(F_deviceGetAdapterInfo).@"fn".params[0].type.?, a1: @typeInfo(F_deviceGetAdapterInfo).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceGetAdapterInfo") {
    return bridge.invoke("deviceGetAdapterInfo", .{a0, a1});
}
const F_deviceGetAHardwareBufferProperties = @typeInfo(@typeInfo(c.WGPUProcDeviceGetAHardwareBufferProperties).optional.child).pointer.child;
pub fn deviceGetAHardwareBufferProperties(a0: @typeInfo(F_deviceGetAHardwareBufferProperties).@"fn".params[0].type.?, a1: @typeInfo(F_deviceGetAHardwareBufferProperties).@"fn".params[1].type.?, a2: @typeInfo(F_deviceGetAHardwareBufferProperties).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceGetAHardwareBufferProperties") {
    return bridge.invoke("deviceGetAHardwareBufferProperties", .{a0, a1, a2});
}
const F_deviceGetFeatures = @typeInfo(@typeInfo(c.WGPUProcDeviceGetFeatures).optional.child).pointer.child;
pub fn deviceGetFeatures(a0: @typeInfo(F_deviceGetFeatures).@"fn".params[0].type.?, a1: @typeInfo(F_deviceGetFeatures).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceGetFeatures") {
    return bridge.invoke("deviceGetFeatures", .{a0, a1});
}
const F_deviceGetLimits = @typeInfo(@typeInfo(c.WGPUProcDeviceGetLimits).optional.child).pointer.child;
pub fn deviceGetLimits(a0: @typeInfo(F_deviceGetLimits).@"fn".params[0].type.?, a1: @typeInfo(F_deviceGetLimits).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceGetLimits") {
    return bridge.invoke("deviceGetLimits", .{a0, a1});
}
const F_deviceGetLostFuture = @typeInfo(@typeInfo(c.WGPUProcDeviceGetLostFuture).optional.child).pointer.child;
pub fn deviceGetLostFuture(a0: @typeInfo(F_deviceGetLostFuture).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceGetLostFuture") {
    return bridge.invoke("deviceGetLostFuture", .{a0});
}
const F_deviceGetQueue = @typeInfo(@typeInfo(c.WGPUProcDeviceGetQueue).optional.child).pointer.child;
pub fn deviceGetQueue(a0: @typeInfo(F_deviceGetQueue).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceGetQueue") {
    return bridge.invoke("deviceGetQueue", .{a0});
}
const F_deviceHasFeature = @typeInfo(@typeInfo(c.WGPUProcDeviceHasFeature).optional.child).pointer.child;
pub fn deviceHasFeature(a0: @typeInfo(F_deviceHasFeature).@"fn".params[0].type.?, a1: @typeInfo(F_deviceHasFeature).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceHasFeature") {
    return bridge.invoke("deviceHasFeature", .{a0, a1});
}
const F_deviceImportSharedBufferMemory = @typeInfo(@typeInfo(c.WGPUProcDeviceImportSharedBufferMemory).optional.child).pointer.child;
pub fn deviceImportSharedBufferMemory(a0: @typeInfo(F_deviceImportSharedBufferMemory).@"fn".params[0].type.?, a1: @typeInfo(F_deviceImportSharedBufferMemory).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceImportSharedBufferMemory") {
    return bridge.invoke("deviceImportSharedBufferMemory", .{a0, a1});
}
const F_deviceImportSharedFence = @typeInfo(@typeInfo(c.WGPUProcDeviceImportSharedFence).optional.child).pointer.child;
pub fn deviceImportSharedFence(a0: @typeInfo(F_deviceImportSharedFence).@"fn".params[0].type.?, a1: @typeInfo(F_deviceImportSharedFence).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceImportSharedFence") {
    return bridge.invoke("deviceImportSharedFence", .{a0, a1});
}
const F_deviceImportSharedTextureMemory = @typeInfo(@typeInfo(c.WGPUProcDeviceImportSharedTextureMemory).optional.child).pointer.child;
pub fn deviceImportSharedTextureMemory(a0: @typeInfo(F_deviceImportSharedTextureMemory).@"fn".params[0].type.?, a1: @typeInfo(F_deviceImportSharedTextureMemory).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceImportSharedTextureMemory") {
    return bridge.invoke("deviceImportSharedTextureMemory", .{a0, a1});
}
const F_deviceInjectError = @typeInfo(@typeInfo(c.WGPUProcDeviceInjectError).optional.child).pointer.child;
pub fn deviceInjectError(a0: @typeInfo(F_deviceInjectError).@"fn".params[0].type.?, a1: @typeInfo(F_deviceInjectError).@"fn".params[1].type.?, a2: @typeInfo(F_deviceInjectError).@"fn".params[2].type.?) callconv(.c) bridge.Return("deviceInjectError") {
    return bridge.invoke("deviceInjectError", .{a0, a1, a2});
}
const F_devicePopErrorScope = @typeInfo(@typeInfo(c.WGPUProcDevicePopErrorScope).optional.child).pointer.child;
pub fn devicePopErrorScope(a0: @typeInfo(F_devicePopErrorScope).@"fn".params[0].type.?, a1: @typeInfo(F_devicePopErrorScope).@"fn".params[1].type.?) callconv(.c) bridge.Return("devicePopErrorScope") {
    return bridge.invoke("devicePopErrorScope", .{a0, a1});
}
const F_devicePushErrorScope = @typeInfo(@typeInfo(c.WGPUProcDevicePushErrorScope).optional.child).pointer.child;
pub fn devicePushErrorScope(a0: @typeInfo(F_devicePushErrorScope).@"fn".params[0].type.?, a1: @typeInfo(F_devicePushErrorScope).@"fn".params[1].type.?) callconv(.c) bridge.Return("devicePushErrorScope") {
    return bridge.invoke("devicePushErrorScope", .{a0, a1});
}
const F_deviceSetLabel = @typeInfo(@typeInfo(c.WGPUProcDeviceSetLabel).optional.child).pointer.child;
pub fn deviceSetLabel(a0: @typeInfo(F_deviceSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_deviceSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceSetLabel") {
    return bridge.invoke("deviceSetLabel", .{a0, a1});
}
const F_deviceSetLoggingCallback = @typeInfo(@typeInfo(c.WGPUProcDeviceSetLoggingCallback).optional.child).pointer.child;
pub fn deviceSetLoggingCallback(a0: @typeInfo(F_deviceSetLoggingCallback).@"fn".params[0].type.?, a1: @typeInfo(F_deviceSetLoggingCallback).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceSetLoggingCallback") {
    return bridge.invoke("deviceSetLoggingCallback", .{a0, a1});
}
const F_deviceTick = @typeInfo(@typeInfo(c.WGPUProcDeviceTick).optional.child).pointer.child;
pub fn deviceTick(a0: @typeInfo(F_deviceTick).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceTick") {
    return bridge.invoke("deviceTick", .{a0});
}
const F_deviceValidateTextureDescriptor = @typeInfo(@typeInfo(c.WGPUProcDeviceValidateTextureDescriptor).optional.child).pointer.child;
pub fn deviceValidateTextureDescriptor(a0: @typeInfo(F_deviceValidateTextureDescriptor).@"fn".params[0].type.?, a1: @typeInfo(F_deviceValidateTextureDescriptor).@"fn".params[1].type.?) callconv(.c) bridge.Return("deviceValidateTextureDescriptor") {
    return bridge.invoke("deviceValidateTextureDescriptor", .{a0, a1});
}
const F_deviceAddRef = @typeInfo(@typeInfo(c.WGPUProcDeviceAddRef).optional.child).pointer.child;
pub fn deviceAddRef(a0: @typeInfo(F_deviceAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceAddRef") {
    return bridge.invoke("deviceAddRef", .{a0});
}
const F_deviceRelease = @typeInfo(@typeInfo(c.WGPUProcDeviceRelease).optional.child).pointer.child;
pub fn deviceRelease(a0: @typeInfo(F_deviceRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("deviceRelease") {
    return bridge.invoke("deviceRelease", .{a0});
}
const F_externalTextureDestroy = @typeInfo(@typeInfo(c.WGPUProcExternalTextureDestroy).optional.child).pointer.child;
pub fn externalTextureDestroy(a0: @typeInfo(F_externalTextureDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("externalTextureDestroy") {
    return bridge.invoke("externalTextureDestroy", .{a0});
}
const F_externalTextureExpire = @typeInfo(@typeInfo(c.WGPUProcExternalTextureExpire).optional.child).pointer.child;
pub fn externalTextureExpire(a0: @typeInfo(F_externalTextureExpire).@"fn".params[0].type.?) callconv(.c) bridge.Return("externalTextureExpire") {
    return bridge.invoke("externalTextureExpire", .{a0});
}
const F_externalTextureRefresh = @typeInfo(@typeInfo(c.WGPUProcExternalTextureRefresh).optional.child).pointer.child;
pub fn externalTextureRefresh(a0: @typeInfo(F_externalTextureRefresh).@"fn".params[0].type.?) callconv(.c) bridge.Return("externalTextureRefresh") {
    return bridge.invoke("externalTextureRefresh", .{a0});
}
const F_externalTextureSetLabel = @typeInfo(@typeInfo(c.WGPUProcExternalTextureSetLabel).optional.child).pointer.child;
pub fn externalTextureSetLabel(a0: @typeInfo(F_externalTextureSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_externalTextureSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("externalTextureSetLabel") {
    return bridge.invoke("externalTextureSetLabel", .{a0, a1});
}
const F_externalTextureAddRef = @typeInfo(@typeInfo(c.WGPUProcExternalTextureAddRef).optional.child).pointer.child;
pub fn externalTextureAddRef(a0: @typeInfo(F_externalTextureAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("externalTextureAddRef") {
    return bridge.invoke("externalTextureAddRef", .{a0});
}
const F_externalTextureRelease = @typeInfo(@typeInfo(c.WGPUProcExternalTextureRelease).optional.child).pointer.child;
pub fn externalTextureRelease(a0: @typeInfo(F_externalTextureRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("externalTextureRelease") {
    return bridge.invoke("externalTextureRelease", .{a0});
}
const F_instanceCreateSurface = @typeInfo(@typeInfo(c.WGPUProcInstanceCreateSurface).optional.child).pointer.child;
pub fn instanceCreateSurface(a0: @typeInfo(F_instanceCreateSurface).@"fn".params[0].type.?, a1: @typeInfo(F_instanceCreateSurface).@"fn".params[1].type.?) callconv(.c) bridge.Return("instanceCreateSurface") {
    return bridge.invoke("instanceCreateSurface", .{a0, a1});
}
const F_instanceGetWGSLLanguageFeatures = @typeInfo(@typeInfo(c.WGPUProcInstanceGetWGSLLanguageFeatures).optional.child).pointer.child;
pub fn instanceGetWGSLLanguageFeatures(a0: @typeInfo(F_instanceGetWGSLLanguageFeatures).@"fn".params[0].type.?, a1: @typeInfo(F_instanceGetWGSLLanguageFeatures).@"fn".params[1].type.?) callconv(.c) bridge.Return("instanceGetWGSLLanguageFeatures") {
    return bridge.invoke("instanceGetWGSLLanguageFeatures", .{a0, a1});
}
const F_instanceHasWGSLLanguageFeature = @typeInfo(@typeInfo(c.WGPUProcInstanceHasWGSLLanguageFeature).optional.child).pointer.child;
pub fn instanceHasWGSLLanguageFeature(a0: @typeInfo(F_instanceHasWGSLLanguageFeature).@"fn".params[0].type.?, a1: @typeInfo(F_instanceHasWGSLLanguageFeature).@"fn".params[1].type.?) callconv(.c) bridge.Return("instanceHasWGSLLanguageFeature") {
    return bridge.invoke("instanceHasWGSLLanguageFeature", .{a0, a1});
}
const F_instanceProcessEvents = @typeInfo(@typeInfo(c.WGPUProcInstanceProcessEvents).optional.child).pointer.child;
pub fn instanceProcessEvents(a0: @typeInfo(F_instanceProcessEvents).@"fn".params[0].type.?) callconv(.c) bridge.Return("instanceProcessEvents") {
    return bridge.invoke("instanceProcessEvents", .{a0});
}
const F_instanceRequestAdapter = @typeInfo(@typeInfo(c.WGPUProcInstanceRequestAdapter).optional.child).pointer.child;
pub fn instanceRequestAdapter(a0: @typeInfo(F_instanceRequestAdapter).@"fn".params[0].type.?, a1: @typeInfo(F_instanceRequestAdapter).@"fn".params[1].type.?, a2: @typeInfo(F_instanceRequestAdapter).@"fn".params[2].type.?) callconv(.c) bridge.Return("instanceRequestAdapter") {
    return bridge.invoke("instanceRequestAdapter", .{a0, a1, a2});
}
const F_instanceWaitAny = @typeInfo(@typeInfo(c.WGPUProcInstanceWaitAny).optional.child).pointer.child;
pub fn instanceWaitAny(a0: @typeInfo(F_instanceWaitAny).@"fn".params[0].type.?, a1: @typeInfo(F_instanceWaitAny).@"fn".params[1].type.?, a2: @typeInfo(F_instanceWaitAny).@"fn".params[2].type.?, a3: @typeInfo(F_instanceWaitAny).@"fn".params[3].type.?) callconv(.c) bridge.Return("instanceWaitAny") {
    return bridge.invoke("instanceWaitAny", .{a0, a1, a2, a3});
}
const F_instanceAddRef = @typeInfo(@typeInfo(c.WGPUProcInstanceAddRef).optional.child).pointer.child;
pub fn instanceAddRef(a0: @typeInfo(F_instanceAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("instanceAddRef") {
    return bridge.invoke("instanceAddRef", .{a0});
}
const F_instanceRelease = @typeInfo(@typeInfo(c.WGPUProcInstanceRelease).optional.child).pointer.child;
pub fn instanceRelease(a0: @typeInfo(F_instanceRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("instanceRelease") {
    return bridge.invoke("instanceRelease", .{a0});
}
const F_pipelineLayoutSetLabel = @typeInfo(@typeInfo(c.WGPUProcPipelineLayoutSetLabel).optional.child).pointer.child;
pub fn pipelineLayoutSetLabel(a0: @typeInfo(F_pipelineLayoutSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_pipelineLayoutSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("pipelineLayoutSetLabel") {
    return bridge.invoke("pipelineLayoutSetLabel", .{a0, a1});
}
const F_pipelineLayoutAddRef = @typeInfo(@typeInfo(c.WGPUProcPipelineLayoutAddRef).optional.child).pointer.child;
pub fn pipelineLayoutAddRef(a0: @typeInfo(F_pipelineLayoutAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("pipelineLayoutAddRef") {
    return bridge.invoke("pipelineLayoutAddRef", .{a0});
}
const F_pipelineLayoutRelease = @typeInfo(@typeInfo(c.WGPUProcPipelineLayoutRelease).optional.child).pointer.child;
pub fn pipelineLayoutRelease(a0: @typeInfo(F_pipelineLayoutRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("pipelineLayoutRelease") {
    return bridge.invoke("pipelineLayoutRelease", .{a0});
}
const F_querySetDestroy = @typeInfo(@typeInfo(c.WGPUProcQuerySetDestroy).optional.child).pointer.child;
pub fn querySetDestroy(a0: @typeInfo(F_querySetDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("querySetDestroy") {
    return bridge.invoke("querySetDestroy", .{a0});
}
const F_querySetGetCount = @typeInfo(@typeInfo(c.WGPUProcQuerySetGetCount).optional.child).pointer.child;
pub fn querySetGetCount(a0: @typeInfo(F_querySetGetCount).@"fn".params[0].type.?) callconv(.c) bridge.Return("querySetGetCount") {
    return bridge.invoke("querySetGetCount", .{a0});
}
const F_querySetGetType = @typeInfo(@typeInfo(c.WGPUProcQuerySetGetType).optional.child).pointer.child;
pub fn querySetGetType(a0: @typeInfo(F_querySetGetType).@"fn".params[0].type.?) callconv(.c) bridge.Return("querySetGetType") {
    return bridge.invoke("querySetGetType", .{a0});
}
const F_querySetSetLabel = @typeInfo(@typeInfo(c.WGPUProcQuerySetSetLabel).optional.child).pointer.child;
pub fn querySetSetLabel(a0: @typeInfo(F_querySetSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_querySetSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("querySetSetLabel") {
    return bridge.invoke("querySetSetLabel", .{a0, a1});
}
const F_querySetAddRef = @typeInfo(@typeInfo(c.WGPUProcQuerySetAddRef).optional.child).pointer.child;
pub fn querySetAddRef(a0: @typeInfo(F_querySetAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("querySetAddRef") {
    return bridge.invoke("querySetAddRef", .{a0});
}
const F_querySetRelease = @typeInfo(@typeInfo(c.WGPUProcQuerySetRelease).optional.child).pointer.child;
pub fn querySetRelease(a0: @typeInfo(F_querySetRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("querySetRelease") {
    return bridge.invoke("querySetRelease", .{a0});
}
const F_queueCopyExternalTextureForBrowser = @typeInfo(@typeInfo(c.WGPUProcQueueCopyExternalTextureForBrowser).optional.child).pointer.child;
pub fn queueCopyExternalTextureForBrowser(a0: @typeInfo(F_queueCopyExternalTextureForBrowser).@"fn".params[0].type.?, a1: @typeInfo(F_queueCopyExternalTextureForBrowser).@"fn".params[1].type.?, a2: @typeInfo(F_queueCopyExternalTextureForBrowser).@"fn".params[2].type.?, a3: @typeInfo(F_queueCopyExternalTextureForBrowser).@"fn".params[3].type.?, a4: @typeInfo(F_queueCopyExternalTextureForBrowser).@"fn".params[4].type.?) callconv(.c) bridge.Return("queueCopyExternalTextureForBrowser") {
    return bridge.invoke("queueCopyExternalTextureForBrowser", .{a0, a1, a2, a3, a4});
}
const F_queueCopyTextureForBrowser = @typeInfo(@typeInfo(c.WGPUProcQueueCopyTextureForBrowser).optional.child).pointer.child;
pub fn queueCopyTextureForBrowser(a0: @typeInfo(F_queueCopyTextureForBrowser).@"fn".params[0].type.?, a1: @typeInfo(F_queueCopyTextureForBrowser).@"fn".params[1].type.?, a2: @typeInfo(F_queueCopyTextureForBrowser).@"fn".params[2].type.?, a3: @typeInfo(F_queueCopyTextureForBrowser).@"fn".params[3].type.?, a4: @typeInfo(F_queueCopyTextureForBrowser).@"fn".params[4].type.?) callconv(.c) bridge.Return("queueCopyTextureForBrowser") {
    return bridge.invoke("queueCopyTextureForBrowser", .{a0, a1, a2, a3, a4});
}
const F_queueOnSubmittedWorkDone = @typeInfo(@typeInfo(c.WGPUProcQueueOnSubmittedWorkDone).optional.child).pointer.child;
pub fn queueOnSubmittedWorkDone(a0: @typeInfo(F_queueOnSubmittedWorkDone).@"fn".params[0].type.?, a1: @typeInfo(F_queueOnSubmittedWorkDone).@"fn".params[1].type.?) callconv(.c) bridge.Return("queueOnSubmittedWorkDone") {
    return bridge.invoke("queueOnSubmittedWorkDone", .{a0, a1});
}
const F_queueSetLabel = @typeInfo(@typeInfo(c.WGPUProcQueueSetLabel).optional.child).pointer.child;
pub fn queueSetLabel(a0: @typeInfo(F_queueSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_queueSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("queueSetLabel") {
    return bridge.invoke("queueSetLabel", .{a0, a1});
}
const F_queueSubmit = @typeInfo(@typeInfo(c.WGPUProcQueueSubmit).optional.child).pointer.child;
pub fn queueSubmit(a0: @typeInfo(F_queueSubmit).@"fn".params[0].type.?, a1: @typeInfo(F_queueSubmit).@"fn".params[1].type.?, a2: @typeInfo(F_queueSubmit).@"fn".params[2].type.?) callconv(.c) bridge.Return("queueSubmit") {
    return bridge.invoke("queueSubmit", .{a0, a1, a2});
}
const F_queueWriteBuffer = @typeInfo(@typeInfo(c.WGPUProcQueueWriteBuffer).optional.child).pointer.child;
pub fn queueWriteBuffer(a0: @typeInfo(F_queueWriteBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_queueWriteBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_queueWriteBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_queueWriteBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_queueWriteBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("queueWriteBuffer") {
    return bridge.invoke("queueWriteBuffer", .{a0, a1, a2, a3, a4});
}
const F_queueWriteTexture = @typeInfo(@typeInfo(c.WGPUProcQueueWriteTexture).optional.child).pointer.child;
pub fn queueWriteTexture(a0: @typeInfo(F_queueWriteTexture).@"fn".params[0].type.?, a1: @typeInfo(F_queueWriteTexture).@"fn".params[1].type.?, a2: @typeInfo(F_queueWriteTexture).@"fn".params[2].type.?, a3: @typeInfo(F_queueWriteTexture).@"fn".params[3].type.?, a4: @typeInfo(F_queueWriteTexture).@"fn".params[4].type.?, a5: @typeInfo(F_queueWriteTexture).@"fn".params[5].type.?) callconv(.c) bridge.Return("queueWriteTexture") {
    return bridge.invoke("queueWriteTexture", .{a0, a1, a2, a3, a4, a5});
}
const F_queueAddRef = @typeInfo(@typeInfo(c.WGPUProcQueueAddRef).optional.child).pointer.child;
pub fn queueAddRef(a0: @typeInfo(F_queueAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("queueAddRef") {
    return bridge.invoke("queueAddRef", .{a0});
}
const F_queueRelease = @typeInfo(@typeInfo(c.WGPUProcQueueRelease).optional.child).pointer.child;
pub fn queueRelease(a0: @typeInfo(F_queueRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("queueRelease") {
    return bridge.invoke("queueRelease", .{a0});
}
const F_renderBundleSetLabel = @typeInfo(@typeInfo(c.WGPUProcRenderBundleSetLabel).optional.child).pointer.child;
pub fn renderBundleSetLabel(a0: @typeInfo(F_renderBundleSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleSetLabel") {
    return bridge.invoke("renderBundleSetLabel", .{a0, a1});
}
const F_renderBundleAddRef = @typeInfo(@typeInfo(c.WGPUProcRenderBundleAddRef).optional.child).pointer.child;
pub fn renderBundleAddRef(a0: @typeInfo(F_renderBundleAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderBundleAddRef") {
    return bridge.invoke("renderBundleAddRef", .{a0});
}
const F_renderBundleRelease = @typeInfo(@typeInfo(c.WGPUProcRenderBundleRelease).optional.child).pointer.child;
pub fn renderBundleRelease(a0: @typeInfo(F_renderBundleRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderBundleRelease") {
    return bridge.invoke("renderBundleRelease", .{a0});
}
const F_renderBundleEncoderDraw = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderDraw).optional.child).pointer.child;
pub fn renderBundleEncoderDraw(a0: @typeInfo(F_renderBundleEncoderDraw).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderDraw).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderDraw).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderDraw).@"fn".params[3].type.?, a4: @typeInfo(F_renderBundleEncoderDraw).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderBundleEncoderDraw") {
    return bridge.invoke("renderBundleEncoderDraw", .{a0, a1, a2, a3, a4});
}
const F_renderBundleEncoderDrawIndexed = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderDrawIndexed).optional.child).pointer.child;
pub fn renderBundleEncoderDrawIndexed(a0: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[3].type.?, a4: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[4].type.?, a5: @typeInfo(F_renderBundleEncoderDrawIndexed).@"fn".params[5].type.?) callconv(.c) bridge.Return("renderBundleEncoderDrawIndexed") {
    return bridge.invoke("renderBundleEncoderDrawIndexed", .{a0, a1, a2, a3, a4, a5});
}
const F_renderBundleEncoderDrawIndexedIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderDrawIndexedIndirect).optional.child).pointer.child;
pub fn renderBundleEncoderDrawIndexedIndirect(a0: @typeInfo(F_renderBundleEncoderDrawIndexedIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderDrawIndexedIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderDrawIndexedIndirect).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderBundleEncoderDrawIndexedIndirect") {
    return bridge.invoke("renderBundleEncoderDrawIndexedIndirect", .{a0, a1, a2});
}
const F_renderBundleEncoderDrawIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderDrawIndirect).optional.child).pointer.child;
pub fn renderBundleEncoderDrawIndirect(a0: @typeInfo(F_renderBundleEncoderDrawIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderDrawIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderDrawIndirect).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderBundleEncoderDrawIndirect") {
    return bridge.invoke("renderBundleEncoderDrawIndirect", .{a0, a1, a2});
}
const F_renderBundleEncoderFinish = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderFinish).optional.child).pointer.child;
pub fn renderBundleEncoderFinish(a0: @typeInfo(F_renderBundleEncoderFinish).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderFinish).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleEncoderFinish") {
    return bridge.invoke("renderBundleEncoderFinish", .{a0, a1});
}
const F_renderBundleEncoderInsertDebugMarker = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderInsertDebugMarker).optional.child).pointer.child;
pub fn renderBundleEncoderInsertDebugMarker(a0: @typeInfo(F_renderBundleEncoderInsertDebugMarker).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderInsertDebugMarker).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleEncoderInsertDebugMarker") {
    return bridge.invoke("renderBundleEncoderInsertDebugMarker", .{a0, a1});
}
const F_renderBundleEncoderPopDebugGroup = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderPopDebugGroup).optional.child).pointer.child;
pub fn renderBundleEncoderPopDebugGroup(a0: @typeInfo(F_renderBundleEncoderPopDebugGroup).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderBundleEncoderPopDebugGroup") {
    return bridge.invoke("renderBundleEncoderPopDebugGroup", .{a0});
}
const F_renderBundleEncoderPushDebugGroup = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderPushDebugGroup).optional.child).pointer.child;
pub fn renderBundleEncoderPushDebugGroup(a0: @typeInfo(F_renderBundleEncoderPushDebugGroup).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderPushDebugGroup).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleEncoderPushDebugGroup") {
    return bridge.invoke("renderBundleEncoderPushDebugGroup", .{a0, a1});
}
const F_renderBundleEncoderSetBindGroup = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetBindGroup).optional.child).pointer.child;
pub fn renderBundleEncoderSetBindGroup(a0: @typeInfo(F_renderBundleEncoderSetBindGroup).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetBindGroup).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderSetBindGroup).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderSetBindGroup).@"fn".params[3].type.?, a4: @typeInfo(F_renderBundleEncoderSetBindGroup).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetBindGroup") {
    return bridge.invoke("renderBundleEncoderSetBindGroup", .{a0, a1, a2, a3, a4});
}
const F_renderBundleEncoderSetImmediates = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetImmediates).optional.child).pointer.child;
pub fn renderBundleEncoderSetImmediates(a0: @typeInfo(F_renderBundleEncoderSetImmediates).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetImmediates).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderSetImmediates).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderSetImmediates).@"fn".params[3].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetImmediates") {
    return bridge.invoke("renderBundleEncoderSetImmediates", .{a0, a1, a2, a3});
}
const F_renderBundleEncoderSetIndexBuffer = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetIndexBuffer).optional.child).pointer.child;
pub fn renderBundleEncoderSetIndexBuffer(a0: @typeInfo(F_renderBundleEncoderSetIndexBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetIndexBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderSetIndexBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderSetIndexBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_renderBundleEncoderSetIndexBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetIndexBuffer") {
    return bridge.invoke("renderBundleEncoderSetIndexBuffer", .{a0, a1, a2, a3, a4});
}
const F_renderBundleEncoderSetLabel = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetLabel).optional.child).pointer.child;
pub fn renderBundleEncoderSetLabel(a0: @typeInfo(F_renderBundleEncoderSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetLabel") {
    return bridge.invoke("renderBundleEncoderSetLabel", .{a0, a1});
}
const F_renderBundleEncoderSetPipeline = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetPipeline).optional.child).pointer.child;
pub fn renderBundleEncoderSetPipeline(a0: @typeInfo(F_renderBundleEncoderSetPipeline).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetPipeline).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetPipeline") {
    return bridge.invoke("renderBundleEncoderSetPipeline", .{a0, a1});
}
const F_renderBundleEncoderSetVertexBuffer = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderSetVertexBuffer).optional.child).pointer.child;
pub fn renderBundleEncoderSetVertexBuffer(a0: @typeInfo(F_renderBundleEncoderSetVertexBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_renderBundleEncoderSetVertexBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_renderBundleEncoderSetVertexBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_renderBundleEncoderSetVertexBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_renderBundleEncoderSetVertexBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderBundleEncoderSetVertexBuffer") {
    return bridge.invoke("renderBundleEncoderSetVertexBuffer", .{a0, a1, a2, a3, a4});
}
const F_renderBundleEncoderAddRef = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderAddRef).optional.child).pointer.child;
pub fn renderBundleEncoderAddRef(a0: @typeInfo(F_renderBundleEncoderAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderBundleEncoderAddRef") {
    return bridge.invoke("renderBundleEncoderAddRef", .{a0});
}
const F_renderBundleEncoderRelease = @typeInfo(@typeInfo(c.WGPUProcRenderBundleEncoderRelease).optional.child).pointer.child;
pub fn renderBundleEncoderRelease(a0: @typeInfo(F_renderBundleEncoderRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderBundleEncoderRelease") {
    return bridge.invoke("renderBundleEncoderRelease", .{a0});
}
const F_renderPassEncoderBeginOcclusionQuery = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderBeginOcclusionQuery).optional.child).pointer.child;
pub fn renderPassEncoderBeginOcclusionQuery(a0: @typeInfo(F_renderPassEncoderBeginOcclusionQuery).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderBeginOcclusionQuery).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderBeginOcclusionQuery") {
    return bridge.invoke("renderPassEncoderBeginOcclusionQuery", .{a0, a1});
}
const F_renderPassEncoderDraw = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderDraw).optional.child).pointer.child;
pub fn renderPassEncoderDraw(a0: @typeInfo(F_renderPassEncoderDraw).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderDraw).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderDraw).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderDraw).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderDraw).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderPassEncoderDraw") {
    return bridge.invoke("renderPassEncoderDraw", .{a0, a1, a2, a3, a4});
}
const F_renderPassEncoderDrawIndexed = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderDrawIndexed).optional.child).pointer.child;
pub fn renderPassEncoderDrawIndexed(a0: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[4].type.?, a5: @typeInfo(F_renderPassEncoderDrawIndexed).@"fn".params[5].type.?) callconv(.c) bridge.Return("renderPassEncoderDrawIndexed") {
    return bridge.invoke("renderPassEncoderDrawIndexed", .{a0, a1, a2, a3, a4, a5});
}
const F_renderPassEncoderDrawIndexedIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderDrawIndexedIndirect).optional.child).pointer.child;
pub fn renderPassEncoderDrawIndexedIndirect(a0: @typeInfo(F_renderPassEncoderDrawIndexedIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderDrawIndexedIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderDrawIndexedIndirect).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderPassEncoderDrawIndexedIndirect") {
    return bridge.invoke("renderPassEncoderDrawIndexedIndirect", .{a0, a1, a2});
}
const F_renderPassEncoderDrawIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderDrawIndirect).optional.child).pointer.child;
pub fn renderPassEncoderDrawIndirect(a0: @typeInfo(F_renderPassEncoderDrawIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderDrawIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderDrawIndirect).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderPassEncoderDrawIndirect") {
    return bridge.invoke("renderPassEncoderDrawIndirect", .{a0, a1, a2});
}
const F_renderPassEncoderEnd = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderEnd).optional.child).pointer.child;
pub fn renderPassEncoderEnd(a0: @typeInfo(F_renderPassEncoderEnd).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderEnd") {
    return bridge.invoke("renderPassEncoderEnd", .{a0});
}
const F_renderPassEncoderEndOcclusionQuery = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderEndOcclusionQuery).optional.child).pointer.child;
pub fn renderPassEncoderEndOcclusionQuery(a0: @typeInfo(F_renderPassEncoderEndOcclusionQuery).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderEndOcclusionQuery") {
    return bridge.invoke("renderPassEncoderEndOcclusionQuery", .{a0});
}
const F_renderPassEncoderExecuteBundles = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderExecuteBundles).optional.child).pointer.child;
pub fn renderPassEncoderExecuteBundles(a0: @typeInfo(F_renderPassEncoderExecuteBundles).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderExecuteBundles).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderExecuteBundles).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderPassEncoderExecuteBundles") {
    return bridge.invoke("renderPassEncoderExecuteBundles", .{a0, a1, a2});
}
const F_renderPassEncoderInsertDebugMarker = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderInsertDebugMarker).optional.child).pointer.child;
pub fn renderPassEncoderInsertDebugMarker(a0: @typeInfo(F_renderPassEncoderInsertDebugMarker).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderInsertDebugMarker).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderInsertDebugMarker") {
    return bridge.invoke("renderPassEncoderInsertDebugMarker", .{a0, a1});
}
const F_renderPassEncoderMultiDrawIndexedIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderMultiDrawIndexedIndirect).optional.child).pointer.child;
pub fn renderPassEncoderMultiDrawIndexedIndirect(a0: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[4].type.?, a5: @typeInfo(F_renderPassEncoderMultiDrawIndexedIndirect).@"fn".params[5].type.?) callconv(.c) bridge.Return("renderPassEncoderMultiDrawIndexedIndirect") {
    return bridge.invoke("renderPassEncoderMultiDrawIndexedIndirect", .{a0, a1, a2, a3, a4, a5});
}
const F_renderPassEncoderMultiDrawIndirect = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderMultiDrawIndirect).optional.child).pointer.child;
pub fn renderPassEncoderMultiDrawIndirect(a0: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[4].type.?, a5: @typeInfo(F_renderPassEncoderMultiDrawIndirect).@"fn".params[5].type.?) callconv(.c) bridge.Return("renderPassEncoderMultiDrawIndirect") {
    return bridge.invoke("renderPassEncoderMultiDrawIndirect", .{a0, a1, a2, a3, a4, a5});
}
const F_renderPassEncoderPixelLocalStorageBarrier = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderPixelLocalStorageBarrier).optional.child).pointer.child;
pub fn renderPassEncoderPixelLocalStorageBarrier(a0: @typeInfo(F_renderPassEncoderPixelLocalStorageBarrier).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderPixelLocalStorageBarrier") {
    return bridge.invoke("renderPassEncoderPixelLocalStorageBarrier", .{a0});
}
const F_renderPassEncoderPopDebugGroup = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderPopDebugGroup).optional.child).pointer.child;
pub fn renderPassEncoderPopDebugGroup(a0: @typeInfo(F_renderPassEncoderPopDebugGroup).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderPopDebugGroup") {
    return bridge.invoke("renderPassEncoderPopDebugGroup", .{a0});
}
const F_renderPassEncoderPushDebugGroup = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderPushDebugGroup).optional.child).pointer.child;
pub fn renderPassEncoderPushDebugGroup(a0: @typeInfo(F_renderPassEncoderPushDebugGroup).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderPushDebugGroup).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderPushDebugGroup") {
    return bridge.invoke("renderPassEncoderPushDebugGroup", .{a0, a1});
}
const F_renderPassEncoderSetBindGroup = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetBindGroup).optional.child).pointer.child;
pub fn renderPassEncoderSetBindGroup(a0: @typeInfo(F_renderPassEncoderSetBindGroup).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetBindGroup).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetBindGroup).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetBindGroup).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderSetBindGroup).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderPassEncoderSetBindGroup") {
    return bridge.invoke("renderPassEncoderSetBindGroup", .{a0, a1, a2, a3, a4});
}
const F_renderPassEncoderSetBlendConstant = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetBlendConstant).optional.child).pointer.child;
pub fn renderPassEncoderSetBlendConstant(a0: @typeInfo(F_renderPassEncoderSetBlendConstant).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetBlendConstant).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderSetBlendConstant") {
    return bridge.invoke("renderPassEncoderSetBlendConstant", .{a0, a1});
}
const F_renderPassEncoderSetImmediates = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetImmediates).optional.child).pointer.child;
pub fn renderPassEncoderSetImmediates(a0: @typeInfo(F_renderPassEncoderSetImmediates).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetImmediates).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetImmediates).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetImmediates).@"fn".params[3].type.?) callconv(.c) bridge.Return("renderPassEncoderSetImmediates") {
    return bridge.invoke("renderPassEncoderSetImmediates", .{a0, a1, a2, a3});
}
const F_renderPassEncoderSetIndexBuffer = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetIndexBuffer).optional.child).pointer.child;
pub fn renderPassEncoderSetIndexBuffer(a0: @typeInfo(F_renderPassEncoderSetIndexBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetIndexBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetIndexBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetIndexBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderSetIndexBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderPassEncoderSetIndexBuffer") {
    return bridge.invoke("renderPassEncoderSetIndexBuffer", .{a0, a1, a2, a3, a4});
}
const F_renderPassEncoderSetLabel = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetLabel).optional.child).pointer.child;
pub fn renderPassEncoderSetLabel(a0: @typeInfo(F_renderPassEncoderSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderSetLabel") {
    return bridge.invoke("renderPassEncoderSetLabel", .{a0, a1});
}
const F_renderPassEncoderSetPipeline = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetPipeline).optional.child).pointer.child;
pub fn renderPassEncoderSetPipeline(a0: @typeInfo(F_renderPassEncoderSetPipeline).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetPipeline).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderSetPipeline") {
    return bridge.invoke("renderPassEncoderSetPipeline", .{a0, a1});
}
const F_renderPassEncoderSetScissorRect = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetScissorRect).optional.child).pointer.child;
pub fn renderPassEncoderSetScissorRect(a0: @typeInfo(F_renderPassEncoderSetScissorRect).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetScissorRect).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetScissorRect).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetScissorRect).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderSetScissorRect).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderPassEncoderSetScissorRect") {
    return bridge.invoke("renderPassEncoderSetScissorRect", .{a0, a1, a2, a3, a4});
}
const F_renderPassEncoderSetStencilReference = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetStencilReference).optional.child).pointer.child;
pub fn renderPassEncoderSetStencilReference(a0: @typeInfo(F_renderPassEncoderSetStencilReference).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetStencilReference).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPassEncoderSetStencilReference") {
    return bridge.invoke("renderPassEncoderSetStencilReference", .{a0, a1});
}
const F_renderPassEncoderSetVertexBuffer = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetVertexBuffer).optional.child).pointer.child;
pub fn renderPassEncoderSetVertexBuffer(a0: @typeInfo(F_renderPassEncoderSetVertexBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetVertexBuffer).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetVertexBuffer).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetVertexBuffer).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderSetVertexBuffer).@"fn".params[4].type.?) callconv(.c) bridge.Return("renderPassEncoderSetVertexBuffer") {
    return bridge.invoke("renderPassEncoderSetVertexBuffer", .{a0, a1, a2, a3, a4});
}
const F_renderPassEncoderSetViewport = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderSetViewport).optional.child).pointer.child;
pub fn renderPassEncoderSetViewport(a0: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[2].type.?, a3: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[3].type.?, a4: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[4].type.?, a5: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[5].type.?, a6: @typeInfo(F_renderPassEncoderSetViewport).@"fn".params[6].type.?) callconv(.c) bridge.Return("renderPassEncoderSetViewport") {
    return bridge.invoke("renderPassEncoderSetViewport", .{a0, a1, a2, a3, a4, a5, a6});
}
const F_renderPassEncoderWriteTimestamp = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderWriteTimestamp).optional.child).pointer.child;
pub fn renderPassEncoderWriteTimestamp(a0: @typeInfo(F_renderPassEncoderWriteTimestamp).@"fn".params[0].type.?, a1: @typeInfo(F_renderPassEncoderWriteTimestamp).@"fn".params[1].type.?, a2: @typeInfo(F_renderPassEncoderWriteTimestamp).@"fn".params[2].type.?) callconv(.c) bridge.Return("renderPassEncoderWriteTimestamp") {
    return bridge.invoke("renderPassEncoderWriteTimestamp", .{a0, a1, a2});
}
const F_renderPassEncoderAddRef = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderAddRef).optional.child).pointer.child;
pub fn renderPassEncoderAddRef(a0: @typeInfo(F_renderPassEncoderAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderAddRef") {
    return bridge.invoke("renderPassEncoderAddRef", .{a0});
}
const F_renderPassEncoderRelease = @typeInfo(@typeInfo(c.WGPUProcRenderPassEncoderRelease).optional.child).pointer.child;
pub fn renderPassEncoderRelease(a0: @typeInfo(F_renderPassEncoderRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPassEncoderRelease") {
    return bridge.invoke("renderPassEncoderRelease", .{a0});
}
const F_renderPipelineGetBindGroupLayout = @typeInfo(@typeInfo(c.WGPUProcRenderPipelineGetBindGroupLayout).optional.child).pointer.child;
pub fn renderPipelineGetBindGroupLayout(a0: @typeInfo(F_renderPipelineGetBindGroupLayout).@"fn".params[0].type.?, a1: @typeInfo(F_renderPipelineGetBindGroupLayout).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPipelineGetBindGroupLayout") {
    return bridge.invoke("renderPipelineGetBindGroupLayout", .{a0, a1});
}
const F_renderPipelineSetLabel = @typeInfo(@typeInfo(c.WGPUProcRenderPipelineSetLabel).optional.child).pointer.child;
pub fn renderPipelineSetLabel(a0: @typeInfo(F_renderPipelineSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_renderPipelineSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("renderPipelineSetLabel") {
    return bridge.invoke("renderPipelineSetLabel", .{a0, a1});
}
const F_renderPipelineAddRef = @typeInfo(@typeInfo(c.WGPUProcRenderPipelineAddRef).optional.child).pointer.child;
pub fn renderPipelineAddRef(a0: @typeInfo(F_renderPipelineAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPipelineAddRef") {
    return bridge.invoke("renderPipelineAddRef", .{a0});
}
const F_renderPipelineRelease = @typeInfo(@typeInfo(c.WGPUProcRenderPipelineRelease).optional.child).pointer.child;
pub fn renderPipelineRelease(a0: @typeInfo(F_renderPipelineRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("renderPipelineRelease") {
    return bridge.invoke("renderPipelineRelease", .{a0});
}
const F_resourceTableDestroy = @typeInfo(@typeInfo(c.WGPUProcResourceTableDestroy).optional.child).pointer.child;
pub fn resourceTableDestroy(a0: @typeInfo(F_resourceTableDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("resourceTableDestroy") {
    return bridge.invoke("resourceTableDestroy", .{a0});
}
const F_resourceTableGetSize = @typeInfo(@typeInfo(c.WGPUProcResourceTableGetSize).optional.child).pointer.child;
pub fn resourceTableGetSize(a0: @typeInfo(F_resourceTableGetSize).@"fn".params[0].type.?) callconv(.c) bridge.Return("resourceTableGetSize") {
    return bridge.invoke("resourceTableGetSize", .{a0});
}
const F_resourceTableInsertBinding = @typeInfo(@typeInfo(c.WGPUProcResourceTableInsertBinding).optional.child).pointer.child;
pub fn resourceTableInsertBinding(a0: @typeInfo(F_resourceTableInsertBinding).@"fn".params[0].type.?, a1: @typeInfo(F_resourceTableInsertBinding).@"fn".params[1].type.?) callconv(.c) bridge.Return("resourceTableInsertBinding") {
    return bridge.invoke("resourceTableInsertBinding", .{a0, a1});
}
const F_resourceTableRemoveBinding = @typeInfo(@typeInfo(c.WGPUProcResourceTableRemoveBinding).optional.child).pointer.child;
pub fn resourceTableRemoveBinding(a0: @typeInfo(F_resourceTableRemoveBinding).@"fn".params[0].type.?, a1: @typeInfo(F_resourceTableRemoveBinding).@"fn".params[1].type.?) callconv(.c) bridge.Return("resourceTableRemoveBinding") {
    return bridge.invoke("resourceTableRemoveBinding", .{a0, a1});
}
const F_resourceTableUpdate = @typeInfo(@typeInfo(c.WGPUProcResourceTableUpdate).optional.child).pointer.child;
pub fn resourceTableUpdate(a0: @typeInfo(F_resourceTableUpdate).@"fn".params[0].type.?, a1: @typeInfo(F_resourceTableUpdate).@"fn".params[1].type.?, a2: @typeInfo(F_resourceTableUpdate).@"fn".params[2].type.?) callconv(.c) bridge.Return("resourceTableUpdate") {
    return bridge.invoke("resourceTableUpdate", .{a0, a1, a2});
}
const F_resourceTableAddRef = @typeInfo(@typeInfo(c.WGPUProcResourceTableAddRef).optional.child).pointer.child;
pub fn resourceTableAddRef(a0: @typeInfo(F_resourceTableAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("resourceTableAddRef") {
    return bridge.invoke("resourceTableAddRef", .{a0});
}
const F_resourceTableRelease = @typeInfo(@typeInfo(c.WGPUProcResourceTableRelease).optional.child).pointer.child;
pub fn resourceTableRelease(a0: @typeInfo(F_resourceTableRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("resourceTableRelease") {
    return bridge.invoke("resourceTableRelease", .{a0});
}
const F_samplerSetLabel = @typeInfo(@typeInfo(c.WGPUProcSamplerSetLabel).optional.child).pointer.child;
pub fn samplerSetLabel(a0: @typeInfo(F_samplerSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_samplerSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("samplerSetLabel") {
    return bridge.invoke("samplerSetLabel", .{a0, a1});
}
const F_samplerAddRef = @typeInfo(@typeInfo(c.WGPUProcSamplerAddRef).optional.child).pointer.child;
pub fn samplerAddRef(a0: @typeInfo(F_samplerAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("samplerAddRef") {
    return bridge.invoke("samplerAddRef", .{a0});
}
const F_samplerRelease = @typeInfo(@typeInfo(c.WGPUProcSamplerRelease).optional.child).pointer.child;
pub fn samplerRelease(a0: @typeInfo(F_samplerRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("samplerRelease") {
    return bridge.invoke("samplerRelease", .{a0});
}
const F_shaderModuleGetCompilationInfo = @typeInfo(@typeInfo(c.WGPUProcShaderModuleGetCompilationInfo).optional.child).pointer.child;
pub fn shaderModuleGetCompilationInfo(a0: @typeInfo(F_shaderModuleGetCompilationInfo).@"fn".params[0].type.?, a1: @typeInfo(F_shaderModuleGetCompilationInfo).@"fn".params[1].type.?) callconv(.c) bridge.Return("shaderModuleGetCompilationInfo") {
    return bridge.invoke("shaderModuleGetCompilationInfo", .{a0, a1});
}
const F_shaderModuleSetLabel = @typeInfo(@typeInfo(c.WGPUProcShaderModuleSetLabel).optional.child).pointer.child;
pub fn shaderModuleSetLabel(a0: @typeInfo(F_shaderModuleSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_shaderModuleSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("shaderModuleSetLabel") {
    return bridge.invoke("shaderModuleSetLabel", .{a0, a1});
}
const F_shaderModuleAddRef = @typeInfo(@typeInfo(c.WGPUProcShaderModuleAddRef).optional.child).pointer.child;
pub fn shaderModuleAddRef(a0: @typeInfo(F_shaderModuleAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("shaderModuleAddRef") {
    return bridge.invoke("shaderModuleAddRef", .{a0});
}
const F_shaderModuleRelease = @typeInfo(@typeInfo(c.WGPUProcShaderModuleRelease).optional.child).pointer.child;
pub fn shaderModuleRelease(a0: @typeInfo(F_shaderModuleRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("shaderModuleRelease") {
    return bridge.invoke("shaderModuleRelease", .{a0});
}
const F_sharedBufferMemoryBeginAccess = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryBeginAccess).optional.child).pointer.child;
pub fn sharedBufferMemoryBeginAccess(a0: @typeInfo(F_sharedBufferMemoryBeginAccess).@"fn".params[0].type.?, a1: @typeInfo(F_sharedBufferMemoryBeginAccess).@"fn".params[1].type.?, a2: @typeInfo(F_sharedBufferMemoryBeginAccess).@"fn".params[2].type.?) callconv(.c) bridge.Return("sharedBufferMemoryBeginAccess") {
    return bridge.invoke("sharedBufferMemoryBeginAccess", .{a0, a1, a2});
}
const F_sharedBufferMemoryCreateBuffer = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryCreateBuffer).optional.child).pointer.child;
pub fn sharedBufferMemoryCreateBuffer(a0: @typeInfo(F_sharedBufferMemoryCreateBuffer).@"fn".params[0].type.?, a1: @typeInfo(F_sharedBufferMemoryCreateBuffer).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedBufferMemoryCreateBuffer") {
    return bridge.invoke("sharedBufferMemoryCreateBuffer", .{a0, a1});
}
const F_sharedBufferMemoryEndAccess = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryEndAccess).optional.child).pointer.child;
pub fn sharedBufferMemoryEndAccess(a0: @typeInfo(F_sharedBufferMemoryEndAccess).@"fn".params[0].type.?, a1: @typeInfo(F_sharedBufferMemoryEndAccess).@"fn".params[1].type.?, a2: @typeInfo(F_sharedBufferMemoryEndAccess).@"fn".params[2].type.?) callconv(.c) bridge.Return("sharedBufferMemoryEndAccess") {
    return bridge.invoke("sharedBufferMemoryEndAccess", .{a0, a1, a2});
}
const F_sharedBufferMemoryGetProperties = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryGetProperties).optional.child).pointer.child;
pub fn sharedBufferMemoryGetProperties(a0: @typeInfo(F_sharedBufferMemoryGetProperties).@"fn".params[0].type.?, a1: @typeInfo(F_sharedBufferMemoryGetProperties).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedBufferMemoryGetProperties") {
    return bridge.invoke("sharedBufferMemoryGetProperties", .{a0, a1});
}
const F_sharedBufferMemoryIsDeviceLost = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryIsDeviceLost).optional.child).pointer.child;
pub fn sharedBufferMemoryIsDeviceLost(a0: @typeInfo(F_sharedBufferMemoryIsDeviceLost).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedBufferMemoryIsDeviceLost") {
    return bridge.invoke("sharedBufferMemoryIsDeviceLost", .{a0});
}
const F_sharedBufferMemorySetLabel = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemorySetLabel).optional.child).pointer.child;
pub fn sharedBufferMemorySetLabel(a0: @typeInfo(F_sharedBufferMemorySetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_sharedBufferMemorySetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedBufferMemorySetLabel") {
    return bridge.invoke("sharedBufferMemorySetLabel", .{a0, a1});
}
const F_sharedBufferMemoryAddRef = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryAddRef).optional.child).pointer.child;
pub fn sharedBufferMemoryAddRef(a0: @typeInfo(F_sharedBufferMemoryAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedBufferMemoryAddRef") {
    return bridge.invoke("sharedBufferMemoryAddRef", .{a0});
}
const F_sharedBufferMemoryRelease = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryRelease).optional.child).pointer.child;
pub fn sharedBufferMemoryRelease(a0: @typeInfo(F_sharedBufferMemoryRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedBufferMemoryRelease") {
    return bridge.invoke("sharedBufferMemoryRelease", .{a0});
}
const F_sharedBufferMemoryEndAccessStateFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSharedBufferMemoryEndAccessStateFreeMembers).optional.child).pointer.child;
pub fn sharedBufferMemoryEndAccessStateFreeMembers(a0: @typeInfo(F_sharedBufferMemoryEndAccessStateFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedBufferMemoryEndAccessStateFreeMembers") {
    return bridge.invoke("sharedBufferMemoryEndAccessStateFreeMembers", .{a0});
}
const F_sharedFenceExportInfo = @typeInfo(@typeInfo(c.WGPUProcSharedFenceExportInfo).optional.child).pointer.child;
pub fn sharedFenceExportInfo(a0: @typeInfo(F_sharedFenceExportInfo).@"fn".params[0].type.?, a1: @typeInfo(F_sharedFenceExportInfo).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedFenceExportInfo") {
    return bridge.invoke("sharedFenceExportInfo", .{a0, a1});
}
const F_sharedFenceAddRef = @typeInfo(@typeInfo(c.WGPUProcSharedFenceAddRef).optional.child).pointer.child;
pub fn sharedFenceAddRef(a0: @typeInfo(F_sharedFenceAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedFenceAddRef") {
    return bridge.invoke("sharedFenceAddRef", .{a0});
}
const F_sharedFenceRelease = @typeInfo(@typeInfo(c.WGPUProcSharedFenceRelease).optional.child).pointer.child;
pub fn sharedFenceRelease(a0: @typeInfo(F_sharedFenceRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedFenceRelease") {
    return bridge.invoke("sharedFenceRelease", .{a0});
}
const F_sharedTextureMemoryBeginAccess = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryBeginAccess).optional.child).pointer.child;
pub fn sharedTextureMemoryBeginAccess(a0: @typeInfo(F_sharedTextureMemoryBeginAccess).@"fn".params[0].type.?, a1: @typeInfo(F_sharedTextureMemoryBeginAccess).@"fn".params[1].type.?, a2: @typeInfo(F_sharedTextureMemoryBeginAccess).@"fn".params[2].type.?) callconv(.c) bridge.Return("sharedTextureMemoryBeginAccess") {
    return bridge.invoke("sharedTextureMemoryBeginAccess", .{a0, a1, a2});
}
const F_sharedTextureMemoryCreateTexture = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryCreateTexture).optional.child).pointer.child;
pub fn sharedTextureMemoryCreateTexture(a0: @typeInfo(F_sharedTextureMemoryCreateTexture).@"fn".params[0].type.?, a1: @typeInfo(F_sharedTextureMemoryCreateTexture).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedTextureMemoryCreateTexture") {
    return bridge.invoke("sharedTextureMemoryCreateTexture", .{a0, a1});
}
const F_sharedTextureMemoryEndAccess = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryEndAccess).optional.child).pointer.child;
pub fn sharedTextureMemoryEndAccess(a0: @typeInfo(F_sharedTextureMemoryEndAccess).@"fn".params[0].type.?, a1: @typeInfo(F_sharedTextureMemoryEndAccess).@"fn".params[1].type.?, a2: @typeInfo(F_sharedTextureMemoryEndAccess).@"fn".params[2].type.?) callconv(.c) bridge.Return("sharedTextureMemoryEndAccess") {
    return bridge.invoke("sharedTextureMemoryEndAccess", .{a0, a1, a2});
}
const F_sharedTextureMemoryGetProperties = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryGetProperties).optional.child).pointer.child;
pub fn sharedTextureMemoryGetProperties(a0: @typeInfo(F_sharedTextureMemoryGetProperties).@"fn".params[0].type.?, a1: @typeInfo(F_sharedTextureMemoryGetProperties).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedTextureMemoryGetProperties") {
    return bridge.invoke("sharedTextureMemoryGetProperties", .{a0, a1});
}
const F_sharedTextureMemoryIsDeviceLost = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryIsDeviceLost).optional.child).pointer.child;
pub fn sharedTextureMemoryIsDeviceLost(a0: @typeInfo(F_sharedTextureMemoryIsDeviceLost).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedTextureMemoryIsDeviceLost") {
    return bridge.invoke("sharedTextureMemoryIsDeviceLost", .{a0});
}
const F_sharedTextureMemorySetLabel = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemorySetLabel).optional.child).pointer.child;
pub fn sharedTextureMemorySetLabel(a0: @typeInfo(F_sharedTextureMemorySetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_sharedTextureMemorySetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("sharedTextureMemorySetLabel") {
    return bridge.invoke("sharedTextureMemorySetLabel", .{a0, a1});
}
const F_sharedTextureMemoryAddRef = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryAddRef).optional.child).pointer.child;
pub fn sharedTextureMemoryAddRef(a0: @typeInfo(F_sharedTextureMemoryAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedTextureMemoryAddRef") {
    return bridge.invoke("sharedTextureMemoryAddRef", .{a0});
}
const F_sharedTextureMemoryRelease = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryRelease).optional.child).pointer.child;
pub fn sharedTextureMemoryRelease(a0: @typeInfo(F_sharedTextureMemoryRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedTextureMemoryRelease") {
    return bridge.invoke("sharedTextureMemoryRelease", .{a0});
}
const F_sharedTextureMemoryEndAccessStateFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSharedTextureMemoryEndAccessStateFreeMembers).optional.child).pointer.child;
pub fn sharedTextureMemoryEndAccessStateFreeMembers(a0: @typeInfo(F_sharedTextureMemoryEndAccessStateFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("sharedTextureMemoryEndAccessStateFreeMembers") {
    return bridge.invoke("sharedTextureMemoryEndAccessStateFreeMembers", .{a0});
}
const F_supportedFeaturesFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSupportedFeaturesFreeMembers).optional.child).pointer.child;
pub fn supportedFeaturesFreeMembers(a0: @typeInfo(F_supportedFeaturesFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("supportedFeaturesFreeMembers") {
    return bridge.invoke("supportedFeaturesFreeMembers", .{a0});
}
const F_supportedInstanceFeaturesFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSupportedInstanceFeaturesFreeMembers).optional.child).pointer.child;
pub fn supportedInstanceFeaturesFreeMembers(a0: @typeInfo(F_supportedInstanceFeaturesFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("supportedInstanceFeaturesFreeMembers") {
    return bridge.invoke("supportedInstanceFeaturesFreeMembers", .{a0});
}
const F_supportedWGSLLanguageFeaturesFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSupportedWGSLLanguageFeaturesFreeMembers).optional.child).pointer.child;
pub fn supportedWGSLLanguageFeaturesFreeMembers(a0: @typeInfo(F_supportedWGSLLanguageFeaturesFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("supportedWGSLLanguageFeaturesFreeMembers") {
    return bridge.invoke("supportedWGSLLanguageFeaturesFreeMembers", .{a0});
}
const F_surfaceConfigure = @typeInfo(@typeInfo(c.WGPUProcSurfaceConfigure).optional.child).pointer.child;
pub fn surfaceConfigure(a0: @typeInfo(F_surfaceConfigure).@"fn".params[0].type.?, a1: @typeInfo(F_surfaceConfigure).@"fn".params[1].type.?) callconv(.c) bridge.Return("surfaceConfigure") {
    return bridge.invoke("surfaceConfigure", .{a0, a1});
}
const F_surfaceGetCapabilities = @typeInfo(@typeInfo(c.WGPUProcSurfaceGetCapabilities).optional.child).pointer.child;
pub fn surfaceGetCapabilities(a0: @typeInfo(F_surfaceGetCapabilities).@"fn".params[0].type.?, a1: @typeInfo(F_surfaceGetCapabilities).@"fn".params[1].type.?, a2: @typeInfo(F_surfaceGetCapabilities).@"fn".params[2].type.?) callconv(.c) bridge.Return("surfaceGetCapabilities") {
    return bridge.invoke("surfaceGetCapabilities", .{a0, a1, a2});
}
const F_surfaceGetCurrentTexture = @typeInfo(@typeInfo(c.WGPUProcSurfaceGetCurrentTexture).optional.child).pointer.child;
pub fn surfaceGetCurrentTexture(a0: @typeInfo(F_surfaceGetCurrentTexture).@"fn".params[0].type.?, a1: @typeInfo(F_surfaceGetCurrentTexture).@"fn".params[1].type.?) callconv(.c) bridge.Return("surfaceGetCurrentTexture") {
    return bridge.invoke("surfaceGetCurrentTexture", .{a0, a1});
}
const F_surfacePresent = @typeInfo(@typeInfo(c.WGPUProcSurfacePresent).optional.child).pointer.child;
pub fn surfacePresent(a0: @typeInfo(F_surfacePresent).@"fn".params[0].type.?) callconv(.c) bridge.Return("surfacePresent") {
    return bridge.invoke("surfacePresent", .{a0});
}
const F_surfaceSetLabel = @typeInfo(@typeInfo(c.WGPUProcSurfaceSetLabel).optional.child).pointer.child;
pub fn surfaceSetLabel(a0: @typeInfo(F_surfaceSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_surfaceSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("surfaceSetLabel") {
    return bridge.invoke("surfaceSetLabel", .{a0, a1});
}
const F_surfaceUnconfigure = @typeInfo(@typeInfo(c.WGPUProcSurfaceUnconfigure).optional.child).pointer.child;
pub fn surfaceUnconfigure(a0: @typeInfo(F_surfaceUnconfigure).@"fn".params[0].type.?) callconv(.c) bridge.Return("surfaceUnconfigure") {
    return bridge.invoke("surfaceUnconfigure", .{a0});
}
const F_surfaceAddRef = @typeInfo(@typeInfo(c.WGPUProcSurfaceAddRef).optional.child).pointer.child;
pub fn surfaceAddRef(a0: @typeInfo(F_surfaceAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("surfaceAddRef") {
    return bridge.invoke("surfaceAddRef", .{a0});
}
const F_surfaceRelease = @typeInfo(@typeInfo(c.WGPUProcSurfaceRelease).optional.child).pointer.child;
pub fn surfaceRelease(a0: @typeInfo(F_surfaceRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("surfaceRelease") {
    return bridge.invoke("surfaceRelease", .{a0});
}
const F_surfaceCapabilitiesFreeMembers = @typeInfo(@typeInfo(c.WGPUProcSurfaceCapabilitiesFreeMembers).optional.child).pointer.child;
pub fn surfaceCapabilitiesFreeMembers(a0: @typeInfo(F_surfaceCapabilitiesFreeMembers).@"fn".params[0].type.?) callconv(.c) bridge.Return("surfaceCapabilitiesFreeMembers") {
    return bridge.invoke("surfaceCapabilitiesFreeMembers", .{a0});
}
const F_texelBufferViewSetLabel = @typeInfo(@typeInfo(c.WGPUProcTexelBufferViewSetLabel).optional.child).pointer.child;
pub fn texelBufferViewSetLabel(a0: @typeInfo(F_texelBufferViewSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_texelBufferViewSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("texelBufferViewSetLabel") {
    return bridge.invoke("texelBufferViewSetLabel", .{a0, a1});
}
const F_texelBufferViewAddRef = @typeInfo(@typeInfo(c.WGPUProcTexelBufferViewAddRef).optional.child).pointer.child;
pub fn texelBufferViewAddRef(a0: @typeInfo(F_texelBufferViewAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("texelBufferViewAddRef") {
    return bridge.invoke("texelBufferViewAddRef", .{a0});
}
const F_texelBufferViewRelease = @typeInfo(@typeInfo(c.WGPUProcTexelBufferViewRelease).optional.child).pointer.child;
pub fn texelBufferViewRelease(a0: @typeInfo(F_texelBufferViewRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("texelBufferViewRelease") {
    return bridge.invoke("texelBufferViewRelease", .{a0});
}
const F_textureCreateErrorView = @typeInfo(@typeInfo(c.WGPUProcTextureCreateErrorView).optional.child).pointer.child;
pub fn textureCreateErrorView(a0: @typeInfo(F_textureCreateErrorView).@"fn".params[0].type.?, a1: @typeInfo(F_textureCreateErrorView).@"fn".params[1].type.?) callconv(.c) bridge.Return("textureCreateErrorView") {
    return bridge.invoke("textureCreateErrorView", .{a0, a1});
}
const F_textureCreateView = @typeInfo(@typeInfo(c.WGPUProcTextureCreateView).optional.child).pointer.child;
pub fn textureCreateView(a0: @typeInfo(F_textureCreateView).@"fn".params[0].type.?, a1: @typeInfo(F_textureCreateView).@"fn".params[1].type.?) callconv(.c) bridge.Return("textureCreateView") {
    return bridge.invoke("textureCreateView", .{a0, a1});
}
const F_textureDestroy = @typeInfo(@typeInfo(c.WGPUProcTextureDestroy).optional.child).pointer.child;
pub fn textureDestroy(a0: @typeInfo(F_textureDestroy).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureDestroy") {
    return bridge.invoke("textureDestroy", .{a0});
}
const F_textureGetDepthOrArrayLayers = @typeInfo(@typeInfo(c.WGPUProcTextureGetDepthOrArrayLayers).optional.child).pointer.child;
pub fn textureGetDepthOrArrayLayers(a0: @typeInfo(F_textureGetDepthOrArrayLayers).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetDepthOrArrayLayers") {
    return bridge.invoke("textureGetDepthOrArrayLayers", .{a0});
}
const F_textureGetDimension = @typeInfo(@typeInfo(c.WGPUProcTextureGetDimension).optional.child).pointer.child;
pub fn textureGetDimension(a0: @typeInfo(F_textureGetDimension).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetDimension") {
    return bridge.invoke("textureGetDimension", .{a0});
}
const F_textureGetFormat = @typeInfo(@typeInfo(c.WGPUProcTextureGetFormat).optional.child).pointer.child;
pub fn textureGetFormat(a0: @typeInfo(F_textureGetFormat).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetFormat") {
    return bridge.invoke("textureGetFormat", .{a0});
}
const F_textureGetHeight = @typeInfo(@typeInfo(c.WGPUProcTextureGetHeight).optional.child).pointer.child;
pub fn textureGetHeight(a0: @typeInfo(F_textureGetHeight).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetHeight") {
    return bridge.invoke("textureGetHeight", .{a0});
}
const F_textureGetMipLevelCount = @typeInfo(@typeInfo(c.WGPUProcTextureGetMipLevelCount).optional.child).pointer.child;
pub fn textureGetMipLevelCount(a0: @typeInfo(F_textureGetMipLevelCount).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetMipLevelCount") {
    return bridge.invoke("textureGetMipLevelCount", .{a0});
}
const F_textureGetSampleCount = @typeInfo(@typeInfo(c.WGPUProcTextureGetSampleCount).optional.child).pointer.child;
pub fn textureGetSampleCount(a0: @typeInfo(F_textureGetSampleCount).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetSampleCount") {
    return bridge.invoke("textureGetSampleCount", .{a0});
}
const F_textureGetTextureBindingViewDimension = @typeInfo(@typeInfo(c.WGPUProcTextureGetTextureBindingViewDimension).optional.child).pointer.child;
pub fn textureGetTextureBindingViewDimension(a0: @typeInfo(F_textureGetTextureBindingViewDimension).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetTextureBindingViewDimension") {
    return bridge.invoke("textureGetTextureBindingViewDimension", .{a0});
}
const F_textureGetUsage = @typeInfo(@typeInfo(c.WGPUProcTextureGetUsage).optional.child).pointer.child;
pub fn textureGetUsage(a0: @typeInfo(F_textureGetUsage).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetUsage") {
    return bridge.invoke("textureGetUsage", .{a0});
}
const F_textureGetWidth = @typeInfo(@typeInfo(c.WGPUProcTextureGetWidth).optional.child).pointer.child;
pub fn textureGetWidth(a0: @typeInfo(F_textureGetWidth).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureGetWidth") {
    return bridge.invoke("textureGetWidth", .{a0});
}
const F_texturePin = @typeInfo(@typeInfo(c.WGPUProcTexturePin).optional.child).pointer.child;
pub fn texturePin(a0: @typeInfo(F_texturePin).@"fn".params[0].type.?, a1: @typeInfo(F_texturePin).@"fn".params[1].type.?) callconv(.c) bridge.Return("texturePin") {
    return bridge.invoke("texturePin", .{a0, a1});
}
const F_textureSetLabel = @typeInfo(@typeInfo(c.WGPUProcTextureSetLabel).optional.child).pointer.child;
pub fn textureSetLabel(a0: @typeInfo(F_textureSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_textureSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("textureSetLabel") {
    return bridge.invoke("textureSetLabel", .{a0, a1});
}
const F_textureSetOwnershipForMemoryDump = @typeInfo(@typeInfo(c.WGPUProcTextureSetOwnershipForMemoryDump).optional.child).pointer.child;
pub fn textureSetOwnershipForMemoryDump(a0: @typeInfo(F_textureSetOwnershipForMemoryDump).@"fn".params[0].type.?, a1: @typeInfo(F_textureSetOwnershipForMemoryDump).@"fn".params[1].type.?) callconv(.c) bridge.Return("textureSetOwnershipForMemoryDump") {
    return bridge.invoke("textureSetOwnershipForMemoryDump", .{a0, a1});
}
const F_textureUnpin = @typeInfo(@typeInfo(c.WGPUProcTextureUnpin).optional.child).pointer.child;
pub fn textureUnpin(a0: @typeInfo(F_textureUnpin).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureUnpin") {
    return bridge.invoke("textureUnpin", .{a0});
}
const F_textureAddRef = @typeInfo(@typeInfo(c.WGPUProcTextureAddRef).optional.child).pointer.child;
pub fn textureAddRef(a0: @typeInfo(F_textureAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureAddRef") {
    return bridge.invoke("textureAddRef", .{a0});
}
const F_textureRelease = @typeInfo(@typeInfo(c.WGPUProcTextureRelease).optional.child).pointer.child;
pub fn textureRelease(a0: @typeInfo(F_textureRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureRelease") {
    return bridge.invoke("textureRelease", .{a0});
}
const F_textureViewSetLabel = @typeInfo(@typeInfo(c.WGPUProcTextureViewSetLabel).optional.child).pointer.child;
pub fn textureViewSetLabel(a0: @typeInfo(F_textureViewSetLabel).@"fn".params[0].type.?, a1: @typeInfo(F_textureViewSetLabel).@"fn".params[1].type.?) callconv(.c) bridge.Return("textureViewSetLabel") {
    return bridge.invoke("textureViewSetLabel", .{a0, a1});
}
const F_textureViewAddRef = @typeInfo(@typeInfo(c.WGPUProcTextureViewAddRef).optional.child).pointer.child;
pub fn textureViewAddRef(a0: @typeInfo(F_textureViewAddRef).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureViewAddRef") {
    return bridge.invoke("textureViewAddRef", .{a0});
}
const F_textureViewRelease = @typeInfo(@typeInfo(c.WGPUProcTextureViewRelease).optional.child).pointer.child;
pub fn textureViewRelease(a0: @typeInfo(F_textureViewRelease).@"fn".params[0].type.?) callconv(.c) bridge.Return("textureViewRelease") {
    return bridge.invoke("textureViewRelease", .{a0});
}
pub fn isStandard(comptime field: []const u8) bool {
    const std = @import("std");
    if (std.mem.eql(u8, field, "createInstance")) return true;
    if (std.mem.eql(u8, field, "getInstanceFeatures")) return true;
    if (std.mem.eql(u8, field, "getInstanceLimits")) return true;
    if (std.mem.eql(u8, field, "hasInstanceFeature")) return true;
    if (std.mem.eql(u8, field, "getProcAddress")) return true;
    if (std.mem.eql(u8, field, "adapterGetFeatures")) return true;
    if (std.mem.eql(u8, field, "adapterGetInfo")) return true;
    if (std.mem.eql(u8, field, "adapterGetLimits")) return true;
    if (std.mem.eql(u8, field, "adapterHasFeature")) return true;
    if (std.mem.eql(u8, field, "adapterRequestDevice")) return true;
    if (std.mem.eql(u8, field, "adapterAddRef")) return true;
    if (std.mem.eql(u8, field, "adapterRelease")) return true;
    if (std.mem.eql(u8, field, "adapterInfoFreeMembers")) return true;
    if (std.mem.eql(u8, field, "bindGroupSetLabel")) return true;
    if (std.mem.eql(u8, field, "bindGroupAddRef")) return true;
    if (std.mem.eql(u8, field, "bindGroupRelease")) return true;
    if (std.mem.eql(u8, field, "bindGroupLayoutSetLabel")) return true;
    if (std.mem.eql(u8, field, "bindGroupLayoutAddRef")) return true;
    if (std.mem.eql(u8, field, "bindGroupLayoutRelease")) return true;
    if (std.mem.eql(u8, field, "bufferDestroy")) return true;
    if (std.mem.eql(u8, field, "bufferGetConstMappedRange")) return true;
    if (std.mem.eql(u8, field, "bufferGetMappedRange")) return true;
    if (std.mem.eql(u8, field, "bufferGetMapState")) return true;
    if (std.mem.eql(u8, field, "bufferGetSize")) return true;
    if (std.mem.eql(u8, field, "bufferGetUsage")) return true;
    if (std.mem.eql(u8, field, "bufferMapAsync")) return true;
    if (std.mem.eql(u8, field, "bufferReadMappedRange")) return true;
    if (std.mem.eql(u8, field, "bufferSetLabel")) return true;
    if (std.mem.eql(u8, field, "bufferUnmap")) return true;
    if (std.mem.eql(u8, field, "bufferWriteMappedRange")) return true;
    if (std.mem.eql(u8, field, "bufferAddRef")) return true;
    if (std.mem.eql(u8, field, "bufferRelease")) return true;
    if (std.mem.eql(u8, field, "commandBufferSetLabel")) return true;
    if (std.mem.eql(u8, field, "commandBufferAddRef")) return true;
    if (std.mem.eql(u8, field, "commandBufferRelease")) return true;
    if (std.mem.eql(u8, field, "commandEncoderBeginComputePass")) return true;
    if (std.mem.eql(u8, field, "commandEncoderBeginRenderPass")) return true;
    if (std.mem.eql(u8, field, "commandEncoderClearBuffer")) return true;
    if (std.mem.eql(u8, field, "commandEncoderCopyBufferToBuffer")) return true;
    if (std.mem.eql(u8, field, "commandEncoderCopyBufferToTexture")) return true;
    if (std.mem.eql(u8, field, "commandEncoderCopyTextureToBuffer")) return true;
    if (std.mem.eql(u8, field, "commandEncoderCopyTextureToTexture")) return true;
    if (std.mem.eql(u8, field, "commandEncoderFinish")) return true;
    if (std.mem.eql(u8, field, "commandEncoderInsertDebugMarker")) return true;
    if (std.mem.eql(u8, field, "commandEncoderPopDebugGroup")) return true;
    if (std.mem.eql(u8, field, "commandEncoderPushDebugGroup")) return true;
    if (std.mem.eql(u8, field, "commandEncoderResolveQuerySet")) return true;
    if (std.mem.eql(u8, field, "commandEncoderSetLabel")) return true;
    if (std.mem.eql(u8, field, "commandEncoderWriteTimestamp")) return true;
    if (std.mem.eql(u8, field, "commandEncoderAddRef")) return true;
    if (std.mem.eql(u8, field, "commandEncoderRelease")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderDispatchWorkgroups")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderDispatchWorkgroupsIndirect")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderEnd")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderInsertDebugMarker")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderPopDebugGroup")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderPushDebugGroup")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderSetBindGroup")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderSetImmediates")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderSetLabel")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderSetPipeline")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderAddRef")) return true;
    if (std.mem.eql(u8, field, "computePassEncoderRelease")) return true;
    if (std.mem.eql(u8, field, "computePipelineGetBindGroupLayout")) return true;
    if (std.mem.eql(u8, field, "computePipelineSetLabel")) return true;
    if (std.mem.eql(u8, field, "computePipelineAddRef")) return true;
    if (std.mem.eql(u8, field, "computePipelineRelease")) return true;
    if (std.mem.eql(u8, field, "deviceCreateBindGroup")) return true;
    if (std.mem.eql(u8, field, "deviceCreateBindGroupLayout")) return true;
    if (std.mem.eql(u8, field, "deviceCreateBuffer")) return true;
    if (std.mem.eql(u8, field, "deviceCreateCommandEncoder")) return true;
    if (std.mem.eql(u8, field, "deviceCreateComputePipeline")) return true;
    if (std.mem.eql(u8, field, "deviceCreateComputePipelineAsync")) return true;
    if (std.mem.eql(u8, field, "deviceCreatePipelineLayout")) return true;
    if (std.mem.eql(u8, field, "deviceCreateQuerySet")) return true;
    if (std.mem.eql(u8, field, "deviceCreateRenderBundleEncoder")) return true;
    if (std.mem.eql(u8, field, "deviceCreateRenderPipeline")) return true;
    if (std.mem.eql(u8, field, "deviceCreateRenderPipelineAsync")) return true;
    if (std.mem.eql(u8, field, "deviceCreateSampler")) return true;
    if (std.mem.eql(u8, field, "deviceCreateShaderModule")) return true;
    if (std.mem.eql(u8, field, "deviceCreateTexture")) return true;
    if (std.mem.eql(u8, field, "deviceDestroy")) return true;
    if (std.mem.eql(u8, field, "deviceGetAdapterInfo")) return true;
    if (std.mem.eql(u8, field, "deviceGetFeatures")) return true;
    if (std.mem.eql(u8, field, "deviceGetLimits")) return true;
    if (std.mem.eql(u8, field, "deviceGetLostFuture")) return true;
    if (std.mem.eql(u8, field, "deviceGetQueue")) return true;
    if (std.mem.eql(u8, field, "deviceHasFeature")) return true;
    if (std.mem.eql(u8, field, "devicePopErrorScope")) return true;
    if (std.mem.eql(u8, field, "devicePushErrorScope")) return true;
    if (std.mem.eql(u8, field, "deviceSetLabel")) return true;
    if (std.mem.eql(u8, field, "deviceAddRef")) return true;
    if (std.mem.eql(u8, field, "deviceRelease")) return true;
    if (std.mem.eql(u8, field, "externalTextureSetLabel")) return true;
    if (std.mem.eql(u8, field, "externalTextureAddRef")) return true;
    if (std.mem.eql(u8, field, "externalTextureRelease")) return true;
    if (std.mem.eql(u8, field, "instanceCreateSurface")) return true;
    if (std.mem.eql(u8, field, "instanceProcessEvents")) return true;
    if (std.mem.eql(u8, field, "instanceRequestAdapter")) return true;
    if (std.mem.eql(u8, field, "instanceWaitAny")) return true;
    if (std.mem.eql(u8, field, "instanceAddRef")) return true;
    if (std.mem.eql(u8, field, "instanceRelease")) return true;
    if (std.mem.eql(u8, field, "pipelineLayoutSetLabel")) return true;
    if (std.mem.eql(u8, field, "pipelineLayoutAddRef")) return true;
    if (std.mem.eql(u8, field, "pipelineLayoutRelease")) return true;
    if (std.mem.eql(u8, field, "querySetDestroy")) return true;
    if (std.mem.eql(u8, field, "querySetGetCount")) return true;
    if (std.mem.eql(u8, field, "querySetGetType")) return true;
    if (std.mem.eql(u8, field, "querySetSetLabel")) return true;
    if (std.mem.eql(u8, field, "querySetAddRef")) return true;
    if (std.mem.eql(u8, field, "querySetRelease")) return true;
    if (std.mem.eql(u8, field, "queueOnSubmittedWorkDone")) return true;
    if (std.mem.eql(u8, field, "queueSetLabel")) return true;
    if (std.mem.eql(u8, field, "queueSubmit")) return true;
    if (std.mem.eql(u8, field, "queueWriteBuffer")) return true;
    if (std.mem.eql(u8, field, "queueWriteTexture")) return true;
    if (std.mem.eql(u8, field, "queueAddRef")) return true;
    if (std.mem.eql(u8, field, "queueRelease")) return true;
    if (std.mem.eql(u8, field, "renderBundleSetLabel")) return true;
    if (std.mem.eql(u8, field, "renderBundleAddRef")) return true;
    if (std.mem.eql(u8, field, "renderBundleRelease")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderDraw")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderDrawIndexed")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderDrawIndexedIndirect")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderDrawIndirect")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderFinish")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderInsertDebugMarker")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderPopDebugGroup")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderPushDebugGroup")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetBindGroup")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetImmediates")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetIndexBuffer")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetLabel")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetPipeline")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderSetVertexBuffer")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderAddRef")) return true;
    if (std.mem.eql(u8, field, "renderBundleEncoderRelease")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderBeginOcclusionQuery")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderDraw")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderDrawIndexed")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderDrawIndexedIndirect")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderDrawIndirect")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderEnd")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderEndOcclusionQuery")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderExecuteBundles")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderInsertDebugMarker")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderPopDebugGroup")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderPushDebugGroup")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetBindGroup")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetBlendConstant")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetImmediates")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetIndexBuffer")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetLabel")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetPipeline")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetScissorRect")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetStencilReference")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetVertexBuffer")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderSetViewport")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderAddRef")) return true;
    if (std.mem.eql(u8, field, "renderPassEncoderRelease")) return true;
    if (std.mem.eql(u8, field, "renderPipelineGetBindGroupLayout")) return true;
    if (std.mem.eql(u8, field, "renderPipelineSetLabel")) return true;
    if (std.mem.eql(u8, field, "renderPipelineAddRef")) return true;
    if (std.mem.eql(u8, field, "renderPipelineRelease")) return true;
    if (std.mem.eql(u8, field, "samplerSetLabel")) return true;
    if (std.mem.eql(u8, field, "samplerAddRef")) return true;
    if (std.mem.eql(u8, field, "samplerRelease")) return true;
    if (std.mem.eql(u8, field, "shaderModuleGetCompilationInfo")) return true;
    if (std.mem.eql(u8, field, "shaderModuleSetLabel")) return true;
    if (std.mem.eql(u8, field, "shaderModuleAddRef")) return true;
    if (std.mem.eql(u8, field, "shaderModuleRelease")) return true;
    if (std.mem.eql(u8, field, "supportedFeaturesFreeMembers")) return true;
    if (std.mem.eql(u8, field, "supportedInstanceFeaturesFreeMembers")) return true;
    if (std.mem.eql(u8, field, "surfaceConfigure")) return true;
    if (std.mem.eql(u8, field, "surfaceGetCapabilities")) return true;
    if (std.mem.eql(u8, field, "surfaceGetCurrentTexture")) return true;
    if (std.mem.eql(u8, field, "surfacePresent")) return true;
    if (std.mem.eql(u8, field, "surfaceSetLabel")) return true;
    if (std.mem.eql(u8, field, "surfaceUnconfigure")) return true;
    if (std.mem.eql(u8, field, "surfaceAddRef")) return true;
    if (std.mem.eql(u8, field, "surfaceRelease")) return true;
    if (std.mem.eql(u8, field, "surfaceCapabilitiesFreeMembers")) return true;
    if (std.mem.eql(u8, field, "textureCreateView")) return true;
    if (std.mem.eql(u8, field, "textureDestroy")) return true;
    if (std.mem.eql(u8, field, "textureGetDepthOrArrayLayers")) return true;
    if (std.mem.eql(u8, field, "textureGetDimension")) return true;
    if (std.mem.eql(u8, field, "textureGetFormat")) return true;
    if (std.mem.eql(u8, field, "textureGetHeight")) return true;
    if (std.mem.eql(u8, field, "textureGetMipLevelCount")) return true;
    if (std.mem.eql(u8, field, "textureGetSampleCount")) return true;
    if (std.mem.eql(u8, field, "textureGetTextureBindingViewDimension")) return true;
    if (std.mem.eql(u8, field, "textureGetUsage")) return true;
    if (std.mem.eql(u8, field, "textureGetWidth")) return true;
    if (std.mem.eql(u8, field, "textureSetLabel")) return true;
    if (std.mem.eql(u8, field, "textureAddRef")) return true;
    if (std.mem.eql(u8, field, "textureRelease")) return true;
    if (std.mem.eql(u8, field, "textureViewSetLabel")) return true;
    if (std.mem.eql(u8, field, "textureViewAddRef")) return true;
    if (std.mem.eql(u8, field, "textureViewRelease")) return true;
    return false;
}
pub fn isStatus(comptime field: []const u8) bool {
    const std = @import("std");
    if (std.mem.eql(u8, field, "getInstanceLimits")) return true;
    if (std.mem.eql(u8, field, "adapterGetFormatCapabilities")) return true;
    if (std.mem.eql(u8, field, "adapterGetInfo")) return true;
    if (std.mem.eql(u8, field, "adapterGetLimits")) return true;
    if (std.mem.eql(u8, field, "bufferReadMappedRange")) return true;
    if (std.mem.eql(u8, field, "bufferWriteMappedRange")) return true;
    if (std.mem.eql(u8, field, "deviceGetAdapterInfo")) return true;
    if (std.mem.eql(u8, field, "deviceGetAHardwareBufferProperties")) return true;
    if (std.mem.eql(u8, field, "deviceGetLimits")) return true;
    if (std.mem.eql(u8, field, "resourceTableRemoveBinding")) return true;
    if (std.mem.eql(u8, field, "resourceTableUpdate")) return true;
    if (std.mem.eql(u8, field, "sharedBufferMemoryBeginAccess")) return true;
    if (std.mem.eql(u8, field, "sharedBufferMemoryEndAccess")) return true;
    if (std.mem.eql(u8, field, "sharedBufferMemoryGetProperties")) return true;
    if (std.mem.eql(u8, field, "sharedTextureMemoryBeginAccess")) return true;
    if (std.mem.eql(u8, field, "sharedTextureMemoryEndAccess")) return true;
    if (std.mem.eql(u8, field, "sharedTextureMemoryGetProperties")) return true;
    if (std.mem.eql(u8, field, "surfaceGetCapabilities")) return true;
    if (std.mem.eql(u8, field, "surfacePresent")) return true;
    return false;
}
