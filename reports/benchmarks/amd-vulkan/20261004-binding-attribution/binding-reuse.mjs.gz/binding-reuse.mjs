import assert from 'node:assert/strict';
const providerPath = process.env.DOE_BINDING_PROVIDER ?? '/home/x/deco/doe/packages/doe-gpu/src/index.js';
const {create, globals} = await import(providerPath);

Object.assign(globalThis, globals);
const gpu = create(['backend=vulkan']);
const adapter = await gpu.requestAdapter();
assert(adapter);
const info = adapter.info;
console.log(JSON.stringify({provider: providerPath, adapter: {vendor: info.vendor, architecture: info.architecture, device: info.device, description: info.description}, fallback: adapter.isFallbackAdapter}));
const device = await adapter.requestDevice();
const usage = globals.GPUBufferUsage;
const first = device.createBuffer({size: 32, usage: usage.UNIFORM | usage.STORAGE | usage.COPY_DST});
const second = device.createBuffer({size: 32, usage: usage.UNIFORM | usage.STORAGE | usage.COPY_DST});
const output = device.createBuffer({size: 4, usage: usage.STORAGE | usage.COPY_SRC});
const readback = device.createBuffer({size: 4, usage: usage.COPY_DST | usage.MAP_READ});
device.queue.writeBuffer(first, 0, new Uint32Array([10, 0, 0, 0, 30, 0, 0, 0]));
device.queue.writeBuffer(second, 0, new Uint32Array([20, 0, 0, 0, 40, 0, 0, 0]));

function makePipeline(storage) {
  const layout = device.createBindGroupLayout({entries: [
    {binding: 0, visibility: GPUShaderStage.COMPUTE, buffer: {type: storage ? 'read-only-storage' : 'uniform'}},
    {binding: 1, visibility: GPUShaderStage.COMPUTE, buffer: {type: 'storage'}},
  ]});
  const module = device.createShaderModule({code: `
    struct Params { value: vec4<u32> };
    @group(0) @binding(0) var<${storage ? 'storage, read' : 'uniform'}> input: Params;
    @group(0) @binding(1) var<storage, read_write> output: array<u32>;
    @compute @workgroup_size(1) fn main() { output[0] = input.value.x; }
  `});
  const pipeline = device.createComputePipeline({layout: device.createPipelineLayout({bindGroupLayouts: [layout]}), compute: {module, entryPoint: 'main'}});
  return {layout, pipeline};
}

const uniform = makePipeline(false);
const storage = makePipeline(true);
function bind(program, buffer, size = 16) {
  return device.createBindGroup({layout: program.layout, entries: [
    {binding: 0, resource: {buffer, offset: 0, size}},
    {binding: 1, resource: {buffer: output}},
  ]});
}
const firstGroup = bind(uniform, first);
const equivalentGroup = bind(uniform, first);
const secondGroup = bind(uniform, second);
const changedRangeGroup = bind(uniform, first, 32);
const storageGroup = bind(storage, first);
async function execute(label, program, group, expected) {
  console.error(`DOE_BINDING_CASE_BEGIN=${label}`);
  const encoder = device.createCommandEncoder();
  for (let index = 0; index < 2; index += 1) {
    const pass = encoder.beginComputePass();
    pass.setPipeline(program.pipeline);
    pass.setBindGroup(0, group);
    pass.dispatchWorkgroups(1);
    pass.end();
  }
  device.queue.submit([encoder.finish()]);
  const copy = device.createCommandEncoder();
  copy.copyBufferToBuffer(output, 0, readback, 0, 4);
  device.queue.submit([copy.finish()]);
  await readback.mapAsync(GPUMapMode.READ);
  const actual = new Uint32Array(readback.getMappedRange())[0];
  readback.unmap();
  assert.equal(actual, expected, label);
  console.log(JSON.stringify({case: label, actual, expected, pass: true}));
  console.error(`DOE_BINDING_CASE_END=${label}`);
}
try {
  await execute('initial', uniform, firstGroup, 10);
  for (let index = 0; index < 3; index += 1) await execute(`unchanged-${index}`, uniform, firstGroup, 10);
  await execute('equivalent-new-bindgroup', uniform, equivalentGroup, 10);
  device.queue.writeBuffer(first, 0, new Uint32Array([99, 0, 0, 0]));
  await execute('changed-buffer-content', uniform, firstGroup, 99);
  await execute('changed-resource', uniform, secondGroup, 20);
  await execute('return-original-resource', uniform, firstGroup, 99);
  await execute('changed-range', uniform, changedRangeGroup, 99);
  await execute('return-original-range', uniform, firstGroup, 99);
  await execute('changed-layout', storage, storageGroup, 99);
  await execute('return-original-layout', uniform, secondGroup, 20);
} finally {
  for (const buffer of [first, second, output, readback]) buffer.destroy();
  device.destroy();
  adapter.destroy?.();
}
