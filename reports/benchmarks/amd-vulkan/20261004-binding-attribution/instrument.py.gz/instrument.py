from pathlib import Path
import subprocess

root=Path.cwd();out=root/'bench/out/vulkan-bindings/20261004'
files=['runtime/zig/src/backend/vulkan/vk_descriptors.zig','runtime/zig/src/backend/vulkan/vk_descriptor_identity.zig','runtime/zig/src/native/queue/doe_queue_submit_vulkan.zig']
for name in files:
 path=root/name;(out/(path.name+'.original')).write_bytes(path.read_bytes())
p=root/files[0];s=p.read_text();anchor='pub fn prepare(\n';diag='''pub const Diagnostic = struct {
    calls: u64 = 0, active: u64 = 0, cached: u64 = 0, misses: u64 = 0,
    prepare_ns: i128 = 0, resolve_ns: i128 = 0, allocation_requests: u64 = 0,
    updates: u64 = 0, writes: u64 = 0, pools: u64 = 0, sets: u64 = 0,
};
pub var diagnostic = Diagnostic{};

''';assert s.count(anchor)==1;s=s.replace(anchor,diag+anchor)
s=s.replace('    if (self.descriptor_set_count == 0) return;\n    const bs', '''    diagnostic.calls += 1;
    const diagnostic_started = std.time.nanoTimestamp();
    defer diagnostic.prepare_ns += std.time.nanoTimestamp() - diagnostic_started;
    if (self.descriptor_set_count == 0) return;
    const bs''',1)
s=s.replace('    var descriptor_bindings_hash = cache.resolve_descriptor_state_hash(self, hint, bs);', '''    var resolve_started = std.time.nanoTimestamp();
    var descriptor_bindings_hash = cache.resolve_descriptor_state_hash(self, hint, bs);
    diagnostic.resolve_ns += std.time.nanoTimestamp() - resolve_started;''',1)
needle='    if (self.has_descriptor_pool and self.has_current_descriptor_bindings_hash and descriptor_bindings_hash == self.current_descriptor_bindings_hash) return;';assert s.count(needle)==2;s=s.replace(needle,'''    if (self.has_descriptor_pool and self.has_current_descriptor_bindings_hash and descriptor_bindings_hash == self.current_descriptor_bindings_hash) {
        diagnostic.active += 1;
        return;
    }''',1)
s=s.replace('    if (cache.has_cached_descriptor_state(self, descriptor_bindings_hash)) {','    if (cache.has_cached_descriptor_state(self, descriptor_bindings_hash)) {\n        diagnostic.cached += 1;',1)
s=s.replace('    if (!self.recorded_submit_replay_active and', '    diagnostic.misses += 1;\n    if (!self.recorded_submit_replay_active and',1)
s=s.replace('    try buffer_infos.ensureTotalCapacity(self.allocator, bs.len);','    diagnostic.allocation_requests += 6;\n    try buffer_infos.ensureTotalCapacity(self.allocator, bs.len);',1)
s=s.replace('    descriptor_bindings_hash = cache.resolve_descriptor_state_hash(self, hint, bs);','    resolve_started = std.time.nanoTimestamp();\n    descriptor_bindings_hash = cache.resolve_descriptor_state_hash(self, hint, bs);\n    diagnostic.resolve_ns += std.time.nanoTimestamp() - resolve_started;',1)
s=s.replace('        c.vkUpdateDescriptorSets(self.device,', '        diagnostic.updates += 1;\n        diagnostic.writes += writes.items.len;\n        c.vkUpdateDescriptorSets(self.device,',1)
s=s.replace('    try c.check_vk(c.vkCreateDescriptorPool', '    diagnostic.pools += 1;\n    try c.check_vk(c.vkCreateDescriptorPool',1)
s=s.replace('    try c.check_vk(c.vkAllocateDescriptorSets', '    diagnostic.sets += self.descriptor_set_count;\n    try c.check_vk(c.vkAllocateDescriptorSets',1);p.write_text(s)
p=root/files[1];s=p.read_text();s=s.replace('pub fn snapshot(self: anytype, declaration:', 'pub var diagnostic_snapshots: u64 = 0;\npub var diagnostic_snapshot_ns: i128 = 0;\n\npub fn snapshot(self: anytype, declaration:',1);s=s.replace('    const result: Binding = switch', '    diagnostic_snapshots += 1;\n    const diagnostic_started = std.time.nanoTimestamp();\n    defer diagnostic_snapshot_ns += std.time.nanoTimestamp() - diagnostic_started;\n    const result: Binding = switch',1);p.write_text(s)
p=root/files[2];s=p.read_text();s=s.replace('const vk_upload = queue_submit_ops.vulkan_upload;', 'const vk_upload = queue_submit_ops.vulkan_upload;\nconst diagnostic_descriptors = @import("../../backend/vulkan/vk_descriptors.zig");\nconst diagnostic_identity = @import("../../backend/vulkan/vk_descriptor_identity.zig");',1)
anchor='    var recorded_replay_work = false;';assert s.count(anchor)==1;s=s.replace(anchor,'''    const before = diagnostic_descriptors.diagnostic;
    const snapshots_before = diagnostic_identity.diagnostic_snapshots;
    const snapshot_ns_before = diagnostic_identity.diagnostic_snapshot_ns;
    var diagnostic_prepare_ns: i128 = 0;
    var diagnostic_record_ns: i128 = 0;
    var diagnostic_submit = vk_upload.RecordedReplaySubmitTimings{};
    defer {
        const after = diagnostic_descriptors.diagnostic;
        std.debug.print("DOE_BINDING_PHASE calls={d} active={d} cached={d} misses={d} descriptors_ns={d} resolve_ns={d} snapshots={d} snapshot_ns={d} allocations={d} updates={d} writes={d} pools={d} sets={d} prepare_ns={d} record_ns={d} end_ns={d} sync_ns={d} driver_ns={d}\\n", .{ after.calls-before.calls, after.active-before.active, after.cached-before.cached, after.misses-before.misses, after.prepare_ns-before.prepare_ns, after.resolve_ns-before.resolve_ns, diagnostic_identity.diagnostic_snapshots-snapshots_before, diagnostic_identity.diagnostic_snapshot_ns-snapshot_ns_before, after.allocation_requests-before.allocation_requests, after.updates-before.updates, after.writes-before.writes, after.pools-before.pools, after.sets-before.sets, diagnostic_prepare_ns, diagnostic_record_ns, diagnostic_submit.command_buffer_end_ns, diagnostic_submit.sync_prepare_ns, diagnostic_submit.driver_submit_ns });
    }
    var recorded_replay_work = false;''',1)
needle='                    if (!prepareRecordedDispatchIfNeeded(rt, dispatch_cmd, &prepared_dispatch)) continue;';assert s.count(needle)==1;s=s.replace(needle,'''                    const diagnostic_started = std.time.nanoTimestamp();
                    const diagnostic_ready = prepareRecordedDispatchIfNeeded(rt, dispatch_cmd, &prepared_dispatch);
                    diagnostic_prepare_ns += std.time.nanoTimestamp() - diagnostic_started;
                    if (!diagnostic_ready) continue;
                    const diagnostic_record_started = std.time.nanoTimestamp();''',1);s=s.replace('                    vulkan_compute.vulkan_run_prepared_dispatch(rt, dispatch_cmd);','                    vulkan_compute.vulkan_run_prepared_dispatch(rt, dispatch_cmd);\n                    diagnostic_record_ns += std.time.nanoTimestamp() - diagnostic_record_started;',1)
needle='            rt.submit_recorded_replay() catch |err| {';assert s.count(needle)==1;s=s.replace(needle,'            diagnostic_submit = rt.submit_recorded_replay_timed() catch |err| {',1);p.write_text(s)
subprocess.run(['zig','fmt',*[str(root/f) for f in files]],check=True)
(out/'binding-instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--',*files]))
