"""Retain the bounded descriptor-cache attribution and its physical controls."""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path.cwd()
SCRATCH = ROOT / 'bench/out/vulkan-bindings/20261004'
REPORT = ROOT / 'reports/benchmarks/amd-vulkan/20261004-binding-attribution'
REPORT.mkdir(parents=True, exist_ok=True)


def write(name: str, value: object) -> None:
    (REPORT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def identity(path: pathlib.Path) -> dict[str, object]:
    return {'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def phases(text: str) -> list[dict[str, int]]:
    return [dict((key, int(value)) for key, value in re.findall(r'(\w+)=(-?\d+)', line)) for line in text.splitlines() if line.startswith('DOE_BINDING_PHASE ')]


def aggregate(rows: list[dict[str, int]]) -> dict[str, int]:
    result = collections.Counter()
    for row in rows:
        result.update(row)
    return dict(result)


text = (SCRATCH / 'umap.log').read_text(encoding='utf-8')
rows = phases(text)
assert len(rows) == 2004
operations = []
for index in range(4):
    group = rows[index * 501:(index + 1) * 501]
    totals = aggregate(group)
    assert totals['calls'] == 1000 and totals['active'] == 998
    assert totals['misses'] == totals['updates'] == totals['pools'] == 2
    assert all(row['misses'] == row['updates'] == row['allocations'] == 0 for row in group[1:])
    operations.append({'sampleKind': 'warmup' if index == 0 else 'measured', 'totals': totals, 'firstComputeSubmission': group[0], 'firstRepeatedComputeSubmission': group[1], 'repeatedComputeTotals': aggregate(group[1:-1]), 'finalCopySubmission': group[-1]})
results_line = next(line for line in text.splitlines() if line.startswith('DOE_UMAP_SGD_BENCHMARK='))
workload_result = json.loads(results_line.split('=', 1)[1])
assert len(workload_result['samples']) == 4
assert all(sample['oracle']['pass'] for sample in workload_result['samples'])
assert len({sample['outputSha256'] for sample in workload_result['samples']}) == 1
write('umap-attribution.json', {'classification': 'instrumented-diagnostic', 'operations': operations, 'totals': aggregate(rows), 'instrumentedWorkloadResult': workload_result, 'diagnosticPatch': 'binding-instrumentation.patch.gz', 'counterDefinitions': {'calls': 'vk_descriptors.prepare invocations', 'active': 'initial resolved identity matches the current active descriptor state', 'cached': 'initial resolved identity selects a retained descriptor state before miss preparation', 'misses': 'initial cache lookup requires resource/descriptor preparation; not a claim every possible miss ends with a native update', 'allocations': 'five temporary collection capacity requests plus one retained identity allocation per initial miss; excludes allocations in resource promotion, pipeline caches and driver internals', 'snapshots': 'vk_descriptor_identity.snapshot calls, including full generation/handle/extent comparisons', 'resolve_ns': 'time in cache.resolve_descriptor_state_hash; includes lookup and snapshot/match time', 'snapshot_ns': 'nested time in identity.snapshot; never add to resolve_ns', 'descriptors_ns': 'whole descriptors.prepare; includes nested resolution and miss work', 'prepare_ns': 'whole native recorded-dispatch preparation; includes descriptors.prepare', 'sync_ns': 'existing RecordedReplaySubmitTimings.sync_prepare_ns', 'driver_ns': 'existing RecordedReplaySubmitTimings.driver_submit_ns'}, 'limits': ['This serial diagnostic uses temporary process-local counters. No diagnostic globals or retained command pointers enter production.', 'Timer calls and per-submission diagnostic output perturb execution. Instrumented application latency is not acceptance evidence.', 'Nested intervals cannot be summed. GPU overlap need not be calibrated to observe cache hits or the local descriptor preparation interval.', 'Resource generation, backing handle, extent and texture layout checks are retained; no unchecked shortcut is proposed.']})

fixture_text = (SCRATCH / 'binding-reuse.log').read_text(encoding='utf-8')
cases = []
for block in fixture_text.split('DOE_BINDING_CASE_BEGIN=')[1:]:
    label = block.splitlines()[0]
    actual = next(json.loads(line) for line in block.splitlines() if line.startswith('{"case":'))
    cases.append({'case': label, 'output': actual, 'phases': phases(block)})
assert len(cases) == 12 and all(case['output']['pass'] for case in cases)
controls = {}
for name in ['binding-reuse-baseline', 'binding-reuse-dawn']:
    lines = (SCRATCH / (name + '.log')).read_text(encoding='utf-8').splitlines()
    values = [json.loads(line) for line in lines if line.startswith('{"case":')]
    assert len(values) == 12 and all(value['pass'] for value in values)
    assert [case['output'] for case in cases] == values
    provider = next(json.loads(line) for line in lines if line.startswith('{"provider":'))
    controls[name] = {'provider': provider, 'outputs': values}
write('binding-controls.json', {'classification': 'physical-buffer-binding-controls', 'diagnosticCases': cases, 'uninstrumentedControls': controls, 'limits': ['Independent literal expected outputs and pinned Dawn validate these buffer cases, not every texture, sampler, collision, allocation-failure or device-loss path.', 'No production change is retained, so this is characterization rather than a new runtime conformance claim.']})

source_paths = ['runtime/zig/src/native/queue/doe_queue_submit_vulkan.zig', 'runtime/zig/src/native/vulkan/vulkan_compute_native.zig', 'runtime/zig/src/backend/vulkan/vk_descriptors.zig', 'runtime/zig/src/backend/vulkan/vk_descriptor_identity.zig', 'runtime/zig/src/backend/vulkan/vk_pipeline_cache.zig', 'runtime/zig/src/backend/vulkan/vk_pipeline.zig', 'runtime/zig/src/backend/vulkan/vk_upload.zig', 'bench/external-projects/umap-gpu/sgd-benchmark.harness.json', 'bench/external-projects/umap-gpu/sgd-benchmark.inputs.json', 'bench/external-projects/umap-gpu/sgd-benchmark.oracle.md', 'bench/external-projects/umap-gpu/sgd-benchmark.workload.test.ts']
binary_paths = ['bench/out/vulkan-bindings/20261004/diagnostic-runtime/lib/libwebgpu_doe.so', 'bench/out/vulkan-identifiers/20261004/runtime/lib/libwebgpu_doe.so', 'packages/doe-gpu/build/Release/doe_napi.node', 'bench/out/external-projects/umap-gpu/upstream/node_modules/webgpu/dist/linux-x64.dawn.node']
for name in source_paths[:1] + source_paths[2:4]:
    path = ROOT / name
    assert path.read_bytes() == (SCRATCH / (path.name + '.original')).read_bytes()
write('evidence.json', {'classification': 'diagnostic-source-workspace-attribution', 'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'sourceInputs': [identity(ROOT / name) for name in source_paths], 'executables': [identity(ROOT / name) | {'custody': 'local; native binaries not duplicated into tracked report'} for name in binary_paths], 'upstreamCommit': '7884b287f49bc057df7e0856c5539f130a20e0ad', 'hardware': {'adapter': 'Radeon 8060S Graphics RADV STRIX_HALO', 'driver': 'Mesa 26.0.3-1ubuntu1', 'backend': 'Vulkan'}, 'toolchain': {'zig': '0.15.2', 'node': subprocess.check_output(['node', '--version'], text=True).strip()}, 'decision': {'stopUmapBindingOptimization': True, 'productionCandidateEvaluated': False, 'productionBehaviorChanged': False, 'instrumentationRemoved': True, 'O3RejectionPreserved': True, 'applicationPerformanceAdvantageEstablished': False, 'umapRole': 'regression workload'}, 'commands': json.loads((SCRATCH / 'commands.json').read_text(encoding='utf-8')), 'buildCommand': 'zig build dropin -Doptimize=ReleaseFast --prefix <diagnostic-runtime> from runtime/zig', 'uninstrumentedControlCommands': ['DOE_WEBGPU_LIB=<accepted-runtime> node <binding-reuse.mjs>', 'DOE_BINDING_PROVIDER=<pinned Dawn module> node <binding-reuse.mjs>'], 'nextWorkloadSelection': {'application': 'Doppler full Gemma 3 270M text generation on Node/Vulkan', 'modelId': 'gemma-3-270m-it-q4k-ehf16-af32', 'status': 'selected; new model/prompt/provider contract and performance limits must be frozen before execution', 'criteriaToFreeze': ['First streamed useful token and final requested completion', 'Cold loading and retained-device generation separately', 'Logit/tokens, stopping and cancellation correctness with matched provider work', 'Complete-operation median/tail, peak memory, failures and cleanup', 'Instrumentation-disabled alternating candidate acceptance'], 'priorEvidenceBoundary': 'Retired provider-compare and Electron qualification contracts are not reopened and grant no acceptance credit.'}})
for name in ['umap.log', 'binding-reuse.log', 'binding-reuse-baseline.log', 'binding-reuse-dawn.log', 'build.log', 'binding-instrumentation.patch', 'binding-reuse.mjs', 'instrument.py', 'curate.py']:
    (REPORT / (name + '.gz')).write_bytes(gzip.compress((SCRATCH / name).read_bytes(), mtime=0))
print('curated', REPORT.relative_to(ROOT))
