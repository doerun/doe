#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <time.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>
#define CAPACITY 100000
struct Row {char name[32]; uint64_t begin,end; uint32_t count; int32_t result;};
struct Store {_Atomic uint64_t next; struct Row rows[CAPACITY];};
static struct Store *store;
static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000ull+t.tv_nsec;}
static void record(const char *name,uint64_t begin,uint64_t end,uint32_t count,int32_t result){if(!store){const char *base=getenv("DOE_VK_BOUNDARIES_OUT");if(!base)return;char path[4096];snprintf(path,sizeof(path),"%s.%d.bin",base,getpid());int fd=open(path,O_CREAT|O_RDWR|O_EXCL,0600);if(fd<0)abort();if(ftruncate(fd,sizeof(struct Store)))abort();store=mmap(NULL,sizeof(struct Store),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);close(fd);if(store==MAP_FAILED)abort();}uint64_t i=atomic_fetch_add(&store->next,1);if(i<CAPACITY){struct Row *r=&store->rows[i];snprintf(r->name,sizeof(r->name),"%s",name);r->begin=begin;r->end=end;r->count=count;r->result=result;}}
#define RESULT_HOOK(NAME,ARGS,PASS,COUNT) VKAPI_ATTR VkResult VKAPI_CALL NAME ARGS {static PFN_##NAME original;if(!original)original=dlsym(dlopen("libvulkan.so.1",RTLD_NOW|RTLD_LOCAL),#NAME);uint64_t begin_ns=now();VkResult result=original PASS;uint64_t end_ns=now();record(#NAME,begin_ns,end_ns,COUNT,result);return result;}
RESULT_HOOK(vkQueueSubmit,(VkQueue q,uint32_t n,const VkSubmitInfo *s,VkFence f),(q,n,s,f),n)
RESULT_HOOK(vkBeginCommandBuffer,(VkCommandBuffer b,const VkCommandBufferBeginInfo *i),(b,i),1)
RESULT_HOOK(vkEndCommandBuffer,(VkCommandBuffer b),(b),1)
RESULT_HOOK(vkResetCommandBuffer,(VkCommandBuffer b,VkCommandBufferResetFlags f),(b,f),1)
RESULT_HOOK(vkAllocateCommandBuffers,(VkDevice d,const VkCommandBufferAllocateInfo *i,VkCommandBuffer *b),(d,i,b),i->commandBufferCount)
RESULT_HOOK(vkWaitSemaphores,(VkDevice d,const VkSemaphoreWaitInfo *i,uint64_t t),(d,i,t),i->semaphoreCount)
RESULT_HOOK(vkWaitForFences,(VkDevice d,uint32_t n,const VkFence *f,VkBool32 a,uint64_t t),(d,n,f,a,t),n)
RESULT_HOOK(vkQueueWaitIdle,(VkQueue q),(q),1)
RESULT_HOOK(vkDeviceWaitIdle,(VkDevice d),(d),1)
