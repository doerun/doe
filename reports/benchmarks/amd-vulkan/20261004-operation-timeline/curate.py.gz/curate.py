"""Retain this bounded operation experiment without copying provider binaries."""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

ROOT = pathlib.Path.cwd()
SCRATCH = ROOT / 'bench/out/vulkan-operation/20261004'
REPORT = ROOT / 'reports/benchmarks/amd-vulkan/20261004-operation-timeline'
REPORT.mkdir(parents=True, exist_ok=True)


def write(name: str, payload: object) -> None:
    (REPORT / name).write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def retain(path: pathlib.Path, name: str | None = None) -> None:
    (REPORT / (name or (path.name + '.gz'))).write_bytes(gzip.compress(path.read_bytes(), mtime=0))


def identity(path: pathlib.Path) -> dict[str, object]:
    return {'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


policy = json.loads((SCRATCH / 'evaluation-policy.json').read_text())
write('evaluation-policy.json', policy)
cohorts = {}
for name in policy['cohortOrder']:
    path = ROOT / f'bench/out/external-projects/umap-gpu/20261004-operation-{name}'
    raw = json.loads((path / 'raw-benchmark.json').read_text())
    receipt = json.loads((path / 'receipt-summary.json').read_text())
    cohorts[name] = {'lanes': {lane: data['summary'] for lane, data in receipt['laneSummaries'].items()}, 'comparison': receipt['comparison'], 'decision': receipt['decision']}
    for artifact in ['raw-benchmark.json', 'receipt-summary.json']:
        retain(path / artifact, name + '-' + artifact + '.gz')
pairs = []
for number in [1, 2]:
    before = cohorts[f'baseline-{number}']['lanes']['D0']
    after = cohorts[f'candidate-{number}']['lanes']['D0']
    ratios = {key: {q: before[key][q] / after[key][q] for q in ['p50', 'p95', 'p99']} for key in ['selectedOperationLatencyMs', 'cleanProcessLatencyMs']}
    regressions = {key: {q: after[key][q] / before[key][q] - 1 for q in ['p50', 'p95', 'p99']} for key in ['selectedOperationLatencyMs', 'cleanProcessLatencyMs']}
    regressions['peakProcessTreeRssBytes'] = after['peakProcessTreeRssBytes'] / before['peakProcessTreeRssBytes'] - 1
    pairs.append({'pair': number, 'speedupRatios': ratios, 'regressionFractions': regressions, 'materialGain': all(ratios['selectedOperationLatencyMs'][q] >= policy['minimumMaterialSpeedupRatio'] for q in ['p50', 'p95'])})
write('application-comparison.json', {'classification': 'diagnostic', 'decision': 'reject-addon-O3; no repeatable material complete-operation gain', 'candidateRetained': False, 'cohorts': cohorts, 'pairs': pairs, 'limitations': ['Existing populated disk caches; fresh processes are not empty-cache measurements.', 'All ordinary cohorts run sequentially without timeline, native observer, submission breakdown, or GPU timestamp instrumentation.', 'A favorable individual Doe/Dawn cohort does not establish repeatable replacement value.']})

phase_rows = {}
for label in ['current-doe', 'optimized-doe', 'dawn', 'native4-doe']:
    path = SCRATCH / f'api-{label}.json'
    data = json.loads(path.read_text())
    assert not data['overflow']
    operations = []
    group = []
    destroys = 0
    for row in data['rows']:
        if row['name'].startswith(('gpu.', 'adapter.')):
            continue
        group.append(row)
        if row['name'] != 'buffer.destroy':
            continue
        destroys += 1
        if destroys % 10:
            continue
        durations = collections.defaultdict(float)
        counts = collections.Counter()
        waits = collections.defaultdict(float)
        for event in group:
            durations[event['name']] += (event['end'] - event['begin']) / 1e6
            counts[event['name']] += 1
            if 'settled' in event:
                waits[event['name']] += (event['settled'] - event['begin']) / 1e6
        operations.append({'sampleKind': 'warmup' if not operations else 'measured', 'firstObservedResourceToFinalDestroyMs': (group[-1]['end'] - group[0]['begin']) / 1e6, 'synchronousCallMs': dict(durations), 'promiseThroughSettlementMs': dict(waits), 'callCounts': dict(counts), 'firstSubmitMs': next((event['end'] - event['begin']) / 1e6 for event in group if event['name'] == 'queue.submit')})
        group = []
    assert len(operations) == 4
    phase_rows[label] = {'operations': operations, 'diagnostics': data.get('diagnostics'), 'eventCount': len(data['rows'])}
    retain(path)

native_path = next(SCRATCH.glob('*.decoded.json'))
native = json.loads(native_path.read_text())
api = json.loads((SCRATCH / 'api-native4-doe.json').read_text())
origin = api['origin']
intervals = [(origin + row['begin'], origin + row['end']) for row in api['rows'] if row['name'] == 'queue.submit']
joined = []
for row in native['rows']:
    if row['name'] == 'vkQueueSubmit':
        assert row['result'] == 0
        matched = [i for i, (begin, end) in enumerate(intervals) if begin <= row['begin'] <= row['end'] <= end]
        assert len(matched) == 1
        joined.append({'apiSubmission': matched[0], 'driverMs': (row['end'] - row['begin']) / 1e6})
assert len(joined) == len(intervals) == 2004
native_totals = {}
for name in sorted({row['name'] for row in native['rows']}):
    rows = [row for row in native['rows'] if row['name'] == name]
    native_totals[name] = {'calls': len(rows), 'totalMs': sum(row['end'] - row['begin'] for row in rows) / 1e6, 'results': sorted({row['result'] for row in rows})}
retain(native_path, 'native-boundaries.json.gz')
write('operation-timeline.json', {'classification': 'instrumented-diagnostic', 'api': phase_rows, 'nativeBoundaryTotals': native_totals, 'driverSubmissionsMatchedToApiIntervals': len(joined), 'clockJoin': 'Linux monotonic host clock; every driver submit falls inside exactly one observed queue.submit interval.', 'limits': ['Public intervals include API validation, bridge work, native preparation and driver calls; existing submitBreakdownNs separately observes preparation/replay/native submit/wait.', 'Nested API/native intervals must not be summed. API promise settlement includes synchronous call time.', 'GPU timestamps have no calibrated common host origin. They establish pass durations only; no disjoint CPU/GPU attribution by subtraction.', 'Resource-to-destroy spans omit code outside the observed calls and are not the frozen complete-operation timing. Snapshot serialization adds diagnostic overhead.', 'Native command-buffer creation counts do not prove host malloc counts; per-operation physical allocation attribution remains incomplete.', 'Internal compiler cache misses are not separately counted; first/repeated pipeline timings are observations, not inferred cache-hit proof.']})

gpu = {}
for label in ['gpu-current-doe', 'gpu-current-dawn', 'gpu-baseline-doe']:
    rows = []
    for line in (SCRATCH / (label + '.log')).read_text().splitlines():
        if 'DOE_GPU_PROFILE=' in line:
            data = json.loads(line.split('DOE_GPU_PROFILE=', 1)[1])
            rows.append({'sampleKind': 'warmup' if not rows else 'measured', 'epochs': len(data['rows']), 'sgdPassTotalMs': sum(x['sgdNs'] for x in data['rows']) / 1e6, 'applyPassTotalMs': sum(x['applyNs'] for x in data['rows']) / 1e6})
    gpu[label] = rows
write('gpu-durations.json', {'classification': 'instrumented-pass-duration-diagnostic', 'timestampQuantizationDisabledForDawn': True, 'samples': gpu, 'limits': ['Query resolution, timestamp copies and extra readback change execution.', 'No absolute GPU/host clock calibration; no claimed execution improvement or summed critical-path attribution.']})

compiler = []
for path in sorted(SCRATCH.glob('compiler-*.log')):
    log = path.read_text()
    allocation = json.loads(re.search(r'DOE_COMPILER_ALLOCATION=(\{.*\})', log)[1])
    text = log.splitlines()[-1].split()
    compiler.append({'cohort': path.stem, 'shader': text[0], 'target': text[1], 'p50Us': float(text[2]), 'p95Us': float(text[3]), 'p99Us': float(text[4]), 'outputBytes': int(text[5]), 'backingAllocatorObservation': allocation})
write('compiler-cost.json', {'classification': 'diagnostic', 'cohortOrder': ['previous', 'current', 'current', 'previous'], 'iterations': 500, 'warmup': 50, 'samples': compiler, 'decision': 'No compiler change in this candidate. Earlier slower apply-forces samples remain unresolved; these cohorts do not consistently reproduce them.', 'priorEvidence': '../20261004-identifiers-subgroups/compiler-costs.json'})

for path in sorted(SCRATCH.glob('*.log')):
    retain(path)
for path in sorted(SCRATCH.glob('compiler-*.ndjson')):
    retain(path)
for name in ['timeline-provider.mjs', 'probe.py', 'vulkan-boundaries.c', 'cc-optimized']:
    retain(SCRATCH / name, name + '.gz')
retain(ROOT / 'bench/out/vulkan-generated/20261004/profile-provider.mjs', 'timestamp-provider.mjs.gz')
retain(ROOT / 'bench/out/external-projects/doppler/20261004-operation-addon/result.json', 'doppler-result.json.gz')
write('build-metadata.json', json.loads((ROOT / 'bench/out/vulkan-identifiers/20261004/runtime/share/doe-build-metadata.json').read_text()))
paths = ['packages/doe-gpu/scripts/build-addon.js', 'packages/doe-gpu/binding.gyp', 'runtime/bridge/webgpu-addon/doe_napi_queue.c', 'runtime/zig/src/native/queue/doe_queue_submit_vulkan.zig', 'runtime/zig/src/backend/vulkan/vk_upload.zig', 'config/backend-runtime-policy.json', 'bench/external-projects/umap-gpu/sgd-benchmark.harness.json', 'bench/external-projects/umap-gpu/sgd-benchmark.inputs.json', 'bench/external-projects/umap-gpu/sgd-benchmark.oracle.md', 'bench/external-projects/umap-gpu/sgd-benchmark.workload.test.ts', 'bench/external-projects/umap-gpu/run-sgd-benchmark.mjs']
binaries = ['bench/out/external-projects/umap-gpu/upstream/node_modules/webgpu/dist/linux-x64.dawn.node', 'bench/out/vulkan-identifiers/20261004/runtime/lib/libwebgpu_doe.so', 'bench/out/vulkan-operation/20261004/original-addon.node', 'bench/out/vulkan-operation/20261004/baseline-addon.node', 'bench/out/vulkan-operation/20261004/candidate-addon.node', 'bench/out/vulkan-generated/20261004/fixed-allocation-tools/bin/doe-compilation-bench', 'bench/out/vulkan-identifiers/20261004/allocation-tools/bin/doe-compilation-bench', 'bench/out/vulkan-operation/20261004/vulkan-boundaries.so']
write('evidence.json', {'classification': 'diagnostic-source-workspace-experiment', 'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'upstreamCommit': '7884b287f49bc057df7e0856c5539f130a20e0ad', 'sourceInputs': [identity(ROOT / name) for name in paths], 'executables': [identity(ROOT / name) | {'custody': 'local ignored artifacts; not a portable release or installed-package qualification'} for name in binaries], 'decision': {'candidateRetained': False, 'baselineAddonRestored': True, 'productionRuntimeUnchanged': True, 'materialApplicationAdvantageEstablished': False, 'identifierAdmissionPreserved': True, 'hoistingAndSubgroupRejectionsPreserved': True}, 'correctness': {'ordinaryCohorts': 4, 'cleanProcessesPerLanePerCohort': 10, 'lanesPerCohort': 4, 'allCohortsRequireAllPassSucceeded': True, 'combinedSuitePassed': 5854, 'combinedSuiteSkipped': 22, 'candidateShaderRender': 'pass', 'candidateCommandOwnership': 'pass', 'candidateRenderOwnership': 'pass', 'selectedDopplerKernelParity': 'pass; not full inference'}, 'toolchain': {'zig': '0.15.2', 'node': subprocess.check_output(['node', '--version'], text=True).strip(), 'cc': subprocess.check_output(['cc', '--version'], text=True).splitlines()[0]}, 'commands': ['node packages/doe-gpu/scripts/build-addon.js', 'CC=<cc-optimized wrapper> node packages/doe-gpu/scripts/build-addon.js', 'DOE_WEBGPU_LIB=<retained runtime> node bench/external-projects/umap-gpu/run-sgd-benchmark.mjs --clean-process-runs 10 --run-id 20261004-operation-<cohort> --require-all-pass', 'zig build test test-full test-wgsl -Doptimize=ReleaseFast --summary all', '<compiler tool> --shader-path <unchanged upstream shader> --shader-name <name> --shader-tier external --target spirv --iterations 500 --warmup 50 --out <ndjson>'], 'limitations': ['The original addon and fresh baseline rebuild have identical hashes; no stale-source difference is credited.', 'No accepted production performance change, universal superiority, full WGSL conformance, full inference, installed archive qualification or physical device-loss claim.', 'Initial LD_PRELOAD resolution failed because the runtime loads Vulkan locally. Failure log is retained; successful observation explicitly resolves libvulkan.so.1.']})
assert hashlib.sha256((ROOT / 'packages/doe-gpu/build/Release/doe_napi.node').read_bytes()).hexdigest() == policy['artifacts']['baseline-addon.node']
print('curated', REPORT.relative_to(ROOT))
