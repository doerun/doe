import {writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const provider=await import(pathToFileURL(process.env.DOE_TIMELINE_PROVIDER).href);
export const globals=provider.globals;
export const providerDiagnostics=provider.providerDiagnostics;
const rows=[];
const start=process.hrtime.bigint();
const now=()=>Number(process.hrtime.bigint()-start);
const limit=100000;
let overflow=false;
let destroyed=0;
function flush(){writeFileSync(process.env.DOE_TIMELINE_OUT,JSON.stringify({kind:"diagnostic-api-timeline",clock:"process.hrtime.bigint",origin:Number(start),provider:process.env.DOE_TIMELINE_PROVIDER,overflow,rows,diagnostics:provider.providerDiagnostics?.()}));}
function observe(name,fn){
 const begin=now();let row;
 try{const value=fn();row={name,begin,end:now()};if(rows.length<limit)rows.push(row);else overflow=true;
 if(name==="buffer.destroy" && ++destroyed%10===0)flush();
 if(value&&typeof value.then==='function')return value.then(result=>{row.settled=now();return result;},error=>{row.settled=now();row.error=String(error);throw error;});return value;
 }catch(error){row={name,begin,end:now(),error:String(error)};if(rows.length<limit)rows.push(row);else overflow=true;throw error;}
}
function instrument(object,label,methods){
 for(const method of methods){const original=object[method];if(typeof original!=='function')continue;
 object[method]=(...args)=>observe(`${label}.${method}`,()=>original.apply(object,args));
 }return object;
}
function deviceWrap(device){
 instrument(device.queue,'queue',['writeBuffer','submit','onSubmittedWorkDone']);
 instrument(device,'device',['createShaderModule','createComputePipeline','createBindGroup','createCommandEncoder','createBuffer','destroy']);
 const make=device.createCommandEncoder.bind(device);
 device.createCommandEncoder=(...args)=>{const encoder=make(...args);instrument(encoder,'encoder',['beginComputePass','finish','copyBufferToBuffer']);const begin=encoder.beginComputePass.bind(encoder);encoder.beginComputePass=(...args)=>instrument(begin(...args),'pass',['setPipeline','setBindGroup','dispatchWorkgroups','end']);return encoder;};
 const buffer=device.createBuffer.bind(device);
 device.createBuffer=(...args)=>instrument(buffer(...args),'buffer',['mapAsync','getMappedRange','unmap','destroy']);
 return device;
}
export function create(...args){const gpu=provider.create(...args);const request=gpu.requestAdapter.bind(gpu);gpu.requestAdapter=async (...args)=>{const adapter=await observe('gpu.requestAdapter',()=>request(...args));const device=adapter.requestDevice.bind(adapter);adapter.requestDevice=async (...args)=>deviceWrap(await observe('adapter.requestDevice',()=>device(...args)));return adapter;};return gpu;}
process.once('exit',()=>writeFileSync(process.env.DOE_TIMELINE_OUT,JSON.stringify({kind:'diagnostic-api-timeline',clock:'process.hrtime.bigint',provider:process.env.DOE_TIMELINE_PROVIDER,overflow,rows,diagnostics:provider.providerDiagnostics?.()})));
