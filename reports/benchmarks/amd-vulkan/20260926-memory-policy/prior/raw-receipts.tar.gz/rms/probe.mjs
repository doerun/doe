import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { bootstrapNodeWebGPUProvider } from '/home/x/deco/doe/packages/doe-gpu/src/node-webgpu.js';
import { instrument } from '/home/x/deco/doe/bench/out/doppler-search/20260920-profile/instrument.mjs';
const selected = process.env.DOPPLER_TIMING_PROVIDER;
const destination = process.env.DOPPLER_TIMING_OUTPUT;
await fs.mkdir(destination);
const moduleUrl = selected === 'doe' ? 'file:///home/x/deco/doe/packages/doe-gpu/src/native.js' : 'file:///home/x/deco/doe/bench/node_modules/webgpu/index.js';
const provider = await bootstrapNodeWebGPUProvider(moduleUrl, { provider: {
 id: selected, kind: 'module', module: moduleUrl,
 gpu: {kind:'factory', path:'create', args:[['backend=vulkan','enable-dawn-features=allow_unsafe_apis']]},
 globals: Object.fromEntries(['GPUBufferUsage','GPUShaderStage','GPUMapMode','GPUTextureUsage'].map(key => [key, `globals.${key}`])),
} });
const device = await provider.session.adapter.requestDevice({ requiredFeatures: ['timestamp-query', 'subgroups'] });
const U = GPUBufferUsage;
const resources = [];
function buffer(size, usage) {
 const value = device.createBuffer({size, usage}); resources.push(value); return value;
}
const tokens = 96;
const width = 1024;
const count = tokens * width;
const fused = Number(process.env.RMS_FUSED ?? 0);
const uniform = buffer(32, U.UNIFORM | U.COPY_DST);
const data = Float32Array.from({length:count}, (_, i) => (i % 101 - 50) / 32);
const residualData = Float32Array.from(data, x => x / 4);
const input = buffer(data.byteLength, U.STORAGE | U.COPY_DST);
const residual = buffer(data.byteLength, U.STORAGE | U.COPY_DST);
const weight = buffer(width * 2, U.STORAGE | U.COPY_DST);
const output = buffer(data.byteLength, U.STORAGE | U.COPY_SRC);
const prenorm = buffer(data.byteLength, U.STORAGE | U.COPY_SRC);
const readback = buffer(data.byteLength, U.COPY_DST | U.MAP_READ);
device.queue.writeBuffer(input,0,data);
device.queue.writeBuffer(residual,0,residualData);
device.queue.writeBuffer(weight,0,new Uint32Array(width / 2).fill(0x3c003c00));
const uniforms = new ArrayBuffer(32);
new Uint32Array(uniforms).set([width,tokens,0,0,tokens,0,0,0]);
new Float32Array(uniforms)[2] = 1e-6;
new Float32Array(uniforms)[5] = 1;
device.queue.writeBuffer(uniform,0,uniforms);
const shader = await fs.readFile('/home/x/deco/doe/bench/out/doppler-search/20260920-shader-capture/0-doe/shader-5.wgsl','utf8');
const layout = device.createBindGroupLayout({entries:['uniform','read-only-storage','read-only-storage','storage','read-only-storage','storage'].map((type,binding)=>({binding, visibility:GPUShaderStage.COMPUTE, buffer:{type}}))});
const pipeline = device.createComputePipeline({label:'rmsnorm_subgroup',layout:device.createPipelineLayout({bindGroupLayouts:[layout]}),compute:{module:device.createShaderModule({code:shader}),entryPoint:'main_subgroup',constants:{RMS_NORM_OFFSET:0,WEIGHT_IS_F16:1,PRE_RESIDUAL:fused,OUTPUT_PRENORM:fused}}});
const bindings = device.createBindGroup({layout,entries:[uniform,input,weight,output,residual,prenorm].map((buffer,binding)=>({binding,resource:{buffer}}))});
const expected = new Float32Array(count);
for (let token = 0; token < tokens; token++) {
 let sum = 0;
 for (let j = 0; j < width; j++) {const x = data[token*width+j] * (fused ? 1.25 : 1); sum += x*x;}
 for (let j = 0; j < width; j++) expected[token*width+j] = data[token*width+j] * (fused ? 1.25 : 1) / Math.sqrt(sum / width + 1e-6);
}
const profile=instrument(device);
try {
 for(let r=0;r<6;r++) {
  if(r) await profile.start();
  const encoder=device.createCommandEncoder({label:'rmsnorm'});
  const pass=encoder.beginComputePass(); pass.setPipeline(pipeline);pass.setBindGroup(0,bindings);
  for(let i=0;i<100;i++) {
   pass.dispatchWorkgroups(tokens);
  }
  pass.end();
  encoder.copyBufferToBuffer(output,0,readback,0,data.byteLength);
  device.queue.submit([encoder.finish()]);
  await readback.mapAsync(GPUMapMode.READ);
  const actual=new Float32Array(readback.getMappedRange());
  for(let i=0;i<count;i++) assert(Math.abs(actual[i] - expected[i]) < 1e-5, `index ${i}: ${actual[i]} vs ${expected[i]}`);
  readback.unmap();
  if(r) await fs.writeFile(`${destination}/profile-${r}.json`,JSON.stringify(await profile.stop()));
 }
 console.log('PASS',selected);
} finally {
 profile.close(); for(const r of resources.reverse())r.destroy(); device.destroy(); await provider.session.close();
}
