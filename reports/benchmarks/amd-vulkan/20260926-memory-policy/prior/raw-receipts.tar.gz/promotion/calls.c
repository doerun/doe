#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdlib.h>

#include <stdio.h>
#include <time.h>
#define NEXT(name) PFN_##name real = (PFN_##name)dlsym(dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL), #name); if (!real) abort()
static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_REALTIME,&t); return t.tv_sec*1000.0+t.tv_nsec/1e6; }
VKAPI_ATTR void VKAPI_CALL vkCmdCopyBuffer(VkCommandBuffer cb, VkBuffer src, VkBuffer dst, uint32_t count, const VkBufferCopy *regions) {
 NEXT(vkCmdCopyBuffer); uint64_t bytes=0; for(uint32_t i=0;i<count;i++) bytes+=regions[i].size;
 fprintf(stderr,"{\"native\":\"copy\",\"timeMs\":%.3f,\"bytes\":%lu}\n",now_ms(),bytes);
 real(cb,src,dst,count,regions);
}
VKAPI_ATTR VkResult VKAPI_CALL vkWaitForFences(VkDevice d,uint32_t count,const VkFence *f,VkBool32 all,uint64_t timeout) {
 NEXT(vkWaitForFences); double begin=now_ms(); VkResult r=real(d,count,f,all,timeout);
 fprintf(stderr,"{\"native\":\"wait\",\"timeMs\":%.3f,\"durationMs\":%.3f}\n",now_ms(),now_ms()-begin); return r;
}
VKAPI_ATTR VkResult VKAPI_CALL vkAllocateMemory(VkDevice d,const VkMemoryAllocateInfo *info,const VkAllocationCallbacks *a,VkDeviceMemory *m) {
 NEXT(vkAllocateMemory); VkResult r=real(d,info,a,m);
 fprintf(stderr,"{\"native\":\"allocation\",\"timeMs\":%.3f,\"bytes\":%lu,\"type\":%u,\"result\":%d}\n",now_ms(),info->allocationSize,info->memoryTypeIndex,r); return r;
}
