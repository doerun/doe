const std = @import("std");
const runtime = @import("src/backend/vulkan/native_runtime.zig");
const upload = @import("src/backend/vulkan/vk_upload.zig");
const c = @import("src/backend/vulkan/vk_constants.zig");
extern fn audit_begin() void;
extern fn audit_fail(c_int) void;
extern fn audit_buffers() i64;
extern fn audit_memories() i64;
extern fn audit_mappings() i64;
extern fn audit_end() void;
const resources = @import("src/backend/vulkan/vk_resources.zig");
const BYTES = 32768;

test "promotion allocation failures release native objects" {
    for (1..5) |step| {
        var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
        audit_begin();
        audit_fail(@intCast(step));
        const result = resources.create_compute_buffer(&rt, BYTES, true);
        audit_fail(0);
        rt.deinit();
        try std.testing.expectError(error.InvalidState, result);
        try std.testing.expectEqual(@as(i64, 0), audit_buffers());
        try std.testing.expectEqual(@as(i64, 0), audit_memories());
        try std.testing.expectEqual(@as(i64, 0), audit_mappings());
        audit_end();
    }
}

test "promotion retains mapped contents and conservatively copies unknown properties" {
    var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
    audit_begin();
    const original = try resources.create_compute_buffer(&rt, BYTES, true);
    try std.testing.expect((original.memory_property_flags & c.VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) != 0);
    const bytes = @as([*]u8, @ptrCast(original.mapped.?))[0..BYTES];
    for (bytes) |byte| try std.testing.expectEqual(@as(u8, 0), byte);
    @memset(bytes[4..20], 0xa7);
    try rt.compute_buffers.put(rt.allocator, 7, original);
    const retained = try resources.promote_compute_buffer_to_device_local(&rt, 7);
    try std.testing.expectEqual(original.buffer, retained.buffer.buffer);
    try std.testing.expectEqual(original.generation, retained.buffer.generation);
    try std.testing.expect(retained.retired_source == null);
    rt.compute_buffers.getPtr(7).?.memory_property_flags = 0;
    const copied = try resources.promote_compute_buffer_to_device_local(&rt, 7);
    try std.testing.expect(copied.buffer.buffer != original.buffer);
    try std.testing.expect(copied.buffer.generation != original.generation);
    const observed = try resources.capture_compute_buffer(&rt, std.testing.allocator, copied.buffer, 0, BYTES);
    defer std.testing.allocator.free(observed);
    try std.testing.expectEqualSlices(u8, bytes, observed);
    resources.release_compute_buffer(&rt, copied.retired_source.?);
    rt.deinit();
    try std.testing.expectEqual(@as(i64, 0), audit_buffers());
    try std.testing.expectEqual(@as(i64, 0), audit_memories());
    try std.testing.expectEqual(@as(i64, 0), audit_mappings());
    audit_end();
}
