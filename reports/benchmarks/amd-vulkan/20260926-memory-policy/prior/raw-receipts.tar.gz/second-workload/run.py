from pathlib import Path
import json,os,subprocess,sys,hashlib
repo=Path('/home/x/deco/doe');sys.path.insert(0,str(repo))
from bench.lib.compute_program_gpu_activity import detect_target,read_snapshot,reject_activity,read_boot_id
root=repo/'bench/out/doppler-search/20260925-excess/second-workload';target=detect_target()
for key in ('LD_PRELOAD','RADV_DEBUG','DOE_VULKAN_REQUIRED_SUBGROUP_SIZE','NODE_OPTIONS','DOE_PROGRAM_IDENTITY_TRACE_PATH','MESA_SPIRV_READ_PATH','MESA_SPIRV_DUMP_PATH','MESA_SHADER_CACHE_DISABLE'):
 if os.environ.get(key): raise RuntimeError(f'Diagnostic environment forbidden: {key}')
for index,variant in enumerate(['baseline','candidate','candidate','baseline']):
 library=repo/f'bench/out/doppler-search/20260925-excess/{variant}-native/lib/libwebgpu_doe.so'
 run_id=f'20260926-promotion-{index}-{variant}'
 command=['node','bench/external-projects/umap-gpu/run-sgd-benchmark.mjs','--run-id',run_id,'--clean-process-runs','1','--require-all-pass']
 before=read_snapshot(target);print('START',index,variant,flush=True)
 with (root/f'{index}-{variant}.log').open('w') as log:
  p=subprocess.run(command,cwd=repo,env=dict(os.environ,DOE_WEBGPU_LIB=str(library)),stdout=log,stderr=subprocess.STDOUT)
 after=read_snapshot(target);activity={'schemaVersion':2,'bootId':read_boot_id(),'target':target,'snapshots':[before,after]}
 try: reject_activity([before,after],target['pciDevice']);activity['admitted']=True
 except ValueError as e: activity['admitted']=False;activity['error']=str(e)
 (root/f'{index}-{variant}-activity.json').write_text(json.dumps(activity,indent=2)+'\n')
 (root/f'{index}-{variant}-execution.json').write_text(json.dumps({'command':command,'exitCode':p.returncode,'library':str(library),'librarySha256':hashlib.sha256(library.read_bytes()).hexdigest(),'artifacts':str(repo/'bench/out/external-projects/umap-gpu'/run_id)},indent=2)+'\n')
 print('END',index,variant,'exit',p.returncode,'activity',activity['admitted'],flush=True)
 if p.returncode or not activity['admitted']:sys.exit(1)
