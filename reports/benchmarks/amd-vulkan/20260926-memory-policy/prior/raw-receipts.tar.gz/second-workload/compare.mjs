import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {stats} from '/home/x/deco/doe/bench/shared/lib/stats.js';
const root='/home/x/deco/doe/bench/out/doppler-search/20260925-excess/second-workload';
const rows=[];let inputs,shape,baselineOutputs;
for(const [i,variant] of ['baseline','candidate','candidate','baseline'].entries()) {
 const execution=JSON.parse(await fs.readFile(`${root}/${i}-${variant}-execution.json`));
 const activity=JSON.parse(await fs.readFile(`${root}/${i}-${variant}-activity.json`));
 const raw=JSON.parse(await fs.readFile(`${execution.artifacts}/raw-benchmark.json`));
 assert.equal(execution.exitCode,0);assert(activity.admitted);assert(raw.decision.correctnessEvidence && raw.decision.replayEvidence);
 inputs ??= raw.immutableInputs;assert.deepEqual(raw.immutableInputs,inputs);
 assert.equal(raw.lanes.D0.probe.identity.provider.providerInfo.doeLibraryPath,execution.library);
 const lanes={};
 for(const name of ['W0','D0']) {
  const samples=raw.lanes[name].runs.flatMap(r=>r.benchmark.samples.filter(s=>s.sampleKind==='measured'));
  for(const s of samples){assert(s.oracle.pass);shape ??= s.dispatch;assert.deepEqual(s.dispatch,shape);}
  lanes[name]={latencyMs:stats(samples.map(s=>s.durationMs)),samplesMs:samples.map(s=>s.durationMs),outputHashes:[...new Set(samples.map(s=>s.outputSha256))],processTreePeakRssBytes:raw.lanes[name].summary.peakProcessTreeRssBytes};
 }
 baselineOutputs ??= lanes.D0.outputHashes;assert.deepEqual(lanes.D0.outputHashes,baselineOutputs);
 rows.push({index:i,variant,raw:`${execution.artifacts}/raw-benchmark.json`,librarySha256:execution.librarySha256,lanes});
}
const results={};for(const variant of ['baseline','candidate'])results[variant]=stats(rows.filter(r=>r.variant===variant).flatMap(r=>r.lanes.D0.samplesMs));
const report={classification:'local-diagnostic-not-release-claim',workload:'pinned-upstream-umap-sgd',checks:{oraclePassed:true,exactProviderReplayPassed:true,unchangedDoeOutputAcrossCandidate:true,inputAndDispatchShapeMatch:true,gpuActivityAdmitted:true},dispatchShape:shape,immutableInputs:inputs,results,rows,candidateOverBaselineMedian:results.candidate.median/results.baseline.median,candidateOverBaselineP95:results.candidate.p95/results.baseline.p95,conclusion:'No transferred speed advantage. Candidate central latency is higher in this small sample; a possible regression remains unresolved. Retain the reranker-only improvement scope.',limitations:['Two main fresh processes per Doe variant, three timed samples each; additional replay processes check correctness and are excluded from pooled timing.','The upstream harness polls process-tree RSS for both providers; this is its existing diagnostic method.','This small-buffer fixture does not establish application-scale performance or generality.','The runner prose has a fixed three-process limitation; actual process counts are recorded in contract and lane rows.']};
await fs.writeFile(`${root}/comparison.json`,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({results,ratios:[report.candidateOverBaselineMedian,report.candidateOverBaselineP95]},null,2));
