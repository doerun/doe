import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { bootstrapNodeWebGPUProvider } from '/home/x/deco/doe/packages/doe-gpu/src/node-webgpu.js';
import { instrument } from '/home/x/deco/doe/bench/out/doppler-search/20260920-profile/instrument.mjs';
const selected = process.env.DOPPLER_TIMING_PROVIDER;
const destination = process.env.DOPPLER_TIMING_OUTPUT;
await fs.mkdir(destination);
const moduleUrl = selected === 'doe' ? 'file:///home/x/deco/doe/packages/doe-gpu/src/native.js' : 'file:///home/x/deco/doe/bench/node_modules/webgpu/index.js';
const provider = await bootstrapNodeWebGPUProvider(moduleUrl, { provider: {
 id: selected, kind: 'module', module: moduleUrl,
 gpu: {kind:'factory', path:'create', args:[['backend=vulkan','enable-dawn-features=allow_unsafe_apis']]},
 globals: Object.fromEntries(['GPUBufferUsage','GPUShaderStage','GPUMapMode','GPUTextureUsage'].map(key => [key, `globals.${key}`])),
} });
const device = await provider.session.adapter.requestDevice({ requiredFeatures: ['timestamp-query', 'shader-f16'] });
const U = GPUBufferUsage;
const resources = [];
function buffer(size, usage) {
 const value = device.createBuffer({size, usage}); resources.push(value); return value;
}
const tokens = 96;
const width = 1024;
const columns = 1024;
const count = tokens * columns;
const uniform = buffer(32, U.UNIFORM | U.COPY_DST);
const data = Float32Array.from({length:tokens*width}, (_, i) => (i % 101 - 50) / 32);
const input = buffer(data.byteLength, U.STORAGE | U.COPY_DST);
const packed = new Uint32Array(columns * (width / 256) * 36);
for (let i = 0; i < packed.length; i += 36) {
 packed[i] = 0x00003c00;
 packed[i+1] = 0x01010101;
 packed[i+2] = 0;
 packed[i+3] = 0x01010101;
 packed.fill(0x11111111, i+4, i+36);
}
const weight = buffer(packed.byteLength, U.STORAGE | U.COPY_DST);
const output = buffer(count * 4, U.STORAGE | U.COPY_SRC);
const readback = buffer(count * 4, U.COPY_DST | U.MAP_READ);
device.queue.writeBuffer(input,0,data);
device.queue.writeBuffer(weight,0,packed);
const uniforms = new ArrayBuffer(32);
new Uint32Array(uniforms).set([tokens,columns,width,0,width/256,0,0,0]);
new Float32Array(uniforms)[3] = 1;
device.queue.writeBuffer(uniform,0,uniforms);
const shader = await fs.readFile('/home/x/deco/doe/bench/out/doppler-search/20260920-shader-capture/0-doe/shader-6.wgsl','utf8');
const layout = device.createBindGroupLayout({entries:['uniform','read-only-storage','read-only-storage','storage'].map((type,binding)=>({binding, visibility:GPUShaderStage.COMPUTE, buffer:{type}}))});
const pipeline = device.createComputePipeline({label:'matmul_q4_fused_widetile',layout:device.createPipelineLayout({bindGroupLayouts:[layout]}),compute:{module:device.createShaderModule({code:shader}),entryPoint:'main'}});
const bindings = device.createBindGroup({layout,entries:[uniform,input,weight,output].map((buffer,binding)=>({binding,resource:{buffer}}))});
const expected = new Float32Array(count);
for (let token = 0; token < tokens; token++) {
 let sum = 0;
 for (let j = 0; j < width; j++) sum += data[token*width+j];
 expected.fill(sum,token*columns,(token+1)*columns);
}
const profile=instrument(device);
try {
 for(let r=0;r<6;r++) {
  if(r) await profile.start();
  const encoder=device.createCommandEncoder({label:'q4'});
  const pass=encoder.beginComputePass(); pass.setPipeline(pipeline);pass.setBindGroup(0,bindings);
  for(let i=0;i<30;i++) {
   pass.dispatchWorkgroups(columns/256,tokens/4);
  }
  pass.end();
  encoder.copyBufferToBuffer(output,0,readback,0,count*4);
  device.queue.submit([encoder.finish()]);
  await readback.mapAsync(GPUMapMode.READ);
  const actual=new Float32Array(readback.getMappedRange());
  for(let i=0;i<count;i++) assert(Math.abs(actual[i] - expected[i]) < 1e-5, `index ${i}: ${actual[i]} vs ${expected[i]}`);
  readback.unmap();
  if(r) await fs.writeFile(`${destination}/profile-${r}.json`,JSON.stringify(await profile.stop()));
 }
 console.log('PASS',selected);
} finally {
 profile.close(); for(const r of resources.reverse())r.destroy(); device.destroy(); await provider.session.close();
}
