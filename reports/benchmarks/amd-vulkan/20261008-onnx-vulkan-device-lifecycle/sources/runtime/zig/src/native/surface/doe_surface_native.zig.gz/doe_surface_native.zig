// doe_surface_native.zig — WebGPU Surface C ABI for the Doe Vulkan backend.
//
// Metal surfaces are not exposed through this ABI (Metal uses CAMetalLayer natively).
// Vulkan path routes lifecycle calls to NativeVulkanRuntime surface methods.
//
// Platform VkSurface handles (XCB/Wayland/Xlib) must be attached via
// doeNativeSurfaceSetXcbHandle / doeNativeSurfaceSetWaylandHandle / doeNativeSurfaceSetXlibHandle before
// doeNativeSurfaceConfigure is called to enable a real VkSwapchainKHR.
// Headless placeholder presentation is not allowed on this path; configure
// and acquire fail explicitly until a real platform surface is attached.

const std = @import("std");
const error_scope = @import("../../runtime/diagnostics/error_scope.zig");
const log = std.log.scoped(.doe_surface_native);
const builtin = @import("builtin");
const has_vulkan = (builtin.os.tag == .linux);
const backend_surface_ops = @import("../../backend/dropin_surface_ops.zig");
const backend_resource_ops = @import("../../backend/dropin_resource_ops.zig");
const backend_contract = @import("../../contracts/backend.zig");
const native_types = @import("../support/doe_native_object_types.zig");
const native_shared = @import("../support/doe_native_shared_types.zig");
const native_helpers = @import("../support/doe_native_object_helpers.zig");
const native_rt_helpers = @import("../support/doe_native_runtime_helpers.zig");
const vk_surf = backend_surface_ops;
const vk_constants = if (has_vulkan) backend_resource_ops.vk_constants else struct {};
const vk_resources = if (has_vulkan) backend_resource_ops.vk_resources else struct {};
const texture_native = @import("../resource/doe_texture_sampler_native.zig");
const device_native = @import("../lifecycle/doe_instance_device_native.zig");

const alloc = native_helpers.alloc;
const make = native_helpers.make;
const cast = native_helpers.cast;
const toOpaque = native_helpers.toOpaque;
const model_gpu_types = @import("../../contracts/model/model_texture_value_types.zig");
const model_surface_control_types = @import("../../contracts/model/model_surface_control_types.zig");

const DoeDevice = native_types.DoeDevice;
const DoeInstance = native_types.DoeInstance;
const DoeTexture = native_types.DoeTexture;
const NativeVulkanRuntime = native_shared.NativeVulkanRuntime;

const MAGIC_SURFACE: u32 = 0xD0E1_0013;
const MAX_SURFACE_DESCRIPTOR_CHAIN_NODES: u32 = 16;

const WGPU_STATUS_SUCCESS: u32 = 0x00000001;
const WGPU_STATUS_ERROR: u32 = 0x00000002;
const WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUCCESS: u32 = 0x00000001;
const WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUBOPTIMAL: u32 = 0x00000002;
const WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_TIMEOUT: u32 = 0x00000003;
const WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_ERROR: u32 = 0x00000006;
const WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_OUTDATED: u32 = 0x00000004;

pub const DoeSurface = struct {
    pub const TYPE_MAGIC = MAGIC_SURFACE;
    magic: u32 = TYPE_MAGIC,
    ref_count: u32 = 1,
    backend: backend_contract.NativeBackendKind = .metal,
    handle: u64 = 0,
    instance_ref: ?*DoeInstance = null,
    vk_runtime_ref: ?*anyopaque = null,
    current_tex: ?*DoeTexture = null,
    device_ref: ?*DoeDevice = null,
    pending_xcb_connection: ?*anyopaque = null,
    pending_xcb_window: u32 = 0,
    pending_wayland_display: ?*anyopaque = null,
    pending_wayland_surface: ?*anyopaque = null,
    pending_xlib_display: ?*anyopaque = null,
    pending_xlib_window: u64 = 0,
};

const surface_procs = @import("../../full/surface/wgpu_surface_procs.zig");

fn retain_surface_instance(surf: *DoeSurface, inst_raw: ?*anyopaque) void {
    if (cast(DoeInstance, inst_raw)) |inst| {
        native_helpers.object_add_ref(DoeInstance, inst_raw);
        surf.instance_ref = inst;
    }
}

fn release_surface_instance(surf: *DoeSurface) void {
    if (surf.instance_ref) |inst| {
        @import("../lifecycle/doe_instance_device_native.zig").doeNativeInstanceRelease(toOpaque(inst));
        surf.instance_ref = null;
    }
}

fn capture_surface_descriptor(surf: *DoeSurface, desc_raw: ?*anyopaque) void {
    const raw = desc_raw orelse return;
    const desc: *const surface_procs.SurfaceDescriptor = @ptrCast(@alignCast(raw));
    var chain = desc.nextInChain;
    var visited: u32 = 0;
    while (chain) |node| : (visited += 1) {
        if (visited >= MAX_SURFACE_DESCRIPTOR_CHAIN_NODES) return;
        switch (node.sType) {
            surface_procs.SurfaceSourceXCBWindowSType => {
                const source: *const surface_procs.SurfaceSourceXCBWindow = @ptrCast(@alignCast(node));
                surf.pending_xcb_connection = source.connection;
                surf.pending_xcb_window = source.window;
            },
            surface_procs.SurfaceSourceWaylandSurfaceSType => {
                const source: *const surface_procs.SurfaceSourceWaylandSurface = @ptrCast(@alignCast(node));
                surf.pending_wayland_display = source.display;
                surf.pending_wayland_surface = source.surface;
            },
            surface_procs.SurfaceSourceXlibWindowSType => {
                const source: *const surface_procs.SurfaceSourceXlibWindow = @ptrCast(@alignCast(node));
                surf.pending_xlib_display = source.display;
                surf.pending_xlib_window = source.window;
            },
            else => {},
        }
        chain = node.next;
    }
}

fn attach_xcb_surface(surf: *DoeSurface, rt: *NativeVulkanRuntime) bool {
    if (surf.pending_xcb_connection == null) return false;
    const state = rt.surfaces.getPtr(surf.handle) orelse return false;
    if (state.vk_surface != 0) return true;
    const vk_handle = vk_surf.create_xcb_surface(rt.instance, surf.pending_xcb_connection, surf.pending_xcb_window) catch |err| {
        std.log.err("doe_surface_native: create_xcb_surface failed: {s}", .{@errorName(err)});
        return false;
    };
    state.vk_surface = vk_handle;
    state.platform = .xcb;
    return true;
}

fn attach_wayland_surface(surf: *DoeSurface, rt: *NativeVulkanRuntime) bool {
    if (surf.pending_wayland_display == null or surf.pending_wayland_surface == null) return false;
    const state = rt.surfaces.getPtr(surf.handle) orelse return false;
    if (state.vk_surface != 0) return true;
    const vk_handle = vk_surf.create_wayland_surface(rt.instance, surf.pending_wayland_display, surf.pending_wayland_surface) catch |err| {
        std.log.err("doe_surface_native: create_wayland_surface failed: {s}", .{@errorName(err)});
        return false;
    };
    state.vk_surface = vk_handle;
    state.platform = .wayland;
    return true;
}

fn attach_xlib_surface(surf: *DoeSurface, rt: *NativeVulkanRuntime) bool {
    if (surf.pending_xlib_display == null) return false;
    const state = rt.surfaces.getPtr(surf.handle) orelse return false;
    if (state.vk_surface != 0) return true;
    const vk_handle = vk_surf.create_xlib_surface(rt.instance, surf.pending_xlib_display, surf.pending_xlib_window) catch |err| {
        std.log.err("doe_surface_native: create_xlib_surface failed: {s}", .{@errorName(err)});
        return false;
    };
    state.vk_surface = vk_handle;
    state.platform = .xlib;
    return true;
}

fn attach_pending_platform_surface(surf: *DoeSurface, rt: *NativeVulkanRuntime) bool {
    if (attach_xcb_surface(surf, rt)) return true;
    if (attach_wayland_surface(surf, rt)) return true;
    if (attach_xlib_surface(surf, rt)) return true;
    return false;
}

fn bind_surface_runtime(surf: *DoeSurface, dev_raw: ?*anyopaque) bool {
    const dev = cast(DoeDevice, dev_raw) orelse return false;
    if (dev.backend != .vulkan) return false;
    const adapter = dev.adapter orelse return false;
    if (adapter.instance != surf.instance_ref) return false;
    const rt = native_rt_helpers.device_vk_runtime(dev) orelse return false;
    const rt_opaque: *anyopaque = @ptrCast(rt);
    if (surf.vk_runtime_ref) |existing| {
        if (existing != rt_opaque) {
            std.log.err("doe_surface_native: surface configured with a different Vulkan runtime", .{});
            return false;
        }
        _ = attach_pending_platform_surface(surf, rt);
        return true;
    }

    rt.create_surface(surf.handle) catch |err| {
        std.log.err("doe_surface_native: create_surface failed: {s}", .{@errorName(err)});
        return false;
    };
    surf.vk_runtime_ref = rt_opaque;
    surf.device_ref = dev;
    native_helpers.object_add_ref(DoeDevice, dev_raw);
    _ = attach_pending_platform_surface(surf, rt);
    return true;
}

fn release_current_surface_texture(surf: *DoeSurface) void {
    if (surf.current_tex) |tex| {
        tex.destroyed = true;
        surf.current_tex = null;
        texture_native.doeNativeTextureRelease(toOpaque(tex));
    }
}

fn register_acquired_surface_texture(
    rt: *NativeVulkanRuntime,
    surface_state: *backend_surface_ops.VulkanSurface,
    tex: *DoeTexture,
) bool {
    const image_count: usize = @intCast(surface_state.swapchain_image_count);
    const image_index: usize = @intCast(surface_state.current_image_index);
    if (image_index >= image_count) return false;
    const image = surface_state.swapchain_images[image_index];
    if (image == 0) return false;

    const handle: u64 = @intFromPtr(tex);
    var resource = vk_resources.borrowed_texture_resource(
        image,
        surface_state.swapchain_extent.width,
        surface_state.swapchain_extent.height,
        1,
        1,
        1,
        model_gpu_types.WGPUTextureDimension_2D,
        model_gpu_types.WGPUTextureViewDimension_2D,
        model_gpu_types.WGPUTextureAspect_All,
        surface_state.format,
        surface_state.usage,
        vk_constants.VK_IMAGE_LAYOUT_UNDEFINED,
    );
    resource.generation = rt.next_resource_generation() catch return false;
    resource.view = vk_resources.create_texture_view(rt, resource, surface_state.format, model_gpu_types.WGPUTextureViewDimension_2D, 0, 1, 0, 1, model_gpu_types.WGPUTextureAspect_All, 0, 0, 0, 0) catch return false;
    resource.owns_view = true;
    const result = rt.textures.getOrPut(rt.allocator, handle) catch {
        vk_resources.release_texture_resource(rt, resource);
        return false;
    };
    if (result.found_existing) {
        vk_resources.release_texture_resource(rt, result.value_ptr.*);
    }
    result.value_ptr.* = resource;
    tex.vk_id = handle;
    surface_state.acquired_texture_handle = handle;
    return true;
}

// ============================================================
// Instance: createSurface
// ============================================================

/// Create an unconfigured Vulkan surface and retain the originating instance.
/// Device/runtime binding happens at configure time via SurfaceConfiguration.device.
pub export fn doeNativeInstanceCreateSurface(
    inst_raw: ?*anyopaque,
    desc_raw: ?*anyopaque,
    dev_raw: ?*anyopaque,
) callconv(.c) ?*anyopaque {
    if (comptime !has_vulkan) return null;

    const surf = make(DoeSurface) orelse return null;
    const handle: u64 = @intFromPtr(surf);
    surf.* = .{
        .backend = .vulkan,
        .handle = handle,
    };
    retain_surface_instance(surf, inst_raw);
    capture_surface_descriptor(surf, desc_raw);

    if (dev_raw != null and !bind_surface_runtime(surf, dev_raw)) {
        release_surface_instance(surf);
        alloc.destroy(surf);
        return null;
    }
    return toOpaque(surf);
}

// ============================================================
// Platform VkSurface handle setters
// Must be called before doeNativeSurfaceConfigure for windowed rendering.
// ============================================================

/// Attach an XCB window to the surface. Enables real swapchain on Linux.
pub export fn doeNativeSurfaceSetXcbHandle(
    surf_raw: ?*anyopaque,
    xcb_connection: ?*anyopaque,
    xcb_window: u32,
) callconv(.c) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    surf.pending_xcb_connection = xcb_connection;
    surf.pending_xcb_window = xcb_window;
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    _ = attach_xcb_surface(surf, rt);
}

/// Attach a Wayland surface to the surface. Enables real swapchain on Linux.
pub export fn doeNativeSurfaceSetWaylandHandle(
    surf_raw: ?*anyopaque,
    wl_display: ?*anyopaque,
    wl_surface: ?*anyopaque,
) callconv(.c) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    surf.pending_wayland_display = wl_display;
    surf.pending_wayland_surface = wl_surface;
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    _ = attach_wayland_surface(surf, rt);
}

/// Attach an Xlib window to the surface. Enables real swapchain on Linux.
pub export fn doeNativeSurfaceSetXlibHandle(
    surf_raw: ?*anyopaque,
    xlib_display: ?*anyopaque,
    xlib_window: u64,
) callconv(.c) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    surf.pending_xlib_display = xlib_display;
    surf.pending_xlib_window = xlib_window;
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    _ = attach_xlib_surface(surf, rt);
}

// ============================================================
// Surface configure / acquire / present / unconfigure / release
// ============================================================

pub export fn doeNativeSurfaceConfigure(
    surf_raw: ?*anyopaque,
    width: u32,
    height: u32,
    format: u32,
    usage: u32,
    alpha_mode: u32,
    present_mode: u32,
    tone_mapping_mode: u32,
) callconv(.c) void {
    doeNativeSurfaceConfigureForDevice(
        surf_raw,
        null,
        width,
        height,
        format,
        usage,
        alpha_mode,
        present_mode,
        tone_mapping_mode,
    );
}

fn doeNativeSurfaceConfigureForDevice(
    surf_raw: ?*anyopaque,
    dev_raw: ?*anyopaque,
    width: u32,
    height: u32,
    format: u32,
    usage: u32,
    alpha_mode: u32,
    present_mode: u32,
    tone_mapping_mode: u32,
) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    if ((dev_raw != null or surf.vk_runtime_ref == null) and !bind_surface_runtime(surf, dev_raw)) {
        reportConfigurationError(cast(DoeDevice, dev_raw), error.InvalidArgument);
        return;
    }
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    const request = model_surface_control_types.SurfaceConfigureCommand{
        .handle = surf.handle,
        .width = width,
        .height = height,
        .format = format,
        .usage = usage,
        .alpha_mode = alpha_mode,
        .present_mode = present_mode,
        .tone_mapping_mode = if (tone_mapping_mode == 0) model_surface_control_types.WGPUCanvasToneMappingMode_Standard else tone_mapping_mode,
    };
    // Reject unsupported changes before expiring caller-held textures or retiring the swapchain.
    rt.get_surface_capabilities(surf.handle) catch |err| {
        reportConfigurationError(surf.device_ref, err);
        return;
    };
    const state = rt.surfaces.getPtr(surf.handle) orelse return;
    _ = vk_surf.admitConfiguration(state.cached_capabilities, request) catch |err| {
        reportConfigurationError(surf.device_ref, err);
        return;
    };
    release_current_surface_texture(surf);
    rt.configure_surface(request) catch |err| {
        reportConfigurationError(surf.device_ref, err);
    };
}

/// Acquire the next swapchain image and expose it as a WGPUTexture handle.
pub export fn doeNativeSurfaceGetCurrentTexture(
    surf_raw: ?*anyopaque,
    out_texture: ?*?*anyopaque,
    out_suboptimal: ?*u32,
    out_status: ?*u32,
) callconv(.c) void {
    if (out_status) |s| s.* = WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_ERROR;
    if (out_suboptimal) |s| s.* = 0;
    if (out_texture) |t| t.* = null;
    if (comptime !has_vulkan) return;

    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));

    const acquisition = rt.surfaces.getPtr(surf.handle) orelse return;
    if (!acquisition.configured) return;
    if (surf.current_tex) |existing| {
        if (existing.destroyed) return;
        if (out_texture) |t| {
            native_helpers.object_add_ref(DoeTexture, toOpaque(existing));
            t.* = toOpaque(existing);
        }
        if (out_suboptimal) |s| s.* = if (acquisition.last_acquire_suboptimal) 1 else 0;
        if (out_status) |s| s.* = if (acquisition.last_acquire_suboptimal) WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUBOPTIMAL else WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUCCESS;
        return;
    }
    const tex = make(DoeTexture) orelse return;
    rt.acquire_surface(surf.handle) catch |err| {
        alloc.destroy(tex);
        if (out_status) |s| s.* = switch (err) {
            error.SurfaceUnavailable => WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_OUTDATED,
            error.SyncUnavailable => WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_TIMEOUT,
            else => WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_ERROR,
        };
        std.log.err("doe_surface_native: acquire_surface failed: {s}", .{@errorName(err)});
        return;
    };

    const surface_state = rt.surfaces.getPtr(surf.handle) orelse {
        alloc.destroy(tex);
        return;
    };

    tex.* = .{
        .backend = .vulkan,
        .format = surface_state.format,
        .width = surface_state.swapchain_extent.width,
        .height = surface_state.swapchain_extent.height,
        .depth_or_array_layers = 1,
        .dimension = model_gpu_types.WGPUTextureDimension_2D,
        .mip_level_count = 1,
        .sample_count = 1,
        .usage = surface_state.usage,
        .texture_binding_view_dimension = model_gpu_types.WGPUTextureViewDimension_2D,
        .vk_runtime_ref = surf.vk_runtime_ref,
        .device_ref = surf.device_ref,
    };
    if (!register_acquired_surface_texture(rt, surface_state, tex)) {
        alloc.destroy(tex);
        return;
    }
    native_helpers.object_add_ref(DoeDevice, toOpaque(surf.device_ref.?));
    surf.current_tex = tex;
    if (out_texture) |t| {
        native_helpers.object_add_ref(DoeTexture, toOpaque(tex));
        t.* = toOpaque(tex);
    }
    if (out_suboptimal) |s| s.* = if (surface_state.last_acquire_suboptimal or surface_state.last_present_suboptimal) 1 else 0;
    if (out_status) |s| s.* = if (surface_state.last_acquire_suboptimal) WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUBOPTIMAL else WGPU_SURFACE_GET_CURRENT_TEXTURE_STATUS_SUCCESS;
}

pub export fn doeNativeSurfacePresent(surf_raw: ?*anyopaque) callconv(.c) void {
    _ = doeAbiBridgeSurfacePresent(surf_raw);
}

pub export fn doeNativeSurfaceUnconfigure(surf_raw: ?*anyopaque) callconv(.c) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (surf.backend != .vulkan) return;
    const rt_ptr = surf.vk_runtime_ref orelse return;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    release_current_surface_texture(surf);
    rt.unconfigure_surface(surf.handle) catch |err| {
        std.log.err("doe_surface_native: unconfigure_surface failed: {s}", .{@errorName(err)});
    };
}

pub export fn doeNativeSurfaceRelease(surf_raw: ?*anyopaque) callconv(.c) void {
    if (comptime !has_vulkan) return;
    const surf = cast(DoeSurface, surf_raw) orelse return;
    if (!native_helpers.object_should_destroy(surf)) return;
    release_current_surface_texture(surf);
    if (surf.backend == .vulkan) {
        if (surf.vk_runtime_ref) |rt_ptr| {
            const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
            rt.release_surface(surf.handle) catch |err| {
                log.warn("surface release: {s}", .{@errorName(err)});
            };
        }
    }
    if (surf.device_ref) |dev| device_native.doeNativeDeviceReleaseInternal(toOpaque(dev));
    release_surface_instance(surf);
    alloc.destroy(surf);
}

// ============================================================
// Capabilities query
// ============================================================

fn reportConfigurationError(device: ?*DoeDevice, cause: anyerror) void {
    const dev = device orelse return;
    const kind = switch (cause) {
        error.UnsupportedFeature, error.SurfaceUnavailable => error_scope.ERROR_TYPE_VALIDATION,
        else => error_scope.zig_error_to_type(cause),
    };
    var message: [160]u8 = undefined;
    const text = std.fmt.bufPrint(&message, "surface configuration rejected: {s}", .{@errorName(cause)}) catch unreachable;
    dev.error_scopes.deliver(kind, text);
}

fn queryCanvasCapabilities(surf: *DoeSurface, adapter: *native_types.DoeAdapter) !vk_surf.CanvasCapabilities {
    if (surf.backend != .vulkan or adapter.backend != .vulkan or adapter.instance != surf.instance_ref) return error.InvalidArgument;
    if (surf.device_ref) |dev| {
        if (dev.adapter != adapter) return error.InvalidArgument;
        const rt = native_rt_helpers.device_vk_runtime(dev) orelse return error.InvalidState;
        if (!rt.has_surface_completion) return error.UnsupportedFeature;
        try rt.get_surface_capabilities(surf.handle);
        return vk_surf.canvasCapabilities(rt.surfaces.get(surf.handle).?.cached_capabilities);
    }
    const source: vk_surf.SurfaceSource = if (surf.pending_xcb_connection) |connection|
        .{ .xcb = .{ .connection = connection, .window = surf.pending_xcb_window } }
    else if (surf.pending_wayland_display) |display|
        .{ .wayland = .{ .display = display, .surface = surf.pending_wayland_surface orelse return error.InvalidArgument } }
    else if (surf.pending_xlib_display) |display|
        .{ .xlib = .{ .display = display, .window = surf.pending_xlib_window } }
    else
        return error.SurfaceUnavailable;
    return vk_surf.probeSurfaceCapabilities(alloc, adapter.vulkan_queue_family_policy, .{
        .vendor_id = adapter.vendor_id,
        .device_id = adapter.device_id,
        .driver_version = adapter.driver_version,
        .device_name = adapter.device_name,
        .device_name_len = adapter.device_name_len,
    }, source);
}

fn copyCapabilities(allocator: std.mem.Allocator, caps: vk_surf.CanvasCapabilities) !surface_procs.SurfaceCapabilities {
    const formats = try allocator.dupe(u32, caps.formats[0..caps.format_count]);
    errdefer allocator.free(formats);
    const modes = try allocator.dupe(u32, caps.present_modes[0..caps.present_mode_count]);
    errdefer allocator.free(modes);
    const alpha = try allocator.dupe(u32, caps.alpha_modes[0..caps.alpha_mode_count]);
    return .{ .nextInChain = null, .usages = caps.usages, .formatCount = formats.len, .formats = formats.ptr, .presentModeCount = modes.len, .presentModes = modes.ptr, .alphaModeCount = alpha.len, .alphaModes = alpha.ptr };
}

pub export fn doeNativeSurfaceGetCapabilities(
    surf_raw: ?*anyopaque,
    adapter_raw: ?*anyopaque,
    out: ?*surface_procs.SurfaceCapabilities,
) callconv(.c) u32 {
    const output = out orelse return WGPU_STATUS_ERROR;
    const unsupported_chain = output.nextInChain != null;
    output.* = std.mem.zeroes(surface_procs.SurfaceCapabilities);
    if (comptime !has_vulkan) return WGPU_STATUS_ERROR;
    if (unsupported_chain) return WGPU_STATUS_ERROR;
    const surf = cast(DoeSurface, surf_raw) orelse return WGPU_STATUS_ERROR;
    const adapter = cast(native_types.DoeAdapter, adapter_raw) orelse return WGPU_STATUS_ERROR;
    const caps = queryCanvasCapabilities(surf, adapter) catch return WGPU_STATUS_ERROR;
    output.* = copyCapabilities(alloc, caps) catch return WGPU_STATUS_ERROR;
    return WGPU_STATUS_SUCCESS;
}

pub export fn doeNativeSurfaceCapabilitiesFreeMembers(caps: surface_procs.SurfaceCapabilities) callconv(.c) void {
    if (caps.formats) |values| alloc.free(values[0..caps.formatCount]);
    if (caps.presentModes) |values| alloc.free(values[0..caps.presentModeCount]);
    if (caps.alphaModes) |values| alloc.free(values[0..caps.alphaModeCount]);
}

// ============================================================
// ABI bridges: translate WebGPU C ABI struct signatures to
// the flattened parameter signatures used by native functions.
// ============================================================

/// ABI bridge for wgpuInstanceCreateSurface.
/// The native implementation takes an extra dev_raw parameter; the C ABI does not.
/// We pass null for dev_raw (device association happens at configure time).
pub fn doeAbiBridgeInstanceCreateSurface(
    inst_raw: ?*anyopaque,
    desc_raw: *const surface_procs.SurfaceDescriptor,
) callconv(.c) ?*anyopaque {
    return doeNativeInstanceCreateSurface(inst_raw, @ptrCast(@constCast(desc_raw)), null);
}

/// ABI bridge for wgpuSurfaceConfigure.
/// Unpacks SurfaceConfiguration fields into the flattened native call.
pub fn doeAbiBridgeSurfaceConfigure(
    surf_raw: ?*anyopaque,
    config: *const surface_procs.SurfaceConfiguration,
) callconv(.c) void {
    if (config.device == null) {
        const surf = cast(DoeSurface, surf_raw) orelse return;
        reportConfigurationError(surf.device_ref, error.InvalidArgument);
        return;
    }
    if (config.nextInChain != null or config.viewFormatCount != 0 or config.usage > std.math.maxInt(u32)) {
        reportConfigurationError(cast(DoeDevice, config.device), error.UnsupportedFeature);
        return;
    }
    doeNativeSurfaceConfigureForDevice(
        surf_raw,
        config.device,
        config.width,
        config.height,
        config.format,
        @intCast(config.usage),
        config.alphaMode,
        config.presentMode,
        0, // tone_mapping_mode — not in C ABI struct; default to standard
    );
}

/// ABI bridge for wgpuSurfaceGetCurrentTexture.
/// Unpacks the SurfaceTexture output struct from the flattened native outputs.
pub fn doeAbiBridgeSurfaceGetCurrentTexture(
    surf_raw: ?*anyopaque,
    out: *surface_procs.SurfaceTexture,
) callconv(.c) void {
    var tex_ptr: ?*anyopaque = null;
    var suboptimal: u32 = 0;
    var status: u32 = 0;
    doeNativeSurfaceGetCurrentTexture(surf_raw, &tex_ptr, &suboptimal, &status);
    out.texture = @ptrCast(tex_ptr);
    out.status = status;
}

/// ABI bridge for wgpuSurfacePresent.
/// Preserve the backend outcome in the public WGPUStatus result.
pub fn doeAbiBridgeSurfacePresent(surf_raw: ?*anyopaque) callconv(.c) u32 {
    if (comptime !has_vulkan) return WGPU_STATUS_ERROR;
    const surf = cast(DoeSurface, surf_raw) orelse return WGPU_STATUS_ERROR;
    const rt_ptr = surf.vk_runtime_ref orelse return WGPU_STATUS_ERROR;
    const rt: *NativeVulkanRuntime = @ptrCast(@alignCast(rt_ptr));
    rt.present_surface(surf.handle) catch |err| {
        // A rejected queue operation can be retried; an accepted presentation
        // expires this texture even when the surface becomes out of date.
        if (rt.surfaces.get(surf.handle)) |state| {
            if (!state.acquired) {
                release_current_surface_texture(surf);
            } else if (state.completion.present_ready) {
                if (surf.current_tex) |tex| tex.destroyed = true;
            }
        }
        log.warn("surface present: {s}", .{@errorName(err)});
        return WGPU_STATUS_ERROR;
    };
    release_current_surface_texture(surf);
    return WGPU_STATUS_SUCCESS;
}

fn capabilityAllocationCase(allocator: std.mem.Allocator) !void {
    var caps = vk_surf.CanvasCapabilities{};
    caps.formats[0] = model_gpu_types.WGPUTextureFormat_BGRA8Unorm;
    caps.format_count = 1;
    caps.present_modes[0] = 1;
    caps.present_mode_count = 1;
    caps.alpha_modes[0] = 1;
    caps.alpha_mode_count = 1;
    const copied = try copyCapabilities(allocator, caps);
    defer allocator.free(copied.formats.?[0..copied.formatCount]);
    defer allocator.free(copied.presentModes.?[0..copied.presentModeCount]);
    defer allocator.free(copied.alphaModes.?[0..copied.alphaModeCount]);
    caps.formats[0] = 0;
    try std.testing.expectEqual(model_gpu_types.WGPUTextureFormat_BGRA8Unorm, copied.formats.?[0]);
}

test "surface capabilities roll back every allocation and own independent copies" {
    if (comptime has_vulkan) try std.testing.checkAllAllocationFailures(std.testing.allocator, capabilityAllocationCase, .{});
}
