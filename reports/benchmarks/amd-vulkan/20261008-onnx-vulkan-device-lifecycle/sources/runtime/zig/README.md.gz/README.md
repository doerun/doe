# Doe Zig runtime

`runtime/zig/` owns the native runtime, WebGPU ABI, WGSL compiler, backend
implementations, TSIR lowering, and native tools. Public JavaScript behavior is
exposed through `packages/doe-gpu/`; benchmark and claim orchestration remains
under `bench/`.

## Source ownership

Start with the [generated source map](src/README.md). Its responsibility labels,
build views, and import boundaries come from [source-layout.json](source-layout.json).
The map distinguishes WebGPU object ownership, command execution through the
WebGPU ABI, shared execution services, and module incubation. Historical names
such as `core` and `full` are not evidence of which build ships a module.

Use the nearest owner rather than adding catch-all utilities. The import fence
enforces dependency direction; organization quality still requires reviewing
responsibility splits and actual consumers.

The [review ledger](reviews/README.md) tracks examination from individual files
through directory relationships and complete runtime paths. Its generated queue
records coverage separately from architecture decisions and passing tests.

## Build and test

```bash
zig build fmt-check
zig build
zig build test
zig build test-core
zig build test-full
zig build test-wgsl
zig build test-bench-shader
zig build test-bench-compilation
zig build test-bench-host-hotpaths
zig build test-bench-metal-compute test-bench-metal-staged-write
zig build test-runtime-compile-report
zig build import-fence
zig build source-layout
zig build line-limits
```

Use the configured Zig toolchain and the [style guide](STYLE.md). `zig build fmt`
formats owned Zig files; `fmt-check` is also a dependency of the default install
and canonical test suites. Both exclude vendored sources and build outputs.

`-Dtest-filter=<substring>` selects test names in `test`, `test-core`,
`test-full`, `test-d3d12`, `test-wgsl`, `test-bench-shader`, and
`test-bench-compilation`, `test-bench-host-hotpaths`, `test-bench-metal-compute`,
`test-bench-metal-staged-write`, and `test-runtime-compile-report`. Check the executed test count:
a filter matching no names runs no tests, and a filtered run does not qualify
the complete suite.

Backend-specific builds and tools are listed by `zig build --help`. Hardware
execution requires the matching host, SDK, driver, and declared backend lane.
The [compiler benchmark contract](bench/compiler/README.md) describes the
diagnostic stage tool's sampling, error handling, and timing boundaries.
The [host benchmark contract](bench/host_hotpath/README.md) describes local
variant observations, ownership, and diagnostic output migration.
The [Metal benchmark contract](bench/entrypoints/README.md) separates CPU
contract tests from physical Metal execution.

## Runtime contract

- Unsupported behavior is typed and explicit.
- Core must not import full-surface modules.
- Runtime-visible selection comes from config or declared call inputs.
- Promoted execution must preserve provider, backend, adapter, driver, command,
  output, and timing identity.
- Cache, timestamp, trace, and receipt failures cannot silently change semantic
  success.
- Synthetic backend state and hidden fallback are forbidden.

## Build tiers

`compute`, `headless`, and `full` tiers expose increasing WebGPU surface area.
Tier selection is a build contract, not evidence that every operation is
supported. Consult [`../../docs/doe-support-matrix.md`](../../docs/doe-support-matrix.md)
and current artifacts before making compatibility claims.

## Compiler and spatial paths

- WGSL architecture:
  [`../../docs/shader-compiler-architecture.md`](../../docs/shader-compiler-architecture.md)
- TSIR plan: [`../../docs/tsir-lowering-plan.md`](../../docs/tsir-lowering-plan.md)
- CSL architecture: [`../../docs/csl-architecture.md`](../../docs/csl-architecture.md)
- Proof elimination:
  [`../../docs/lean-bounds-elimination-design.md`](../../docs/lean-bounds-elimination-design.md)

Detailed tool invocations belong in focused runbooks and `zig build --help`,
not this module entrypoint.

## Native command ownership

Canonical Zig tests inject allocation failures into private fused-command
construction and check cleanup and publication. The direct C fixture at
[`tests/native_recorded_compute.c`](tests/native_recorded_compute.c) exercises
the exported constructors on AMD Vulkan after caller references are released.
Build, execution, and retained-library reproduction commands are in the
[allocation checkpoint](../../bench/out/compute-program/20260906-recorded-allocation/README.md).
Package qualification separately verifies ordinary command ownership across
the JavaScript/native boundary.

[`tests/native_async_pipeline.c`](tests/native_async_pipeline.c) exercises the
public async render-pipeline callback, immediate caller release, and eventual
device cleanup on Linux Vulkan. Link it against the retained package library
with the same C build recipe. The Zig suite also injects snapshot allocation and
worker-start failures, compares exact request identities, and verifies callback
leases for compute and rendering.

[`tests/native_occlusion_query.c`](tests/native_occlusion_query.c) checks ordinary
public recording, submission, query resolve and pixel readback on Linux Vulkan.
The [query checkpoint](../../reports/maintenance/20260928-production-query/README.md)
retains the isolated build recipe and native command-order observation.

## Build edit measurements

Run `python3 runtime/zig/tools/capture_build_measurements.py` from the repository
root. The tool measures a clean build, a no-change rebuild, and each exact source
edit in `config/zig-build-measurements.json`, using a private source snapshot and
cache. Every edit starts from a restored baseline. The report separates elapsed
time, per-build process RSS, and artifact size; it does not modify active work.
See the [architecture audit](../../docs/status/runtime-architecture-audit.md)
for the current recipe disposition and scoped evidence.

## Native callback delivery

The [bounded callback contract](../../docs/native-callback-contract.md) specifies
instance-owned futures, requested delivery modes, pending mapping state and resource
leases through foreign callbacks. The [ONNX Vulkan fixture and replay](../../bench/external-projects/onnx-vulkan-callbacks/README.md)
qualify the named paths with pinned Dawn controls and unchanged applications.
The [device lifecycle successor](../../docs/native-device-lifecycle-contract.md)
extends the bounded Vulkan evidence to descriptor loss and DeviceDestroy. Abandoned
instances, actual driver loss and generic callback conformance remain open; neither
report establishes a speed advantage.
