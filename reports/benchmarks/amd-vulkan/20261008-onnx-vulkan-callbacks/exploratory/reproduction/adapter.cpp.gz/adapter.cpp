#include "dawn/dawn_proc_table.h"
#include <dlfcn.h>
#include <cstdio>
#include <cstring>
struct Capture { unsigned count=0; WGPUAdapter adapter=nullptr; };
int main(int argc,char**argv) {
 if(argc!=4)return 90;
 auto bridge=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);
 if(!bridge)return 91;
 using Init=const DawnProcTable*(*)(const char*);
 auto init=reinterpret_cast<Init>(dlsym(bridge,!strcmp(argv[3],"doe")?"doeDawnBridgeInitialize":"doeDawnBridgeInitializeControl"));
 auto p=init(argv[2]);if(!p)return 92;
 WGPUInstanceFeatureName feature=WGPUInstanceFeatureName_TimedWaitAny;
 WGPUInstanceDescriptor desc{};desc.requiredFeatureCount=1;desc.requiredFeatures=&feature;
 auto instance=p->createInstance(&desc);if(!instance)return 93;
 WGPURequestAdapterOptions options{};options.backendType=WGPUBackendType_Vulkan;
 Capture capture;
 WGPURequestAdapterCallbackInfo info{};info.mode=WGPUCallbackMode_WaitAnyOnly;info.userdata1=&capture;
 info.callback=[](WGPURequestAdapterStatus status,WGPUAdapter adapter,WGPUStringView,void*data,void*) {
  auto c=static_cast<Capture*>(data);++c->count;c->adapter=adapter;
  std::printf("callback status=%u count=%u\n",unsigned(status),c->count);
 };
 auto future=p->instanceRequestAdapter(instance,&options,info);
 unsigned before=capture.count;
 p->instanceProcessEvents(instance);unsigned after_events=capture.count;
 WGPUFutureWaitInfo wait{future,false};auto status=p->instanceWaitAny(instance,1,&wait,UINT64_MAX);
 std::printf("observation before=%u afterEvents=%u afterWait=%u waitStatus=%u completed=%u future=%llu\n",before,after_events,capture.count,unsigned(status),unsigned(wait.completed),(unsigned long long)future.id);
 if(capture.adapter)p->adapterRelease(capture.adapter);p->instanceRelease(instance);
 return before==0&&after_events==0&&capture.count==1&&status==WGPUWaitStatus_Success&&wait.completed?0:1;
}
