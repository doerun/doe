from pathlib import Path
import struct,json,re
b=Path('/opt/google/chrome/chrome').read_bytes()
shoff=struct.unpack_from('<Q',b,40)[0]; entsize,count,nametable=struct.unpack_from('<HHH',b,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*entsize) for i in range(count)]
namesec=sections[nametable]; names=b[namesec[4]:namesec[4]+namesec[5]]
def name(s): return names[s[0]:].split(b'\0',1)[0].decode()
smap={name(s):s for s in sections}; rel=smap['.rela.dyn']
rmap={offset:addend for offset,info,addend in struct.iter_unpack('<QQq',b[rel[4]:rel[4]+rel[5]]) if info==8}
def address(off):
 for s in sections:
  if s[4]<=off<s[4]+s[5] and s[2]&2 and s[1]!=8: return s[3]+off-s[4]
 raise ValueError(off)
def file_offset(addr):
 for s in sections:
  if s[3]<=addr<s[3]+s[5] and s[2]&2 and s[1]!=8: return s[4]+addr-s[3]
 raise ValueError(addr)
string_names={address(m.start()):m.group()[:-1].decode() for m in re.finditer(rb'wgpu[A-Z][A-Za-z0-9]+\0',b)}
procs={}; records=[]
text=smap['.text']; begin,end=text[3],text[3]+text[5]
for offset,addend in rmap.items():
 n=string_names.get(addend)
 if n and begin<=rmap.get(offset-8,0)<end:
  size=struct.unpack_from('<Q',b,file_offset(offset+8))[0]
  if size==len(n):
   procs[n]=rmap[offset-8]; records.append(offset-8)
reverse={value:key for key,value in procs.items()}
print('mappedProcs',len(procs),'recordRange',hex(min(records)),hex(max(records)))
slots={}
for offset,fn in rmap.items():
 if fn==procs.get('wgpuQueueSubmit'):
  print('queueSubmitReference',hex(offset))
  print([(hex(o),reverse.get(rmap.get(o),hex(rmap.get(o,0)))) for o in range(offset-40,offset+48,8)])
  if reverse.get(rmap.get(offset-8))=='wgpuQueueSetLabel' and reverse.get(rmap.get(offset+8))=='wgpuQueueWriteBuffer': slots['wgpuQueueSubmit']=offset
print('identifiedSlots',slots)
Path('bench/out/stock-chrome-native-swap/20261005/elf-map.json').write_text(json.dumps({'procs':procs,'slots':slots,'procMapStart':min(records),'procMapEnd':max(records)},indent=2)+'\n')
