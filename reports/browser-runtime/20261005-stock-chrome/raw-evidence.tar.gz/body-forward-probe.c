#define _GNU_SOURCE
#include <link.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>
#include <stdatomic.h>
#include <string.h>
#include <sys/mman.h>

typedef void (*QueueSubmit)(void*, size_t, void* const*);
static QueueSubmit original;
static _Atomic unsigned calls;
static void forward_queue_submit(void* queue, size_t count, void* const* commands) {
    unsigned current = atomic_fetch_add(&calls, 1) + 1;
    fprintf(stderr, "DOE_CHROME_PROC_PROBE {\"event\":\"queueSubmit\",\"pid\":%d,\"count\":%u,\"commands\":%zu}\n", getpid(), current, count);
    original(queue, count, commands);
}
static int locate(struct dl_phdr_info* info, size_t size, void* unused) {
    (void)size; (void)unused;
    if (info->dlpi_name && *info->dlpi_name) return 0;
    uintptr_t base = info->dlpi_addr;
    const unsigned char expected[] = {0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56,0x53,0x48,0x83,0xec,0x48,0x48,0x89,0xfb};
    unsigned char* target=(unsigned char*)(base+0x73fe210);
    if(memcmp(target,expected,sizeof(expected))!=0) _exit(78);
    size_t page_size=(size_t)sysconf(_SC_PAGESIZE);
    unsigned char* trampoline=mmap(0,page_size,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(trampoline==MAP_FAILED) _exit(79);
    memcpy(trampoline,target,sizeof(expected));
    const unsigned char jump[]={0xff,0x25,0,0,0,0};
    memcpy(trampoline+sizeof(expected),jump,sizeof(jump));
    uintptr_t resume=(uintptr_t)target+sizeof(expected);
    memcpy(trampoline+sizeof(expected)+sizeof(jump),&resume,sizeof(resume));
    if(mprotect(trampoline,page_size,PROT_READ|PROT_EXEC)!=0) _exit(80);
    original=(QueueSubmit)trampoline;
    void* target_page=(void*)((uintptr_t)target & ~(page_size-1));
    if(mprotect(target_page,page_size,PROT_READ|PROT_WRITE)!=0) _exit(81);
    memcpy(target,jump,sizeof(jump));
    uintptr_t replacement=(uintptr_t)forward_queue_submit;
    memcpy(target+sizeof(jump),&replacement,sizeof(replacement));
    memset(target+sizeof(jump)+sizeof(replacement),0x90,sizeof(expected)-sizeof(jump)-sizeof(replacement));
    if(mprotect(target_page,page_size,PROT_READ|PROT_EXEC)!=0) _exit(82);
    fprintf(stderr,"DOE_CHROME_PROC_PROBE {\"event\":\"installed\",\"pid\":%d}\n",getpid());
    return 1;
}
__attribute__((constructor)) static void install(void) {
    char path[4096];
    ssize_t length=readlink("/proc/self/exe",path,sizeof(path)-1);
    if(length<0) return;
    path[length]='\0';
    const char* name=path;
    for(char* p=path;*p;p++) if(*p=='/') name=p+1;
    if(__builtin_strcmp(name,"chrome")!=0) return;
    dl_iterate_phdr(locate,0);
}
