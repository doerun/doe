#define _GNU_SOURCE
#include <link.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
static int (*prepare_control)(void);
static int (*run_control)(void);
static void* (*next_dlopen)(const char*,int);
static int preparing;
__attribute__((constructor)) static void load_control(void) {
 next_dlopen=(void*(*)(const char*,int))dlsym(RTLD_NEXT,"dlopen");
 void* module=dlmopen(LM_ID_NEWLM,"/home/x/deco/doe/bench/out/stock-chrome-native-swap/20261005/doe-isolated-control.so",RTLD_NOW|RTLD_LOCAL);
 if(!module){fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"loadFailed\",\"error\":\"%s\"}\n",dlerror());_exit(85);}
 prepare_control=(int(*)(void))dlsym(module,"doe_prepare_control");
 run_control=(int(*)(void))dlsym(module,"doe_process_control");
 if(!prepare_control||!run_control)_exit(86);
}
void* dlopen(const char* filename,int flags) {
 if(!next_dlopen)next_dlopen=(void*(*)(const char*,int))dlsym(RTLD_NEXT,"dlopen");
 void* handle=next_dlopen(filename,flags);
 if(filename&&(strstr(filename,"vulkan")||strstr(filename,"swiftshader"))){
  fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"dlopen\",\"pid\":%d,\"path\":\"%s\"}\n",getpid(),filename);
  if(handle&&strstr(filename,"libvulkan.so")&&prepare_control&&!preparing){preparing=1;prepare_control();}
 }
 return handle;
}
int doe_process_control(void){return run_control?run_control():87;}
