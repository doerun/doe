#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
extern int doe_prepare_control(void);
VKAPI_ATTR VkResult VKAPI_CALL vkCreateInstance(const VkInstanceCreateInfo* info,const VkAllocationCallbacks* alloc,VkInstance* out) {
 static PFN_vkCreateInstance next;
 if(!next) next=(PFN_vkCreateInstance)dlsym(RTLD_NEXT,"vkCreateInstance");
 fprintf(stderr,"DOE_CHROME_VULKAN_CALL {\"pid\":%d,\"name\":\"%s\"}\n",getpid(),info->pApplicationInfo&&info->pApplicationInfo->pApplicationName?info->pApplicationInfo->pApplicationName:"");
 if(info->pApplicationInfo && info->pApplicationInfo->pApplicationName && strcmp(info->pApplicationInfo->pApplicationName,"chrome")==0) doe_prepare_control();
 return next(info,alloc,out);
}
