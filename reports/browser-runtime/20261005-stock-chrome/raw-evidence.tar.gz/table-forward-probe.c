#define _GNU_SOURCE
#include <link.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>
#include <stdatomic.h>

typedef void (*QueueSubmit)(void*, size_t, void* const*);
static QueueSubmit original;
static _Atomic unsigned calls;
static void forward_queue_submit(void* queue, size_t count, void* const* commands) {
    unsigned current = atomic_fetch_add(&calls, 1) + 1;
    fprintf(stderr, "DOE_CHROME_PROC_PROBE {\"event\":\"queueSubmit\",\"pid\":%d,\"count\":%u,\"commands\":%zu}\n", getpid(), current, count);
    original(queue, count, commands);
}
static int locate(struct dl_phdr_info* info, size_t size, void* unused) {
    (void)size; (void)unused;
    if (info->dlpi_name && *info->dlpi_name) return 0;
    uintptr_t base = info->dlpi_addr;
    QueueSubmit* slot = (QueueSubmit*)(base + PROBE_SLOT);
    original = (QueueSubmit)(base + PROBE_FUNCTION);
    if (*slot != original) {
        fprintf(stderr,"DOE_CHROME_PROC_PROBE {\"event\":\"identityMismatch\",\"pid\":%d}\n",getpid());
        _exit(78);
    }
    *slot = forward_queue_submit;
    fprintf(stderr,"DOE_CHROME_PROC_PROBE {\"event\":\"installed\",\"pid\":%d}\n",getpid());
    return 1;
}
__attribute__((constructor)) static void install(void) {
    char path[4096];
    ssize_t length=readlink("/proc/self/exe",path,sizeof(path)-1);
    if(length<0) return;
    path[length]='\0';
    const char* name=path;
    for(char* p=path;*p;p++) if(*p=='/') name=p+1;
    if(__builtin_strcmp(name,"chrome")!=0) return;
    dl_iterate_phdr(locate,0);
}
