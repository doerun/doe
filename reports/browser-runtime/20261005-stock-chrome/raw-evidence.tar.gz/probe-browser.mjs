import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
import { chromium } from '/home/x/deco/reploid/node_modules/playwright/index.mjs';
const browserPath='/opt/google/chrome/chrome';
assert.equal(createHash('sha256').update(await readFile(browserPath)).digest('hex'),'163bebf7c62e813523c35b12f8cc59f158b2c428c539ec4a3b5142a6b3c65010');
const root=resolve('bench/out/stock-chrome-native-swap/20261005');
const hooked=process.argv.includes('--hook');
const server=createServer((request,response)=>{response.writeHead(200,{'Content-Type':'text/html'});response.end('<!doctype html><title>Native forwarding control</title>');});
await new Promise(done=>server.listen(0,'127.0.0.1',done));
let browser;
let result={hooked,passed:false};
try {
 browser=await chromium.launch({executablePath:browserPath,headless:!process.argv.includes('--headful'),chromiumSandbox:!process.argv.includes('--no-sandbox'),ignoreDefaultArgs:['--enable-unsafe-swiftshader'],env:{...process.env,...(hooked?{LD_PRELOAD:resolve(root,'forward-probe.so')}:{})},args:['--enable-unsafe-webgpu','--ignore-gpu-blocklist','--enable-webgpu-developer-features','--use-angle=vulkan','--enable-features=Vulkan','--disable-vulkan-surface']});
 const page=await browser.newPage();
 await page.goto(`http://127.0.0.1:${server.address().port}/`);
 const output=await page.evaluate(async()=>{
  let adapter; let adapterRequests=0; for(;adapterRequests<3&&!adapter;adapterRequests++){adapter=await navigator.gpu.requestAdapter();} if(!adapter)throw Error('No physical adapter after three requests');
  const device=await adapter.requestDevice();
  try {
   const buffer=device.createBuffer({size:16,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC});
   const readback=device.createBuffer({size:16,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
   device.queue.writeBuffer(buffer,0,new Uint32Array([1,2,3,4]));
   const shader=device.createShaderModule({code:'@group(0) @binding(0) var<storage,read_write> data:array<u32>; @compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id:vec3<u32>){data[id.x]+=1u;}'});
   const pipeline=device.createComputePipeline({layout:'auto',compute:{module:shader,entryPoint:'main'}});
   const bind=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer}}]});
   const encoder=device.createCommandEncoder();const pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bind);pass.dispatchWorkgroups(4);pass.end();encoder.copyBufferToBuffer(buffer,0,readback,0,16);device.queue.submit([encoder.finish()]);
   await readback.mapAsync(GPUMapMode.READ);const actual=Array.from(new Uint32Array(readback.getMappedRange()));readback.unmap();readback.destroy();buffer.destroy();await device.queue.onSubmittedWorkDone();
   return {actual,adapterRequests,adapterInfo:{vendor:adapter.info.vendor,architecture:adapter.info.architecture,device:adapter.info.device,description:adapter.info.description}};
  } finally {device.destroy();}
 });
 assert.deepEqual(output.actual,[2,3,4,5]);assert.equal(output.adapterInfo.vendor,'amd');result={...result,passed:true,browserVersion:browser.version(),...output};
} catch(error){result.error=String(error);process.exitCode=1;}
finally{await browser?.close();await new Promise(done=>server.close(done));await writeFile(resolve(root,hooked?'forward-control.json':'baseline-control.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));}
