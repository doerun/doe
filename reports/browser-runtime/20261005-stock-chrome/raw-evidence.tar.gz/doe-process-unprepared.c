#include "webgpu.h"
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>

typedef struct Request { void* handle; uint32_t status; } Request;
static void adapter_ready(WGPURequestAdapterStatus status, WGPUAdapter adapter,
    WGPUStringView message, void* out, void* unused) {
    (void)unused;
    *(Request*)out = (Request){adapter, status};
    fprintf(stderr, "DOE_CHROME_NATIVE_CONTROL {\"event\":\"adapter\",\"pid\":%d,\"status\":%u,\"message\":\"%.*s\"}\n", getpid(), status, (int)message.length, message.data ? message.data : "");
}
static void device_ready(WGPURequestDeviceStatus status, WGPUDevice device,
    WGPUStringView message, void* out, void* unused) {
    (void)message; (void)unused;
    *(Request*)out = (Request){device, status};
}
static void mapped(WGPUMapAsyncStatus status, WGPUStringView message, void* out, void* unused) {
    (void)message; (void)unused;
    *(uint32_t*)out = status;
}
static int wait_for(WGPUInstance instance, WGPUFuture future) {
    WGPUFutureWaitInfo wait = {.future=future};
    return wgpuInstanceWaitAny(instance, 1, &wait, UINT64_C(10000000000)) == WGPUWaitStatus_Success && wait.completed;
}
int doe_process_control(void) {
    int result=1;
    WGPUInstance instance=NULL; WGPUAdapter adapter=NULL; WGPUDevice device=NULL;
    WGPUQueue queue=NULL; WGPUBuffer buffer=NULL, readback=NULL;
    WGPUShaderModule shader=NULL; WGPUComputePipeline pipeline=NULL;
    WGPUBindGroupLayout layout=NULL; WGPUBindGroup bind=NULL;
    WGPUCommandEncoder encoder=NULL; WGPUComputePassEncoder pass=NULL;
    WGPUCommandBuffer command=NULL;
    WGPUInstanceFeatureName timed=WGPUInstanceFeatureName_TimedWaitAny;
    WGPUInstanceDescriptor instance_desc=WGPU_INSTANCE_DESCRIPTOR_INIT;
    instance_desc.requiredFeatureCount=1; instance_desc.requiredFeatures=&timed;
    instance=wgpuCreateInstance(&instance_desc);
    if(!instance) goto cleanup;
    fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"instance\",\"pid\":%d}\n",getpid());
    Request request={0};
    WGPURequestAdapterOptions options=WGPU_REQUEST_ADAPTER_OPTIONS_INIT;
    options.backendType=WGPUBackendType_Vulkan;
    WGPURequestAdapterCallbackInfo callback=WGPU_REQUEST_ADAPTER_CALLBACK_INFO_INIT;
    callback.mode=WGPUCallbackMode_WaitAnyOnly; callback.callback=adapter_ready; callback.userdata1=&request;
    if(!wait_for(instance,wgpuInstanceRequestAdapter(instance,&options,callback))) {result=2;goto cleanup;}
    adapter=request.handle;
    if(request.status!=WGPURequestAdapterStatus_Success||!adapter) {result=3;goto cleanup;}
    WGPUAdapterInfo info=WGPU_ADAPTER_INFO_INIT;
    if(wgpuAdapterGetInfo(adapter,&info)!=WGPUStatus_Success) {result=4;goto cleanup;}
    fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"identity\",\"backend\":%u,\"vendor\":%u,\"device\":%u}\n",info.backendType,info.vendorID,info.deviceID);
    int physical=info.backendType==WGPUBackendType_Vulkan && info.vendorID==0x1002 && info.adapterType!=WGPUAdapterType_CPU;
    wgpuAdapterInfoFreeMembers(info);
    if(!physical){result=5;goto cleanup;}
    WGPUDeviceDescriptor device_desc=WGPU_DEVICE_DESCRIPTOR_INIT;
    WGPURequestDeviceCallbackInfo device_callback=WGPU_REQUEST_DEVICE_CALLBACK_INFO_INIT;
    request=(Request){0}; device_callback.mode=WGPUCallbackMode_WaitAnyOnly;
    device_callback.callback=device_ready; device_callback.userdata1=&request;
    if(!wait_for(instance,wgpuAdapterRequestDevice(adapter,&device_desc,device_callback))){result=6;goto cleanup;}
    device=request.handle;
    if(!device || request.status!=WGPURequestDeviceStatus_Success){result=7;goto cleanup;}
    queue=wgpuDeviceGetQueue(device);
    WGPUBufferDescriptor bd=WGPU_BUFFER_DESCRIPTOR_INIT; bd.size=16;
    bd.usage=WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst|WGPUBufferUsage_CopySrc;
    buffer=wgpuDeviceCreateBuffer(device,&bd);
    bd.usage=WGPUBufferUsage_MapRead|WGPUBufferUsage_CopyDst;
    readback=wgpuDeviceCreateBuffer(device,&bd);
    if(!buffer||!readback){result=8;goto cleanup;}
    uint32_t input[]={1,2,3,4}; wgpuQueueWriteBuffer(queue,buffer,0,input,sizeof(input));
    WGPUShaderSourceWGSL source=WGPU_SHADER_SOURCE_WGSL_INIT;
    source.code=(WGPUStringView){"@group(0) @binding(0) var<storage,read_write> data:array<u32>; @compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id:vec3<u32>){data[id.x]+=1u;}",WGPU_STRLEN};
    WGPUShaderModuleDescriptor sd=WGPU_SHADER_MODULE_DESCRIPTOR_INIT; sd.nextInChain=&source.chain;
    shader=wgpuDeviceCreateShaderModule(device,&sd);
    WGPUComputePipelineDescriptor pd=WGPU_COMPUTE_PIPELINE_DESCRIPTOR_INIT;
    pd.compute.module=shader; pd.compute.entryPoint=(WGPUStringView){"main",WGPU_STRLEN};
    pipeline=wgpuDeviceCreateComputePipeline(device,&pd);
    if(!shader||!pipeline){result=9;goto cleanup;}
    layout=wgpuComputePipelineGetBindGroupLayout(pipeline,0);
    WGPUBindGroupEntry entry=WGPU_BIND_GROUP_ENTRY_INIT;entry.binding=0;entry.buffer=buffer;entry.size=16;
    WGPUBindGroupDescriptor bind_desc=WGPU_BIND_GROUP_DESCRIPTOR_INIT;
    bind_desc.layout=layout;bind_desc.entryCount=1;bind_desc.entries=&entry;
    bind=wgpuDeviceCreateBindGroup(device,&bind_desc);
    encoder=wgpuDeviceCreateCommandEncoder(device,NULL);
    pass=wgpuCommandEncoderBeginComputePass(encoder,NULL);
    if(!layout||!bind||!encoder||!pass){result=10;goto cleanup;}
    wgpuComputePassEncoderSetPipeline(pass,pipeline);
    wgpuComputePassEncoderSetBindGroup(pass,0,bind,0,NULL);
    wgpuComputePassEncoderDispatchWorkgroups(pass,4,1,1);
    wgpuComputePassEncoderEnd(pass);
    wgpuCommandEncoderCopyBufferToBuffer(encoder,buffer,0,readback,0,16);
    command=wgpuCommandEncoderFinish(encoder,NULL);
    if(!command){result=11;goto cleanup;}
    wgpuQueueSubmit(queue,1,&command);
    uint32_t map_status=0;
    WGPUBufferMapCallbackInfo map_callback=WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
    map_callback.mode=WGPUCallbackMode_WaitAnyOnly;map_callback.callback=mapped;map_callback.userdata1=&map_status;
    if(!wait_for(instance,wgpuBufferMapAsync(readback,WGPUMapMode_Read,0,16,map_callback))||map_status!=WGPUMapAsyncStatus_Success){result=12;goto cleanup;}
    const uint32_t* output=wgpuBufferGetConstMappedRange(readback,0,16);
    if(!output){result=13;goto cleanup;}
    result=output[0]!=2||output[1]!=3||output[2]!=4||output[3]!=5 ? 14 : 0;
    fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"output\",\"pid\":%d,\"actual\":[%u,%u,%u,%u],\"passed\":%s}\n",getpid(),output[0],output[1],output[2],output[3],result==0?"true":"false");
    wgpuBufferUnmap(readback);
cleanup:
    if(command)wgpuCommandBufferRelease(command);
    if(pass)wgpuComputePassEncoderRelease(pass);
    if(encoder)wgpuCommandEncoderRelease(encoder);
    if(bind)wgpuBindGroupRelease(bind);
    if(layout)wgpuBindGroupLayoutRelease(layout);
    if(pipeline)wgpuComputePipelineRelease(pipeline);
    if(shader)wgpuShaderModuleRelease(shader);
    if(readback){wgpuBufferDestroy(readback);wgpuBufferRelease(readback);}
    if(buffer){wgpuBufferDestroy(buffer);wgpuBufferRelease(buffer);}
    if(queue)wgpuQueueRelease(queue);
    if(device){wgpuDeviceDestroy(device);wgpuDeviceRelease(device);}
    if(adapter)wgpuAdapterRelease(adapter);
    if(instance)wgpuInstanceRelease(instance);
    fprintf(stderr,"DOE_CHROME_NATIVE_CONTROL {\"event\":\"settled\",\"pid\":%d,\"result\":%d}\n",getpid(),result);
    return result;
}
