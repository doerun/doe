const std = @import("std");
const runtime = @import("src/backend/vulkan/native_runtime.zig");
const resources = @import("src/backend/vulkan/vk_resources.zig");
const upload = @import("src/backend/vulkan/vk_upload.zig");
const device = @import("src/backend/vulkan/vk_device.zig");
extern fn audit_begin() void;
extern fn audit_hold(c_int) void;
extern fn audit_allow() void;
extern fn audit_end() void;
extern fn audit_idle_calls() c_int;
extern fn audit_wait_calls() c_int;
extern fn audit_destroyed() c_int;
extern fn audit_premature() c_int;
extern fn audit_buffers() i64;
extern fn audit_memories() i64;
extern fn audit_mappings() i64;
const BYTES = 32768;
const DEADLINE_NS = 5 * std.time.ns_per_s;
const Job = struct {
    rt: *runtime.NativeVulkanRuntime,
    mode: enum { shutdown, registered, direct },
    original: resources.ComputeBuffer,
    done: std.atomic.Value(bool) = std.atomic.Value(bool).init(false),
    fn run(self: *@This()) void {
        switch (self.mode) {
            .shutdown => self.rt.deinit(),
            .registered => resources.destroy_compute_buffer(self.rt, 1),
            .direct => resources.release_compute_buffer(self.rt, self.original),
        }
        self.done.store(true, .release);
    }
};
fn exercise(mode: @FieldType(Job, "mode"), loss: c_int) !void {
    var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
    audit_begin();
    rt.deferred_submission_sync_policy = .require_fence_pool;
    try device.ensure_submission_state(&rt);
    try device.ensure_deferred_submission_state(&rt);
    const src = try resources.ensure_compute_buffer(&rt, 1, BYTES, true);
    const dst = try resources.ensure_compute_buffer(&rt, 2, BYTES, true);
    _ = try resources.ensure_compute_buffer(&rt, 3, BYTES, true);
    resources.destroy_compute_buffer(&rt, 3);
    @memset(@as([*]u8, @ptrCast(src.mapped.?))[0..BYTES], 0x6b);
    try upload.streaming_copy_buffer_region(&rt, src.buffer, 0, dst.buffer, 0, BYTES);
    try rt.flush_streaming_copy(false);
    if (mode == .direct) _ = rt.compute_buffers.fetchRemove(1);
    const before = audit_buffers();
    audit_hold(loss);
    var job = Job{ .rt = &rt, .mode = mode, .original = src };
    const thread = try std.Thread.spawn(.{}, Job.run, .{&job});
    const start = std.time.nanoTimestamp();
    while (audit_idle_calls() < 3 and !job.done.load(.acquire) and std.time.nanoTimestamp() - start < DEADLINE_NS) {
        std.Thread.sleep(std.time.ns_per_ms);
    }
    const retained = !job.done.load(.acquire) and audit_buffers() == before and audit_premature() == 0;
    var reuse_rejected = false;
    if (comptime @hasField(runtime.NativeVulkanRuntime, "retirement")) {
        if (retained) {
            reuse_rejected = if (resources.create_compute_buffer(&rt, BYTES, true)) |_| false else |_| true;
        }
    }
    audit_allow();
    thread.join();
    const premature = audit_premature();
    std.debug.print("LIFETIME mode={s} loss={d} retained={} reuse_rejected={} waits={d} idle_calls={d} premature={d}\n", .{ @tagName(mode), loss, retained, reuse_rejected, audit_wait_calls(), audit_idle_calls(), premature });
    if (mode != .shutdown) {
        for (@as([*]u8, @ptrCast(dst.mapped.?))[0..BYTES]) |byte| try std.testing.expectEqual(@as(u8, 0x6b), byte);
        if (comptime @hasField(runtime.NativeVulkanRuntime, "retirement")) {
            try std.testing.expectEqual(@as(u64, BYTES), rt.compute_buffer_cache.retained_bytes);
        }
        rt.deinit();
    }
    if (comptime @hasField(runtime.NativeVulkanRuntime, "retirement")) {
        try std.testing.expectEqual(loss != 0, rt.retirement.observed_device_loss);
        rt.deinit();
    }
    try std.testing.expectEqual(@as(i64, 0), audit_buffers());
    try std.testing.expectEqual(@as(i64, 0), audit_memories());
    try std.testing.expectEqual(@as(i64, 0), audit_mappings());
    try std.testing.expectEqual(@as(c_int, 1), audit_destroyed());
    audit_end();
    try std.testing.expect(retained and reuse_rejected);
    try std.testing.expectEqual(@as(c_int, 0), premature);
}
test "shutdown retains owners after failed waiting until delayed device completion" { try exercise(.shutdown, 0); }
test "registered buffer fallback waits and bypasses reuse after unresolved completion" { try exercise(.registered, 0); }
test "direct buffer release retains its allocation until device loss permits cleanup" { try exercise(.direct, 1); }
test "device lost during waiting cleans up without eventual successful execution" { try exercise(.shutdown, 2); }

test "compute cache enforces independent size and byte bounds and reinitializes fresh generations" {
    var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
    defer rt.deinit();
    const options = @import("build_options");
    const limit = if (@hasDecl(options, "vulkan_compute_buffer_cache_max_entries_per_size")) options.vulkan_compute_buffer_cache_max_entries_per_size else upload.MAX_POOL_ENTRIES_PER_SIZE;
    var generation: u64 = 0;
    for (0..limit + 1) |i| {
        const buffer = try resources.ensure_compute_buffer(&rt, i + 1, BYTES, true);
        generation = @max(generation, buffer.generation);
        @memset(@as([*]u8, @ptrCast(buffer.mapped.?))[0..BYTES], 0x6b);
    }
    for (0..limit + 1) |i| resources.destroy_compute_buffer(&rt, i + 1);
    try std.testing.expectEqual(limit, rt.compute_buffer_cache.entries.get(BYTES).?.items.len);
    const reused = try resources.ensure_compute_buffer(&rt, 1, BYTES, true);
    try std.testing.expect(reused.generation > generation);
    for (@as([*]u8, @ptrCast(reused.mapped.?))[0..BYTES]) |byte| try std.testing.expectEqual(@as(u8, 0), byte);
    resources.destroy_compute_buffer(&rt, 1);
    const large = 4 * 1024 * 1024;
    const capacity = options.vulkan_compute_buffer_cache_max_bytes / large;
    for (0..capacity + 1) |i| _ = try resources.ensure_compute_buffer(&rt, i + 1, large, true);
    for (0..capacity + 1) |i| resources.destroy_compute_buffer(&rt, i + 1);
    try std.testing.expect(rt.compute_buffer_cache.retained_bytes <= options.vulkan_compute_buffer_cache_max_bytes);
    try std.testing.expect(rt.compute_buffer_cache.entries.get(large).?.items.len < capacity + 1);
    try std.testing.expectEqual(@as(usize, 8), upload.MAX_POOL_ENTRIES_PER_SIZE);
}
