#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
static unsigned inside, active, resets, begins, ends, draws, failures, pools;
#define NEXT(name) PFN_##name next = (PFN_##name)dlsym(RTLD_NEXT, #name)
VKAPI_ATTR VkResult VKAPI_CALL vkCreateQueryPool(VkDevice d, const VkQueryPoolCreateInfo *i, const VkAllocationCallbacks *a, VkQueryPool *p) {
    NEXT(vkCreateQueryPool); ++pools;
    if(i->queryType != VK_QUERY_TYPE_OCCLUSION) ++failures;
    return next(d,i,a,p);
}
VKAPI_ATTR void VKAPI_CALL vkCmdResetQueryPool(VkCommandBuffer b, VkQueryPool p, uint32_t f, uint32_t n) {
    NEXT(vkCmdResetQueryPool); ++resets; if(inside || active) ++failures; next(b,p,f,n);
}
VKAPI_ATTR void VKAPI_CALL vkCmdBeginRenderPass(VkCommandBuffer b, const VkRenderPassBeginInfo *i, VkSubpassContents c) {
    NEXT(vkCmdBeginRenderPass); if(inside) ++failures; inside=1; next(b,i,c);
}
VKAPI_ATTR void VKAPI_CALL vkCmdBeginQuery(VkCommandBuffer b, VkQueryPool p, uint32_t q, VkQueryControlFlags f) {
    NEXT(vkCmdBeginQuery); ++begins; if(!inside || active || resets != begins) ++failures; active=1; next(b,p,q,f);
}
VKAPI_ATTR void VKAPI_CALL vkCmdDraw(VkCommandBuffer b, uint32_t v, uint32_t i, uint32_t f, uint32_t g) {
    NEXT(vkCmdDraw); if(active) ++draws; next(b,v,i,f,g);
}
VKAPI_ATTR void VKAPI_CALL vkCmdEndQuery(VkCommandBuffer b, VkQueryPool p, uint32_t q) {
    NEXT(vkCmdEndQuery); ++ends; if(!inside || !active) ++failures; active=0; next(b,p,q);
}
VKAPI_ATTR void VKAPI_CALL vkCmdEndRenderPass(VkCommandBuffer b) {
    NEXT(vkCmdEndRenderPass); if(!inside || active) ++failures; inside=0; next(b);
}
__attribute__((destructor)) static void finish(void) {
    if(inside || active || begins != ends || begins != draws || !begins) ++failures;
    fprintf(stderr,"order: pools=%u resets=%u begins=%u draws=%u ends=%u failures=%u\n", pools,resets,begins,draws,ends,failures);
    if(failures) _Exit(86);
}
