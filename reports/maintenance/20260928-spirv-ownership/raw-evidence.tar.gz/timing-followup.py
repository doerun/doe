from pathlib import Path
import os,subprocess,json,time,statistics
root=Path('/tmp/doe-spirv-ownership-20260928');folder=root/'timing-followup';folder.mkdir(exist_ok=True)
cpu=min(os.sched_getaffinity(0));rows=[]
for cohort,pairs in [('unchanged-control',4),('candidate',8)]:
 for pair in range(pairs):
  for arm in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   build='baseline' if cohort=='unchanged-control' else arm
   out=folder/f'{cohort}-{pair}-{arm}.ndjson'
   cmd=['taskset','-c',str(cpu),str(root/build/'bin/doe-compilation-bench'),'--iterations','1000','--warmup','100','--target','spirv','--filter','passthrough_vertex','--out',str(out)]
   p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr
   rows.append({'cohort':cohort,'pair':pair,'arm':arm,'build':build,'command':cmd,'exitCode':p.returncode,'rows':[json.loads(line) for line in out.read_text().splitlines()]})
summary=[]
for cohort in ['unchanged-control','candidate']:
 d={}
 for arm in ['baseline','candidate']:
  v=[next(r for r in p['rows'] if r['kind']=='compilation_bench') for p in rows if p['cohort']==cohort and p['arm']==arm]
  d[arm]={'processP50Ns':[r['p50_ns'] for r in v],'medianProcessP50Ns':statistics.median(r['p50_ns'] for r in v),'medianProcessP95Ns':statistics.median(r['p95_ns'] for r in v)}
 summary.append({'cohort':cohort,**d,'p50ChangePercent':100*(d['candidate']['medianProcessP50Ns']/d['baseline']['medianProcessP50Ns']-1)})
payload={'classification':'diagnostic-followup','reason':'Initial passthrough vertex median increased amid process bimodality; preserve that cohort and test fixed CPU plus unchanged controls.','cpu':cpu,'summaryDefinition':'Central-pair medians of process percentiles; no pooling.','summary':summary,'processes':rows}
(root/'compiler-followup.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(summary,indent=2))
