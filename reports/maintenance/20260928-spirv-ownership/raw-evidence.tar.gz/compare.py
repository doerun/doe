from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/doe-spirv-ownership-20260928')
shaders=sorted(Path('/home/x/deco/doe/bench/kernels/compilation-corpus').glob('*.wgsl'))+[root/'mutation.wgsl',root/'unsupported-pointer-alias.wgsl']
rows=[]
for shader in shaders:
 for target in ['spirv','ir-digest','msl','hlsl']:
  row={'source':str(shader),'sourceSha256':hashlib.sha256(shader.read_bytes()).hexdigest(),'target':target,'observations':[]}
  outputs=[]
  for arm in ['baseline','candidate']:
   output=root/'emitted'/arm/(shader.stem+'.'+target);output.parent.mkdir(parents=True,exist_ok=True)
   command=[str(root/arm/'bin'/('doe-emit-'+target)),'--shader-path',str(shader),'--out',str(output)]
   p=subprocess.run(command,capture_output=True)
   if p.returncode==0 and not output.exists(): output.write_bytes(p.stdout)
   payload=output.read_bytes() if p.returncode==0 else p.stderr
   outputs.append((p.returncode,payload));row['observations'].append({'arm':arm,'command':command,'exitCode':p.returncode,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'error':p.stderr.decode() or None})
   if target=='spirv' and p.returncode==0:
    v=subprocess.run(['spirv-val',str(output)],capture_output=True);row['observations'][-1]['spirvValidation']={'exitCode':v.returncode,'stderr':v.stderr.decode()}
  row['equal']=outputs[0]==outputs[1];rows.append(row)
(root/'parity.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'comparisons':len(rows),'equal':sum(r['equal'] for r in rows),'successful':sum(r['observations'][0]['exitCode']==0 for r in rows),'validationFailures':[(r['source'],o['arm'],o['spirvValidation']) for r in rows for o in r['observations'] if o.get('spirvValidation',{}).get('exitCode',0)]},indent=2))
assert all(r['equal'] for r in rows)
