from pathlib import Path
import hashlib,json,os,subprocess,time,statistics
root=Path('/tmp/doe-spirv-ownership-20260928');folder=root/'timing';folder.mkdir(exist_ok=True)
processes=[]
for pair in range(8):
 for arm in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  exe=root/arm/'bin/doe-compilation-bench';out=folder/f'{pair}-{arm}.ndjson'
  command=[str(exe),'--iterations','300','--warmup','30','--target','spirv','--out',str(out)]
  started=time.monotonic_ns()
  with (folder/f'{pair}-{arm}.log').open('wb') as log:
   p=subprocess.Popen(command,stdout=log,stderr=log);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
  processes.append({'pair':pair,'arm':arm,'command':command,'exitCode':p.returncode,'wallNs':time.monotonic_ns()-started,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'peakProcessRssBytes':usage.ru_maxrss*1024,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'rows':[json.loads(line) for line in out.read_text().splitlines()]})
  assert p.returncode==0
(root/'compiler-observations.json').write_text(json.dumps({'classification':'diagnostic-only','processes':processes},indent=2)+'\n')
print(json.dumps({arm:{'medianProcessWallMs':statistics.median(p['wallNs'] for p in processes if p['arm']==arm)/1e6,'medianProcessCpuMs':statistics.median((p['userSeconds']+p['systemSeconds'])*1000 for p in processes if p['arm']==arm)} for arm in ['baseline','candidate']},indent=2))
