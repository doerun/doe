import subprocess,os,json
from pathlib import Path
root=Path('/tmp/doe-surface-20260928')
env=dict(os.environ,DISPLAY=':0',XAUTHORITY='/run/user/1000/.mutter-Xwaylandauth.PU83T3',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/radeon_icd.json',LD_PRELOAD=str(root/'observer.so'))
rows=[]
for mode in ['normal','empty','submit-reject','present-reject','outdated','acquire-wait','present-wait','create-fence','create-view','create-semaphore','images','unsupported','device-lost']:
 p=subprocess.run([str(root/'candidate-test'),mode],env=env,capture_output=True,text=True,timeout=30)
 output=p.stdout+p.stderr
 (root/f'{mode}.log').write_text(output)
 observed=[json.loads(line) for line in output.splitlines() if line.startswith('{"observer"')]
 print(mode,p.returncode,observed,flush=True)
 rows.append({'mode':mode,'exitCode':p.returncode,'observations':observed,'output':output})
(root/'public-results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['exitCode']==0 and len(r['observations'])==1 and r['observations'][0]['violations']==0 for r in rows)
