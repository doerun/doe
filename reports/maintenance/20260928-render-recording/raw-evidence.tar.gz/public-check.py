import subprocess,os,json
from pathlib import Path
root=Path('/tmp/doe-render-context-20260928');rows=[]
for arm in ['baseline','candidate']:
 for mode in ['direct','indexed16','indexed32','indirect','indexed-indirect']:
  env=dict(os.environ,VK_DRIVER_FILES='/usr/share/vulkan/icd.d/radeon_icd.json',LD_LIBRARY_PATH=str(root/arm/'lib'),LD_PRELOAD=str(root/'order.so'))
  with (root/f'{arm}-{mode}.log').open('w') as f:
   p=subprocess.run([str(root/'public-test'),mode],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=20)
  rows.append({'arm':arm,'mode':mode,'exitCode':p.returncode})
(root/'public-results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['exitCode']==0 for r in rows if r['arm']=='candidate')
print('Public draw modes passed; predecessor indexed failures retained.')
