#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
static atomic_int enabled, hold, lost, waits, idles, destroyed, premature;
static VkBuffer bound_index;
static int freed_index;
static atomic_int reject_buffer;
void audit_reject_buffer(void) { atomic_store(&reject_buffer, 1); }
static atomic_int reject_next;
void audit_reject_next(void) { atomic_store(&reject_next, 1); }
static atomic_llong buffers, memories, mappings;
#define TRACKED_HANDLES 4096
static uintptr_t buffer_handles[TRACKED_HANDLES], memory_handles[TRACKED_HANDLES], mapped_handles[TRACKED_HANDLES];
static pthread_mutex_t handles_lock = PTHREAD_MUTEX_INITIALIZER;
static void acquired(uintptr_t *handles, uintptr_t handle) {
    pthread_mutex_lock(&handles_lock);
    size_t slot = TRACKED_HANDLES;
    for (size_t i = 0; i < TRACKED_HANDLES; i++) {
        assert(handles[i] != handle);
        if (!handles[i] && slot == TRACKED_HANDLES) slot = i;
    }
    assert(handle && slot != TRACKED_HANDLES);
    handles[slot] = handle;
    pthread_mutex_unlock(&handles_lock);
}
static void released(uintptr_t *handles, uintptr_t handle) {
    if (!handle) return;
    pthread_mutex_lock(&handles_lock);
    size_t slot = TRACKED_HANDLES;
    for (size_t i = 0; i < TRACKED_HANDLES; i++) if (handles[i] == handle) { slot = i; break; }
    assert(slot != TRACKED_HANDLES);
    handles[slot] = 0;
    pthread_mutex_unlock(&handles_lock);
}
#define NEXT(name) PFN_##name real = (PFN_##name)dlsym(RTLD_NEXT, #name); if (!real) abort()
void audit_begin(void) { atomic_store(&enabled, 0); atomic_store(&hold, 0); atomic_store(&lost, 0); atomic_store(&waits, 0); atomic_store(&idles, 0); atomic_store(&destroyed, 0); atomic_store(&premature, 0); atomic_store(&buffers, 0); atomic_store(&memories, 0); atomic_store(&mappings, 0); }
void audit_hold(int loss) { atomic_store(&lost, loss); atomic_store(&hold, 1); atomic_store(&enabled, 1); }
void audit_allow(void) { atomic_store(&hold, 0); }
void audit_end(void) { atomic_store(&enabled, 0); }
int audit_idle_calls(void) { return atomic_load(&idles); }
int audit_wait_calls(void) { return atomic_load(&waits); }
int audit_destroyed(void) { return atomic_load(&destroyed); }
int audit_premature(void) { return atomic_load(&premature); }
int64_t audit_buffers(void) { return atomic_load(&buffers); }
int64_t audit_memories(void) { return atomic_load(&memories); }
int64_t audit_mappings(void) { return atomic_load(&mappings); }
static void releasing(void) { if (atomic_load(&enabled) && atomic_load(&hold)) atomic_fetch_add(&premature, 1); }
VKAPI_ATTR VkResult VKAPI_CALL vkCreateBuffer(VkDevice d,const VkBufferCreateInfo *i,const VkAllocationCallbacks *a,VkBuffer *b) { NEXT(vkCreateBuffer); if (atomic_exchange(&reject_buffer,0)) return VK_ERROR_OUT_OF_HOST_MEMORY; VkResult r=real(d,i,a,b); if(r==VK_SUCCESS) { acquired(buffer_handles,(uintptr_t)*b); atomic_fetch_add(&buffers,1); } return r; }
VKAPI_ATTR void VKAPI_CALL vkDestroyBuffer(VkDevice d,VkBuffer b,const VkAllocationCallbacks *a) { NEXT(vkDestroyBuffer); if (b == bound_index) freed_index = 1; releasing(); released(buffer_handles,(uintptr_t)b); if(b)atomic_fetch_sub(&buffers,1); real(d,b,a); }
VKAPI_ATTR VkResult VKAPI_CALL vkAllocateMemory(VkDevice d,const VkMemoryAllocateInfo *i,const VkAllocationCallbacks *a,VkDeviceMemory *m) { NEXT(vkAllocateMemory); VkResult r=real(d,i,a,m); if(r==VK_SUCCESS) { acquired(memory_handles,(uintptr_t)*m); atomic_fetch_add(&memories,1); } return r; }
VKAPI_ATTR void VKAPI_CALL vkFreeMemory(VkDevice d,VkDeviceMemory m,const VkAllocationCallbacks *a) { NEXT(vkFreeMemory); releasing(); released(memory_handles,(uintptr_t)m); if(m)atomic_fetch_sub(&memories,1); real(d,m,a); }
VKAPI_ATTR VkResult VKAPI_CALL vkMapMemory(VkDevice d,VkDeviceMemory m,VkDeviceSize o,VkDeviceSize s,VkMemoryMapFlags f,void **p) { NEXT(vkMapMemory); VkResult r=real(d,m,o,s,f,p); if(r==VK_SUCCESS) { acquired(mapped_handles,(uintptr_t)m); atomic_fetch_add(&mappings,1); } return r; }
VKAPI_ATTR void VKAPI_CALL vkUnmapMemory(VkDevice d,VkDeviceMemory m) { NEXT(vkUnmapMemory); releasing(); released(mapped_handles,(uintptr_t)m); atomic_fetch_sub(&mappings,1); real(d,m); }
VKAPI_ATTR VkResult VKAPI_CALL vkGetFenceStatus(VkDevice d,VkFence f) { NEXT(vkGetFenceStatus); if(atomic_load(&enabled))return VK_NOT_READY; return real(d,f); }
VKAPI_ATTR VkResult VKAPI_CALL vkWaitForFences(VkDevice d,uint32_t n,const VkFence *f,VkBool32 all,uint64_t ns) { NEXT(vkWaitForFences); VkResult r=real(d,n,f,all,ns); if(atomic_load(&enabled) && r==VK_SUCCESS) { atomic_fetch_add(&waits,1); return atomic_load(&lost)==2 ? VK_ERROR_DEVICE_LOST : VK_TIMEOUT; } return r; }
VKAPI_ATTR VkResult VKAPI_CALL vkDeviceWaitIdle(VkDevice d) { NEXT(vkDeviceWaitIdle); if(atomic_load(&enabled)) { atomic_fetch_add(&idles,1); if(atomic_load(&hold))return VK_ERROR_OUT_OF_HOST_MEMORY; VkResult r=real(d); if(r==VK_SUCCESS && atomic_load(&lost)==1)return VK_ERROR_DEVICE_LOST; return r; } return real(d); }
VKAPI_ATTR void VKAPI_CALL vkDestroyDevice(VkDevice d,const VkAllocationCallbacks *a) { NEXT(vkDestroyDevice); releasing(); atomic_fetch_add(&destroyed,1); real(d,a); }

VKAPI_ATTR void VKAPI_CALL vkCmdBindIndexBuffer(VkCommandBuffer cb,VkBuffer b,VkDeviceSize o,VkIndexType ty) { NEXT(vkCmdBindIndexBuffer); bound_index=b; freed_index=0; real(cb,b,o,ty); }
VKAPI_ATTR VkResult VKAPI_CALL vkQueueSubmit(VkQueue q,uint32_t n,const VkSubmitInfo *i,VkFence f) { NEXT(vkQueueSubmit); if(atomic_exchange(&reject_next, 0))return VK_ERROR_OUT_OF_HOST_MEMORY; if(freed_index) { freed_index=0; bound_index=VK_NULL_HANDLE; return VK_ERROR_OUT_OF_HOST_MEMORY; } VkResult r=real(q,n,i,f); bound_index=VK_NULL_HANDLE; return r; }
VKAPI_ATTR void VKAPI_CALL vkDestroyFramebuffer(VkDevice d,VkFramebuffer h,const VkAllocationCallbacks *a) { NEXT(vkDestroyFramebuffer); releasing(); real(d,h,a); }
VKAPI_ATTR void VKAPI_CALL vkDestroyRenderPass(VkDevice d,VkRenderPass h,const VkAllocationCallbacks *a) { NEXT(vkDestroyRenderPass); releasing(); real(d,h,a); }
VKAPI_ATTR void VKAPI_CALL vkDestroyPipeline(VkDevice d,VkPipeline h,const VkAllocationCallbacks *a) { NEXT(vkDestroyPipeline); releasing(); real(d,h,a); }
VKAPI_ATTR void VKAPI_CALL vkDestroyImage(VkDevice d,VkImage h,const VkAllocationCallbacks *a) { NEXT(vkDestroyImage); releasing(); real(d,h,a); }

VKAPI_ATTR VkResult VKAPI_CALL vkWaitSemaphores(VkDevice d,const VkSemaphoreWaitInfo *i,uint64_t ns) { NEXT(vkWaitSemaphores); VkResult r=real(d,i,ns); if(atomic_load(&enabled) && r==VK_SUCCESS) { atomic_fetch_add(&waits,1); return atomic_load(&lost)==2 ? VK_ERROR_DEVICE_LOST : VK_TIMEOUT; } return r; }
