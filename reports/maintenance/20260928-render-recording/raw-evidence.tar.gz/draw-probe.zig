const std = @import("std");
const runtime = @import("src/backend/vulkan/native_runtime.zig");
const render = @import("src/backend/vulkan/vk_render.zig");
extern fn audit_reject_next() void;
extern fn audit_reject_buffer() void;
extern fn audit_begin() void;
extern fn audit_hold(c_int) void;
extern fn audit_allow() void;
extern fn audit_end() void;
extern fn audit_idle_calls() c_int;
extern fn audit_premature() c_int;
extern fn audit_memories() i64;
const Job = struct {
    rt: *runtime.NativeVulkanRuntime,
    done: std.atomic.Value(bool) = std.atomic.Value(bool).init(false),
    failed: bool = false,
    fn run(self: *@This()) void {
        _ = draw(self.rt) catch { self.failed = true; };
        self.done.store(true, .release);
    }
};
fn exercise(loss: c_int, timeline: bool) !void {
    var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
    if (timeline) {
        rt.deferred_submission_sync_policy = .prefer_timeline_semaphore;
        try @import("src/backend/vulkan/vk_device.zig").ensure_deferred_submission_state(&rt);
        try std.testing.expect(rt.has_timeline_semaphore);
    }
    audit_begin();
    audit_hold(loss);
    var job = Job{ .rt = &rt };
    const thread = try std.Thread.spawn(.{}, Job.run, .{&job});
    const start = std.time.nanoTimestamp();
    while (audit_idle_calls() < 3 and !job.done.load(.acquire) and std.time.nanoTimestamp() - start < 5 * std.time.ns_per_s) std.Thread.sleep(std.time.ns_per_ms);
    const retained = !job.done.load(.acquire) and audit_memories() > 0 and audit_premature() == 0;
    audit_allow();
    thread.join();
    const premature = audit_premature();
    std.debug.print("RENDER loss={d} timeline={} retained={} failed={} idle_calls={d} premature={d}\n", .{ loss, timeline, retained, job.failed, audit_idle_calls(), premature });
    if (retained) {
        try std.testing.expectError(if (loss == 0) error.InvalidState else error.DeviceLost, draw(&rt));
    }
    rt.deinit();
    rt.deinit();
    audit_end();
    try std.testing.expectEqual(@as(i64, 0), audit_memories());
    try std.testing.expect(job.failed and retained);
    try std.testing.expectEqual(@as(c_int, 0), premature);
}
test "render failed fence wait retains attachments until delayed completion" { try exercise(0, false); }
test "render failed wait retains attachments until device loss" { try exercise(1, false); }
test "render confirmed device loss preserves failed operation" { try exercise(2, false); }

test "render failed timeline wait retains attachments until delayed completion" { try exercise(0, true); }
test "render failed timeline wait retains attachments until device loss" { try exercise(1, true); }
test "render timeline device loss preserves failed operation" { try exercise(2, true); }

test "render rejected submissions preserve retry for fence and timeline" {
    for ([_]bool{ false, true }) |timeline| {
        var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
        defer rt.deinit();
        if (timeline) {
            rt.deferred_submission_sync_policy = .prefer_timeline_semaphore;
            try @import("src/backend/vulkan/vk_device.zig").ensure_deferred_submission_state(&rt);
            try std.testing.expect(rt.has_timeline_semaphore);
        }
        audit_begin();
        audit_reject_next();
        try std.testing.expectError(error.InvalidState, draw(&rt));
        try std.testing.expectEqual(.active, rt.retirement.phase);
        _ = try draw(&rt);
        try std.testing.expectEqual(@as(i64, 0), audit_memories());
        audit_end();
    }
}

fn draw(rt: *runtime.NativeVulkanRuntime) !@import("src/backend/vulkan/vk_metrics.zig").DispatchMetrics {
    const compiler = @import("src/compiler/wgsl/mod.zig");
    var vertex: [compiler.MAX_SPIRV_OUTPUT]u8 align(@alignOf(u32)) = undefined;
    var fragment: [compiler.MAX_SPIRV_OUTPUT]u8 align(@alignOf(u32)) = undefined;
    const vs = try compiler.translateToSpirv(std.testing.allocator, "@vertex fn main(@builtin(vertex_index) i:u32)->@builtin(position) vec4f { var p = array<vec2f,3>(vec2f(-1,-1),vec2f(3,-1),vec2f(-1,3)); return vec4f(p[i],0,1); }", &vertex);
    const fs = try compiler.translateToSpirv(std.testing.allocator, "@fragment fn main()->@location(0) vec4f { return vec4f(1,0,0,1); }", &fragment);
    return render.execute_render_draw(rt, .{ .draw_count=1, .target_width=4, .target_height=4, .index_data=.{ .uint16=&.{0,1,2} }, .vertex_spirv=std.mem.bytesAsSlice(u32,vertex[0..vs]), .fragment_spirv=std.mem.bytesAsSlice(u32,fragment[0..fs]) });
}

test "draw index allocation rejection cleans up before recording and permits retry" {
    var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
    defer rt.deinit();
    audit_begin();
    audit_reject_buffer();
    try std.testing.expectError(error.InvalidState, draw(&rt));
    try std.testing.expectEqual(@as(i64, 0), audit_memories());
    try std.testing.expectEqual(.active, rt.retirement.phase);
    _ = try draw(&rt);
    try std.testing.expectEqual(@as(i64, 0), audit_memories());
    audit_end();
}
