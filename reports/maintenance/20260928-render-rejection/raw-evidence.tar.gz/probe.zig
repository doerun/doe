const std = @import("std");
const runtime = @import("src/backend/vulkan/native_runtime.zig");
const render = @import("src/backend/vulkan/vk_render.zig");
const resources = @import("src/backend/vulkan/vk_resources.zig");
const bundle = @import("src/runtime/render/render_bundle.zig");
const textures = @import("src/contracts/model/model_texture_value_types.zig");
const vk = @import("src/backend/vulkan/vk_constants.zig");
extern fn audit_live() c_int;
extern fn audit_submits() c_int;
extern fn audit_binds() c_int;
extern fn audit_fail_framebuffer() void;

test "physical bundle rejection submission and cleanup" {
    for ([_]bool{ false, true }) |timeline| {
        var rt = try runtime.NativeVulkanRuntime.init(std.testing.allocator, null);
        defer rt.deinit();
        try @import("src/backend/vulkan/vk_device.zig").ensure_submission_state(&rt);
        if (timeline) try @import("src/backend/vulkan/vk_device.zig").create_timeline_semaphore(&rt);
        if (timeline and !rt.has_timeline_semaphore) return error.TimelineUnavailable;
        rt.has_timeline_semaphore = timeline;
        const vertex = try resources.create_host_visible_buffer(&rt, 16, vk.VK_BUFFER_USAGE_VERTEX_BUFFER_BIT);
        defer {
            if (vertex.mapped != null) vk.vkUnmapMemory(rt.device, vertex.memory);
            vk.vkDestroyBuffer(rt.device, vertex.buffer, null);
            vk.vkFreeMemory(rt.device, vertex.memory, null);
        }
        var cmds = [_]bundle.BundleCmd{.{ .set_vertex_buffer = .{ .slot = 0, .buffer_handle = @ptrFromInt(vertex.buffer), .offset = 0, .size = 16 } }};
        const valid = bundle.DoeRenderBundle{ .allocator = std.testing.allocator, .backend = .vulkan, .color_format = textures.WGPUTextureFormat_RGBA8Unorm, .depth_stencil_format = 0, .sample_count = 1, .cmds = &cmds };
        for ([_]bundle.ReplayError{ error.InvalidBundle, error.FormatMismatch, error.SampleCountMismatch }) |expected| {
            var invalid = valid;
            switch (expected) {
                error.InvalidBundle => invalid.error_object = true,
                error.FormatMismatch => invalid.color_format = textures.WGPUTextureFormat_BGRA8Unorm,
                error.SampleCountMismatch => invalid.sample_count = 4,
            }
            for ([_][]const *const bundle.DoeRenderBundle{ &.{&invalid}, &.{ &valid, &invalid } }) |sequence| {
                const live = audit_live();
                const submits = audit_submits();
                const binds = audit_binds();
                const result = render.execute_render_bundles(&rt, sequence, 4, 4, valid.color_format, 1);
                std.debug.print("timeline={} bundles={d} result={any} submits={d} binds={d} live_delta={d}\n", .{ timeline, sequence.len, result, audit_submits()-submits, audit_binds()-binds, audit_live()-live });
                try std.testing.expectError(expected, result);
                try std.testing.expectEqual(submits, audit_submits());
                try std.testing.expectEqual(@as(c_int, @intCast(sequence.len - 1)), audit_binds()-binds);
                try std.testing.expectEqual(live, audit_live());
                _ = try render.execute_render_bundles(&rt, &.{&valid}, 4, 4, valid.color_format, 1);
                try std.testing.expectEqual(submits+1, audit_submits());
                try std.testing.expectEqual(live, audit_live());
            }
        }
        const live = audit_live();
        const submits = audit_submits();
        audit_fail_framebuffer();
        try std.testing.expectError(error.InvalidState, render.execute_render_bundles(&rt, &.{&valid}, 4, 4, valid.color_format, 1));
        try std.testing.expectEqual(submits, audit_submits());
        try std.testing.expectEqual(live, audit_live());
        _ = try render.execute_render_bundles(&rt, &.{&valid}, 4, 4, valid.color_format, 1);
        try std.testing.expectEqual(live, audit_live());
    }
    try std.testing.expectEqual(@as(c_int, 0), audit_live());
}
