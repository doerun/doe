#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <assert.h>
#include <stdint.h>

#define CAPACITY 1024
static uint64_t images[CAPACITY], views[CAPACITY], memory[CAPACITY], passes[CAPACITY], frames[CAPACITY];
static int live, submits, binds, fail_framebuffer;
static void add(uint64_t *set, uint64_t handle) {
    assert(handle);
    for (int i=0;i<CAPACITY;i++) assert(set[i]!=handle);
    for (int i=0;i<CAPACITY;i++) if(!set[i]) { set[i]=handle; live++; return; }
    assert(0);
}
static void remove_handle(uint64_t *set, uint64_t handle) {
    if(!handle) return;
    for(int i=0;i<CAPACITY;i++) if(set[i]==handle) { set[i]=0; live--; return; }
    assert(0);
}
int audit_live(void) { return live; }
int audit_submits(void) { return submits; }
int audit_binds(void) { return binds; }
void audit_fail_framebuffer(void) { fail_framebuffer=1; }
#define CREATE(Name,Type,Info,Set) \
VKAPI_ATTR VkResult VKAPI_CALL vkCreate##Name(VkDevice d,const Info *i,const VkAllocationCallbacks *a,Type *o) { \
 PFN_vkCreate##Name f=(PFN_vkCreate##Name)dlsym(RTLD_NEXT,"vkCreate" #Name); \
 VkResult r=f(d,i,a,o); if(r==VK_SUCCESS) add(Set,(uint64_t)*o); return r; }
#define DESTROY(Name,Type,Set) \
VKAPI_ATTR void VKAPI_CALL vkDestroy##Name(VkDevice d,Type h,const VkAllocationCallbacks *a) { \
 remove_handle(Set,(uint64_t)h); \
 ((PFN_vkDestroy##Name)dlsym(RTLD_NEXT,"vkDestroy" #Name))(d,h,a); }
CREATE(Image,VkImage,VkImageCreateInfo,images)
CREATE(ImageView,VkImageView,VkImageViewCreateInfo,views)
CREATE(RenderPass,VkRenderPass,VkRenderPassCreateInfo,passes)
DESTROY(Image,VkImage,images)
DESTROY(ImageView,VkImageView,views)
DESTROY(RenderPass,VkRenderPass,passes)
DESTROY(Framebuffer,VkFramebuffer,frames)
VKAPI_ATTR VkResult VKAPI_CALL vkCreateFramebuffer(VkDevice d,const VkFramebufferCreateInfo *i,const VkAllocationCallbacks *a,VkFramebuffer *o) {
 if(fail_framebuffer) { fail_framebuffer=0; return VK_ERROR_OUT_OF_HOST_MEMORY; }
 VkResult r=((PFN_vkCreateFramebuffer)dlsym(RTLD_NEXT,"vkCreateFramebuffer"))(d,i,a,o);
 if(r==VK_SUCCESS) add(frames,(uint64_t)*o); return r;
}
VKAPI_ATTR VkResult VKAPI_CALL vkAllocateMemory(VkDevice d,const VkMemoryAllocateInfo *i,const VkAllocationCallbacks *a,VkDeviceMemory *o) {
 VkResult r=((PFN_vkAllocateMemory)dlsym(RTLD_NEXT,"vkAllocateMemory"))(d,i,a,o);
 if(r==VK_SUCCESS) add(memory,(uint64_t)*o); return r;
}
VKAPI_ATTR void VKAPI_CALL vkFreeMemory(VkDevice d,VkDeviceMemory m,const VkAllocationCallbacks *a) {
 remove_handle(memory,(uint64_t)m);
 ((PFN_vkFreeMemory)dlsym(RTLD_NEXT,"vkFreeMemory"))(d,m,a);
}
VKAPI_ATTR VkResult VKAPI_CALL vkQueueSubmit(VkQueue q,uint32_t n,const VkSubmitInfo *i,VkFence f) {
 submits++;
 return ((PFN_vkQueueSubmit)dlsym(RTLD_NEXT,"vkQueueSubmit"))(q,n,i,f);
}
VKAPI_ATTR void VKAPI_CALL vkCmdBindVertexBuffers(VkCommandBuffer c,uint32_t f,uint32_t n,const VkBuffer *b,const VkDeviceSize *o) {
 binds++;
 ((PFN_vkCmdBindVertexBuffers)dlsym(RTLD_NEXT,"vkCmdBindVertexBuffers"))(c,f,n,b,o);
}
