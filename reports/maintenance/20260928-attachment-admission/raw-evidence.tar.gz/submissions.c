#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdio.h>
VKAPI_ATTR VkResult VKAPI_CALL vkQueueSubmit(VkQueue q, uint32_t n, const VkSubmitInfo *s, VkFence f) {
    PFN_vkQueueSubmit next = (PFN_vkQueueSubmit)dlsym(RTLD_NEXT,"vkQueueSubmit");
    fprintf(stderr,"native-submit count=%u\n",n);
    return next(q,n,s,f);
}
