import subprocess,os,json,time,statistics,hashlib
from pathlib import Path
root=Path('/tmp/doe-attachment-20260928');rows=[];cpu=min(os.sched_getaffinity(0))
for pair in range(10):
 for arm in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  env=dict(os.environ,VK_DRIVER_FILES='/usr/share/vulkan/icd.d/radeon_icd.json',LD_LIBRARY_PATH=str(root/arm/'lib'));env.pop('LD_PRELOAD',None)
  cmd=['taskset','-c',str(cpu),str(root/'query-test'),'direct']
  with (root/f'cost-{pair}-{arm}.log').open('w') as f:
   start=time.monotonic_ns();p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);wall=time.monotonic_ns()-start
  assert p.returncode==0
  rows.append({'pair':pair,'arm':arm,'command':cmd,'exitCode':p.returncode,'wallNs':wall,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'peakProcessRssBytes':usage.ru_maxrss*1024})
x={'classification':'diagnostic-only','scope':'Complete direct public fixture process including startup, shader/pipeline compilation, draws, query resolve, readback and teardown; no resident-operation timing.','cpu':cpu,'instrumentation':'disabled','summaryDefinition':'Central-pair median and nearest-rank p95 across independent processes; no sample pooling.','samples':rows,'summary':{}}
for arm in ['baseline','candidate']:
 r=[v for v in rows if v['arm']==arm];times=sorted(v['wallNs']/1e6 for v in r)
 x['summary'][arm]={'medianWallMs':statistics.median(times),'p95WallMs':times[-1],'medianCpuMs':statistics.median((v['userSeconds']+v['systemSeconds'])*1000 for v in r),'medianPeakProcessRssBytes':statistics.median(v['peakProcessRssBytes'] for v in r)}
(root/'process-observations.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x['summary'],indent=2))
