# Cerebras operator: ask

Operator-facing page for whoever at Cerebras is running the validation
on the endpoint. Tight and single-purpose. The rest of the bundle's
documents are reviewer-facing; this one is for the person pressing
Enter on the hardware.

Before running, read `MODEL_ACCESS.md` in the bundle. It pins model-access
policy, writable Hugging Face cache env vars, and the claim boundary. The
primary hardware ask is the Gemma 4 31B af16 full-prompt HostPlan run. Qwen
3.6 27B now has a matching af16 full-prompt HostPlan wrapper for the companion
hybrid-architecture lane. The layer-block runner is a bounded fallback, not
the main claim.

Current local bridge evidence: the selected-token lm-head splice at
`bench/out/r3-1-31b-af16-doppler-csl-splice/selected-logit-splice/selected-logit-splice.json`
uses the real Gemma 4 31B af16 hidden state for
`<bos>The color of the sky is`, real tied lm-head weights, and generated CSL.
It computes token `3730` (` blue`) with
`logitAbsDiff=0.008741699047892126` against the Doppler/WebGPU reference.
This is not full hardware parity; it is the local bridge proof the hardware
path is meant to extend.

The Qwen companion receipt is
`bench/out/r3-2-27b-af16-doppler-csl-splice/selected-logit-splice/selected-logit-splice.json`.
It binds the real Qwen 3.6 27B final-prompt state, final RMSNorm, selected
Q4_K_M lm-head row, generated CSL, and Doppler prefill-logit parity. It has
the same boundary: selected-logit local proof, not a hardware receipt.

## Two paths

**Path A: endpoint access.** We run the runner from our side against a
Cerebras-provided endpoint:

1. **Reachable CS/WSC endpoint.** Either a direct `--cmaddr <ip:port>`
   target or an appliance SdkLauncher endpoint.
2. **SDK Python environment** matching the `csPython` on the bundler's
   host. SDK 2.10 is the active Doe CSL floor; older receipts are
   historical and should not be used for new hardware claims.
3. **Authorization to run the runner** in `bench/runners/csl-runners/`
   against the endpoint with the pinned manifest, HostPlan, CSL, and
   Doppler weight artifact.

**Path B: Cerebras-assisted source checkout run.** A Cerebras engineer
runs the same commands internally and returns the receipt artifacts:

1. **Clone Doe at the archive commit** and verify the archive.
2. **Fetch the Doppler RDRR artifact** from `Clocksmith/rdrr`, or mount an
   already-validated copy.
3. **Build generated CSL, compile it with cslc, run the full-prompt
   HostPlan runner, and return the trace artifacts.**
4. **Redact what your policy requires.** Every `hardware.*` field has
   an explicit `"redacted"` convention so we can compare receipts
   without leaking endpoint identity.

## What to run

Clone the source checkout. For a repo-published bundle, the archive is already
in the checkout and the wrapper verifies it before running:

```bash
git clone https://github.com/doe-gpu/doe.git
cd doe
git checkout <bundle-commit>

python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install numpy jsonschema huggingface_hub

mkdir -p bench/out/hardware-run
```

Then run the Gemma wrapper. It performs the hosted RDRR fetch and validation,
bundled archive verification, SDK compile from the bundled HostPlan source,
and full-prompt hardware execution. The endpoint is the required run
parameter.

```bash
export CMADDR=<operator-supplied>

bench/tools/run_gemma4_31b_af16_hardware_path.sh \
  --cmaddr "$CMADDR"
```

`Clocksmith/rdrr` is publicly fetchable. Pass `--hf-token <token>` only if the
host wants authenticated Hugging Face access. The default path does not require
`zig`; use `--rebuild-hostplan` only when regenerating HostPlan/CSL from the
execution-v1 input:

```bash
bench/tools/run_gemma4_31b_af16_hardware_path.sh \
  --cmaddr "$CMADDR" \
  --rebuild-hostplan
```

If the evidence archive is supplied separately instead of through the repo,
pass `--archive <path>`.

For the Qwen companion lane, use the matching wrapper:

```bash
bench/tools/run_qwen3_6_27b_af16_hardware_path.sh \
  --cmaddr "$CMADDR"
```

That wrapper fetches `Clocksmith/rdrr` revision
`3dee21b3b12d65ac7fef9b24cbf759cacc953a67`, model path
`models/qwen-3-6-27b-q4k-eaf16`, and the shared weight pack
`models/qwen-3-6-27b-q4k-ehaf16`. It uses the bundled HostPlan source under
`bench/fixtures/cerebras-hostplans/qwen3-6-27b-af16/`.

The hardware host must also provide the Cerebras SDK surface: `cslc` on
`PATH` or passed with `--cslc-executable`, and a Python environment that can
import `cerebras.sdk.runtime.sdkruntimepybind`.

The wrapper expands to the commands below. Keep them here for audit and for
operators who prefer each step separated.

Fetch the hosted model artifact if a validated RDRR copy is not already
mounted. The af16 manifest references the af32 primary weight pack through
`weightsRef`, so both paths must be present under the same local root:

```bash
export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-$HF_HOME/hub}"
export HF_HUB_CACHE="${HF_HUB_CACHE:-$HF_HOME/hub}"
export DOE_RDRR_ROOT="${DOE_RDRR_ROOT:-$PWD/../rdrr-cache/Clocksmith-rdrr}"

hf auth login --token <token> --add-to-git-credential false

hf download Clocksmith/rdrr \
  --repo-type model \
  --revision e6f36589da5f860d9da9b10efdc945434f1f1be2 \
  --include "models/gemma-4-31b-it-text-q4k-ehf16-af16/*" \
  --include "models/gemma-4-31b-it-text-q4k-ehf16-af32/*" \
  --local-dir "$DOE_RDRR_ROOT"

export DOE_GEMMA4_31B_AF16_MANIFEST="$DOE_RDRR_ROOT/models/gemma-4-31b-it-text-q4k-ehf16-af16/manifest.json"
```

Validate the manifest and shared Q4K shards:

```bash
python3 - <<'PY'
import json
import os
import hashlib
from pathlib import Path

def sha256_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()

manifest_path = Path(os.environ["DOE_GEMMA4_31B_AF16_MANIFEST"]).resolve()
manifest = json.loads(manifest_path.read_text())
assert manifest["modelId"] == "gemma-4-31b-it-text-q4k-ehf16-af16"
weights_ref = manifest["weightsRef"]
weights_root = (manifest_path.parent / weights_ref["artifactRoot"]).resolve()
weights_manifest = json.loads((weights_root / "manifest.json").read_text())
assert sha256_file(weights_root / "manifest.json") == weights_ref["manifestDigest"]
assert weights_manifest["artifactIdentity"]["shardSetHash"] == weights_ref["shardSetHash"]
missing = [
    shard["filename"]
    for shard in weights_manifest["shards"]
    if not (weights_root / shard["filename"]).is_file()
]
if missing:
    raise SystemExit(f"missing Doppler weight shards: {missing[:5]}")
print(f"validated {manifest_path}")
PY
```

Build the generated HostPlan/CSL bundle and compile the targets:

```bash
zig build csl-host-plan-tool

runtime/zig/zig-out/bin/doe-csl-host-plan-tool \
  --input runtime/zig/examples/execution-v1/gemma-4-31b-af16-smoke.json \
  --bundle-root bench/out/hardware-run/gemma4-31b-af16-hostplan \
  --mode steps \
  --cslc-executable cslc

python3 runtime/zig/tools/csl_sdk_driver.py \
  bench/out/hardware-run/gemma4-31b-af16-hostplan/simulator-plan.json \
  --cslc-executable cslc
```

Replace `cslc` with the SDK-local executable path if it is not on `PATH`.

Run the full-prompt hardware path. The prompt token IDs are
`<bos>The color of the sky is`; the Doppler reference continuation is
token `3730` (` blue`).

```bash
python3 bench/runners/csl-runners/gemma4_31b_af16_hostplan_streaming_runner.py \
  --source-doppler-manifest "$DOE_GEMMA4_31B_AF16_MANIFEST" \
  --smoke-config runtime/zig/examples/execution-v1/gemma-4-31b-af16-smoke.json \
  --host-plan bench/out/hardware-run/gemma4-31b-af16-hostplan/host-plan.json \
  --simulator-plan bench/out/hardware-run/gemma4-31b-af16-hostplan/simulator-plan.json \
  --runtime-config bench/out/hardware-run/gemma4-31b-af16-hostplan/runtime-config.json \
  --compile-root bench/out/hardware-run/gemma4-31b-af16-hostplan/compile \
  --prefill-token-count 7 \
  --decode-token-count 2 \
  --prompt-token-id 2 \
  --prompt-token-id 818 \
  --prompt-token-id 2258 \
  --prompt-token-id 529 \
  --prompt-token-id 506 \
  --prompt-token-id 7217 \
  --prompt-token-id 563 \
  --execute \
  --cmaddr <operator-supplied> \
  --session-lm-head-dispatch-mode dense_gemv_width_tiled_session \
  --session-lm-head-tile-width 32 \
  --session-lm-head-tile-dispatch-budget 0 \
  --session-prefill-q4k-gemv-output-pe-rows 4 \
  --session-out-dir bench/out/hardware-run/gemma4-31b-af16-session \
  --out bench/out/hardware-run/gemma4-31b-af16-trace.json
```

Return the top-level trace, the session trace, the progress log, and
the driver result files under `bench/out/hardware-run/`.

## Bounded fallback runs

These are useful if the endpoint owner wants a smaller preflight first.
They are not full-prompt Gemma 4 31B evidence.

Layer-block smoke on real-weight smoke slices:

```bash
export DOE_GEMMA4_31B_SAFETENSORS_DIR="${DOE_GEMMA4_31B_SAFETENSORS_DIR:-$PWD/../model-downloads/gemma-4-31B-it}"

hf download google/gemma-4-31B-it \
  --revision 439edf5652646a0d1bd8b46bfdc1d3645761a445 \
  --local-dir "$DOE_GEMMA4_31B_SAFETENSORS_DIR"
```

```bash
python3 bench/tools/extract_gemma4_31b_weight_slices.py \
  --source-dir "$DOE_GEMMA4_31B_SAFETENSORS_DIR" \
  --projection-substitute-tensor pre_feedforward_layernorm.weight \
  --linear-attention-policy skip-with-layout-metadata \
  --out-dir bench/out/gemma-4-31b-real-weights \
  --out-json bench/out/gemma-4-31b-real-weights/verdict.json

cs_python bench/runners/csl-runners/gemma_4_31b_layer_block_smoke.py \
  --num-layers 61 \
  --size 1024 \
  --weights-dir bench/out/gemma-4-31b-real-weights \
  --compile-out bench/out/hardware-run/layer-block-smoke-compile \
  --trace-out bench/out/hardware-run/layer-block-smoke-trace.json \
  --cmaddr <operator-supplied>
```

Gemma af16 lm-head cell:

```bash
python3 bench/tools/run_gemma4_31b_af16_simfabric_cells.py \
  --cmaddr <operator-supplied>
```

## What to return

For the full-prompt run, return these files when present:

- `bench/out/hardware-run/gemma4-31b-af16-trace.json`
- `bench/out/hardware-run/gemma4-31b-af16-session/trace.json`
- `bench/out/hardware-run/gemma4-31b-af16-session/progress.jsonl`
- `bench/out/hardware-run/gemma4-31b-af16-hostplan/trace.json.driver-result.json`

For any returned receipt, fill explicit fields with `"redacted"` rather
than omitting them when operator policy does not allow disclosure.

- `hardware.endpoint`: operator-scoped tag, not raw IP, or `"redacted"`
- `hardware.jobId`: provider-assigned job identifier, or `"redacted"`
- `hardware.sdkVersion`: Cerebras SDK release string
- `hardware.fabricId`: fabric identity for trace pinning
- `hardware.deviceArch`: e.g. `"wse3"`
- `executedCompile.elapsedMs`: only if operator authorizes disclosure;
  otherwise `"redacted"`
- `executedRun.elapsedMs`: same disclosure policy
- `executedRun.status`: `"succeeded"` or `"failed:<taxonomy>"`
- `executedRun.generatedTokenIds`: if the full-prompt run reaches token
  output
- `executedRun.logitsDigest` or `executedRun.output.sha256`: if logits
  or output tensors are returned
- `executedRun.blocker`: typed blocker if the run stops before token
  output
- `executedRun.lastPhaseReached`: final phase marker when available
- `claimScope`: explicit `{claimable: [...], notClaimable: [...]}`

## What we will NOT publish without written approval

- Any hardware timing beyond what the operator authorizes
- Endpoint identity (IP, physical location, rack/appliance IDs)
- Queue-depth, fabric-level, or operator-internal telemetry in SDK logs
- Any performance claim beyond the receipt's own local numerical
  comparison fields
- Comparisons against other hardware unless the methodology is jointly
  signed off

See `docs/claim-discipline.md` for the full enforcement policy. The
claim-discipline gate in this repo rejects any performance prose that
does not cite a `hardware_success` receipt; the gate only goes INACTIVE
when such a receipt exists in `bench/out/`.

## Point of contact

Questions, clarifications, or receipt-field negotiation: reply to the
email thread this archive came from, or the sender address on the
outreach message. The Doe team is the point of contact; we handle the
interpretation side of anything that comes back.

`docs/hardware-validation-appendix.md` is the parent appendix;
`CEREBRAS_ASK.md` is its operational distillation. If the two ever
disagree, the appendix wins.
