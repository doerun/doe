#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// Diagnostic only. Never a supported runtime input or a replacement library.
VKAPI_ATTR VkResult VKAPI_CALL vkCreateShaderModule(VkDevice device,
 const VkShaderModuleCreateInfo *info, const VkAllocationCallbacks *allocator,
 VkShaderModule *module) {
 void *loader = dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
 PFN_vkCreateShaderModule original = loader ? (PFN_vkCreateShaderModule)dlsym(loader,"vkCreateShaderModule") : NULL;
 if (!original) return VK_ERROR_INITIALIZATION_FAILED;
 uint32_t *words = malloc(info->codeSize);
 if (!words) return VK_ERROR_OUT_OF_HOST_MEMORY;
 memcpy(words,info->pCode,info->codeSize);
 size_t count=info->codeSize/sizeof(uint32_t), changed=0;
 for(size_t i=5;i<count;) {
  uint32_t length=words[i]>>16, op=words[i]&0xffff;
  if (!length || i+length>count) abort();
  if(op==246 && length==4 && words[i+3]==2) {words[i+3]=1; changed++;}
  i+=length;
 }
 fprintf(stderr,"{\"diagnostic\":\"forced-unroll-diagnostic\",\"changedLoops\":%zu}\n",changed);
 VkShaderModuleCreateInfo patched=*info;patched.pCode=words;
 VkResult result=original(device,&patched,allocator,module);
 free(words); return result;
}
