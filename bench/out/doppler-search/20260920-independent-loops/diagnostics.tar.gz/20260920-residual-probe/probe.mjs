import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { bootstrapNodeWebGPUProvider } from '/home/x/deco/doe/packages/doe-gpu/src/node-webgpu.js';
import { instrument } from '/home/x/deco/doe/bench/out/doppler-search/20260920-profile/instrument.mjs';
const selected = process.env.DOPPLER_TIMING_PROVIDER;
const destination = process.env.DOPPLER_TIMING_OUTPUT;
await fs.mkdir(destination);
const moduleUrl = selected === 'doe' ? 'file:///home/x/deco/doe/packages/doe-gpu/src/native.js' : 'file:///home/x/deco/doe/bench/node_modules/webgpu/index.js';
const provider = await bootstrapNodeWebGPUProvider(moduleUrl, { provider: {
 id: selected, kind: 'module', module: moduleUrl,
 gpu: {kind:'factory', path:'create', args:[['backend=vulkan','enable-dawn-features=allow_unsafe_apis']]},
 globals: Object.fromEntries(['GPUBufferUsage','GPUShaderStage','GPUMapMode','GPUTextureUsage'].map(key => [key, `globals.${key}`])),
} });
const device = await provider.session.adapter.requestDevice({ requiredFeatures: ['timestamp-query'] });
const U = GPUBufferUsage;
const resources = [];
function buffer(size, usage) {
 const value = device.createBuffer({size, usage}); resources.push(value); return value;
}
const count = 96 * 1024;
const uniform = buffer(16, U.UNIFORM | U.COPY_DST);
const data = new Float32Array(count);
for (let i = 0; i < count; i++) data[i] = i % 101;
const a = buffer(data.byteLength, U.STORAGE | U.COPY_DST);
const b = buffer(data.byteLength, U.STORAGE | U.COPY_DST);
const output = buffer(data.byteLength, U.STORAGE | U.COPY_SRC);
const readback = buffer(data.byteLength, U.COPY_DST | U.MAP_READ);
device.queue.writeBuffer(a,0,data); device.queue.writeBuffer(b,0,data);
const uniforms = new ArrayBuffer(16); new Uint32Array(uniforms)[0] = count;
new Float32Array(uniforms)[1] = 1;
device.queue.writeBuffer(uniform,0,uniforms);
const shader = await fs.readFile('/var/tmp/doppler-startup-reuse-20260920/consumer/node_modules/doppler-gpu/src/gpu/kernels/residual_vec4.wgsl','utf8');
const pipeline = device.createComputePipeline({label:'residual_vec4',layout:'auto',compute:{module:device.createShaderModule({code:shader}),entryPoint:'add_vec4'}});
const bindings = device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[uniform,a,b,output].map((buffer,binding)=>({binding,resource:{buffer}}))});
const profile=instrument(device);
try {
 for(let r=0;r<4;r++) {
  if(r) await profile.start();
  const encoder=device.createCommandEncoder({label:'residual'});
  for(let i=0;i<30;i++) {
   const pass=encoder.beginComputePass(); pass.setPipeline(pipeline);pass.setBindGroup(0,bindings);pass.dispatchWorkgroups(384);pass.end();
  }
  encoder.copyBufferToBuffer(output,0,readback,0,data.byteLength);
  device.queue.submit([encoder.finish()]);
  await readback.mapAsync(GPUMapMode.READ);
  const actual=new Float32Array(readback.getMappedRange());
  for(let i=0;i<count;i++) assert.equal(actual[i],data[i]*2);
  readback.unmap();
  if(r) await fs.writeFile(`${destination}/profile-${r}.json`,JSON.stringify(await profile.stop()));
 }
 console.log('PASS',selected);
} finally {
 profile.close(); for(const r of resources.reverse())r.destroy(); device.destroy(); await provider.session.close();
}
