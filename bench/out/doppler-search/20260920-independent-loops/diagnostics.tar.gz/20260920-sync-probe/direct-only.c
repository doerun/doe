#define _GNU_SOURCE
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <stdio.h>
static unsigned long narrowed_count;
__attribute__((destructor)) static void report(void) { fprintf(stderr,"{\"diagnostic\":\"direct-only-barrier\",\"narrowed\":%lu}\n",narrowed_count); }

// Diagnostic isolation only: this executable refuses indirect GPU work.
VKAPI_ATTR void VKAPI_CALL vkCmdDispatchIndirect(VkCommandBuffer command, VkBuffer buffer, VkDeviceSize offset) {
    (void)command; (void)buffer; (void)offset;
    abort();
}

VKAPI_ATTR void VKAPI_CALL vkCmdPipelineBarrier(
    VkCommandBuffer command, VkPipelineStageFlags source, VkPipelineStageFlags destination,
    VkDependencyFlags flags, uint32_t memory_count, const VkMemoryBarrier *memory,
    uint32_t buffer_count, const VkBufferMemoryBarrier *buffers,
    uint32_t image_count, const VkImageMemoryBarrier *images) {
    void *loader = dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
    PFN_vkCmdPipelineBarrier original = loader ? (PFN_vkCmdPipelineBarrier)dlsym(loader, "vkCmdPipelineBarrier") : NULL;
    if (!original) abort();
    VkMemoryBarrier narrowed;
    if (source == VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT &&
        destination == (VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT) &&
        memory_count == 1 && !buffer_count && !image_count &&
        memory[0].srcAccessMask == VK_ACCESS_SHADER_WRITE_BIT &&
        memory[0].dstAccessMask == (VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_INDIRECT_COMMAND_READ_BIT)) {
        narrowed_count++;
        narrowed = memory[0];
        narrowed.dstAccessMask &= ~VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
        destination = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
        memory = &narrowed;
    }
    original(command, source, destination, flags, memory_count, memory, buffer_count, buffers, image_count, images);
}
