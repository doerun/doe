# Resident Doppler reranker provider timing

Local diagnostic comparing Doe with Node `webgpu` (Dawn) on the same physical
AMD/Vulkan host. No runtime, shader, model, qualification, reference output,
release threshold, or accepted package was changed for this experiment.

`policy.json` freezes the complete-operation timing boundary, warmup policy,
sample count, provider order, explicit Vulkan creation arguments, and retained
inputs. Each process opens the same Node-qualified Capsule through the same
installed Doppler public API, keeps it resident, and times each awaited rerank
request. Independent oracle evaluation and serialization occur after timing.
Model acquisition and initialization are outside the warm query measurements.

`probe.mjs` is run unchanged in fresh processes, using the same installed
Doppler archive as the preceding admission checkpoint. Provider selection and
output location are explicit environment inputs. `run.py` executes the policy
order and retains the existing DRM observer's process-boundary snapshots. This
can reject visible competing GPU work but cannot discover every transient client.

From the repository root:

```bash
python3 bench/out/doppler-search/20260920-provider-timing/run.py
node bench/out/doppler-search/20260920-provider-timing/compare.mjs
```

Replay requires a fresh output directory: the probe refuses to replace existing
per-process output directories. Preserve this directory and change the output
root consistently in the copied scripts before replay. Model and package input
paths intentionally refer to the retained local artifacts.

`comparison.json` owns current sample counts, per-process results, pooled
percentiles, ratios, and limitations. Percentiles use `bench/shared/lib/stats.js`;
no samples are discarded beyond the predefined warmup. Every execution retains
its oracle verdict, receipt, model plan, input identity, and operation counters.
The comparator requires equal declared execution policy and recorded operation
shape. Provider adapter spelling and reported maximum buffer size explain the
resolved execution digest difference; the compiler/model execution selection
remains the same. Both providers target the physical device recorded by DRM.

This is warm application reranking latency, not an isolated GPU-kernel speed
claim or a claim-index promotion. Model operation counters are not a full native
GPU trace. Complete local search, embeddings, generation, cold-start comparison,
other hardware, and release-tail qualification are outside this measurement.
