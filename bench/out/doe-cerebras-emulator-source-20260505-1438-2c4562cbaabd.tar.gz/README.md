# Doe Cerebras emulator source archive

This archive is for people who want runnable CSL source and Python drivers.
It is separate from `doe-cerebras-evidence-*.tar.gz`, which is a
correctness/governance bundle made of receipts and claim-scope documents.

## Included source surfaces

- Gemma 4 31B dense layer-block CSL:
  `bench/out/streaming-executor/e2b-layer-block-source/transformer_layer_shape.csl`
- Gemma 4 31B layer-block drivers:
  `bench/runners/csl-runners/gemma_4_31b_layer_block_smoke.py`
  and `bench/runners/csl-runners/e2b_layer_block_smoke.py`
- Gemma 4 31B AF16 lm-head cell:
  `bench/runners/csl-runners/gemma-4-31b-af16-cells/`
- Qwen 3.6 27B bounded per-kernel cells:
  `bench/runners/csl-runners/qwen-3-6-27b-cells/`
- Manifest contracts:
  `runtime/zig/examples/execution-v1/*smoke.json`

`MANIFEST.txt` records sha256, role, and path for every payload.
`BUNDLE_META.json` records the git commit and dirty-tree flag.

## Running cells

Gemma lm-head cell from the unpacked archive root:

```bash
python3 bench/tools/run_gemma4_31b_af16_simfabric_cells.py
```

For Qwen, see:

```bash
bench/runners/csl-runners/qwen-3-6-27b-cells/README.md
```

That README names the layout files with `_patched` suffixes where the
bounded cell differs from the manifest layout parameter forwarding.

## Scope

The sources here are bounded-shape simulator/emulator inputs. Manifest-shape
compile receipts and parity receipts live in the evidence bundle. Full-fabric
manifest-scale simulator execution remains a separate receipt path and is not
claimed by this source archive.
